# Build the API container image from GitHub (no local Docker)

The workflow `.github/workflows/cloudrun-api.yml` uses **Google Cloud Build** to
build the `server/` image, push it to **Artifact Registry**, and deploy it to
**Cloud Run** — all in CI, so you never run Docker yourself.

## The image URL it produces

```
africa-south1-docker.pkg.dev/<PROJECT_ID>/ngorofarm/ngorofarm-api:<git-sha>
```

Each push is tagged with its commit SHA, so every build is traceable.

## One-time setup

### 1. Create a deploy service account (in the Google Cloud console)

Create a service account (e.g. `github-deployer`) and grant it these roles:

- **Cloud Build Editor** (`roles/cloudbuild.builds.editor`)
- **Artifact Registry Admin** (`roles/artifactregistry.admin`)
- **Cloud Run Admin** (`roles/run.admin`)
- **Service Account User** (`roles/iam.serviceAccountUser`)
- **Secret Manager Secret Accessor** (`roles/secretmanager.secretAccessor`)
- **Storage Admin** (`roles/storage.admin`) — Cloud Build uses a staging bucket

Create a **JSON key** for it and download the file.

### 2. Add GitHub secrets

Repo → **Settings → Secrets and variables → Actions → New repository secret**:

- `GCP_SA_KEY` — paste the entire service-account JSON key
- `GCP_PROJECT_ID` — your Google Cloud project ID

### 3. Store the Anthropic key in Secret Manager (once)

```bash
printf "sk-ant-..." | gcloud secrets create ANTHROPIC_API_KEY --data-file=-
```

(The deploy step mounts it into the service as `ANTHROPIC_API_KEY`.)

## Run it

```bash
git add .
git commit -m "API image"
git push origin main
```

Open the repo's **Actions** tab → **Build & deploy API image to Cloud Run**.
When green, the build log prints the image URL, and the Cloud Run service
`ngorofarm-api` is live. Test: `curl https://<cloud-run-url>/health`.

## If you only want the image (not a deploy)

Delete (or comment out) the final **Deploy to Cloud Run** step. The workflow
will still build and push the image to Artifact Registry, and you can deploy it
whenever you like:

```bash
gcloud run deploy ngorofarm-api \
  --image africa-south1-docker.pkg.dev/<PROJECT_ID>/ngorofarm/ngorofarm-api:<git-sha> \
  --region africa-south1 --allow-unauthenticated \
  --set-secrets ANTHROPIC_API_KEY=ANTHROPIC_API_KEY:latest
```

## More secure alternative

Instead of a JSON key, use **Workload Identity Federation** (keyless) with
`google-github-actions/auth` — recommended for production. See
github.com/google-github-actions/auth#workload-identity-federation.
