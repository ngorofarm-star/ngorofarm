# Getting an installable APK

Compiling an Android APK needs the Android SDK build-tools + Gradle. You have
three ways to get one — pick whichever suits you.

---

## Option 1 — GitHub Actions (no tools to install) ✅ recommended

A ready-made workflow (`.github/workflows/android.yml`) builds the APK in the
cloud and gives you a downloadable file.

1. Create a new GitHub repo and push this project to it:
   ```bash
   git init && git add . && git commit -m "NgoroFarm"
   git branch -M main
   git remote add origin https://github.com/<you>/ngorofarm.git
   git push -u origin main
   ```
2. On GitHub open the **Actions** tab. The **Build Android APK** workflow runs
   automatically on push (or click **Run workflow**).
3. When it finishes (~3–5 min), open the run and download the
   **ngorofarm-debug-apk** artifact. Inside is `app-debug.apk`.
4. Copy it to an Android phone and install (allow "install unknown apps").

That APK is a **debug** build — perfect for testing/sideloading. For a Play
Store release you'll sign it (see Option 3) or extend the workflow with a
keystore stored in GitHub Secrets.

---

## Option 2 — PWABuilder (fastest, browser only)

1. Deploy the built `dist/` folder to any HTTPS host (Netlify, Vercel, GitHub
   Pages). Add a web manifest first if you want a proper icon/name.
2. Go to https://www.pwabuilder.com, paste your site URL, and download the
   **Android** package — it generates a signed APK/AAB for you.

This wraps the live web app; it's the quickest path but gives less native
access than Capacitor.

---

## Option 3 — Your own machine (full control)

Install **Node.js LTS**, **Android Studio** (with SDK), and **JDK 17**, then:

```bash
npm install
npm run build
npx cap add android      # first time only
npx cap sync
npx cap open android     # opens Android Studio
```

In Android Studio: **Build → Build APK(s)** (debug) or
**Build → Generate Signed Bundle / APK** (release, creates a keystore).

Output (debug): `android/app/build/outputs/apk/debug/app-debug.apk`.

---

### Why not build it in the chat sandbox?

The environment that generated this project blocks Google's Android SDK servers
(`dl.google.com`) and Gradle (`services.gradle.org`), so the native toolchain
can't run there. The options above run where those downloads are allowed.
