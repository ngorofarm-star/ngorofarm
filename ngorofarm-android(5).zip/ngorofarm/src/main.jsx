import React from "react";
import ReactDOM from "react-dom/client";
import NgoroFarm from "./NgoroFarm.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <NgoroFarm />
  </React.StrictMode>
);
