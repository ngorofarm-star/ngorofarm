import React, { useState, useMemo, useRef, useEffect, useCallback } from "react";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import {
  LayoutDashboard, Beef, ScanLine, HeartPulse, Baby, GitBranch, Weight as WeightIcon,
  Droplets, Boxes, Wallet, FileText, Search, Bell, Menu, X, Sun, Moon, ChevronRight,
  MapPin, Syringe, Stethoscope, TrendingUp, TriangleAlert, CircleCheck, Clock,
  QrCode, Radio, Milk, Skull, Egg, ArrowUpRight, ArrowDownRight, Printer, Plus, ChevronDown,
  Dna, Sprout, ShieldCheck, Pencil, Trash2, Save, Lock, UserCog,
  Truck, ShoppingCart, Receipt, Banknote, Smartphone, User, Calendar, Minus, Camera,
  ClipboardList, Scale, Mail, Eye, EyeOff, LogIn, LogOut, ArrowLeft, LayoutGrid,
  Wifi, BatteryFull, SignalHigh, Handshake, Wheat, GraduationCap, PlayCircle,
  Headphones, BookOpen, Cloud, CloudOff, Star, Phone, CreditCard, Palette, Fingerprint, Monitor, Laptop, MessageSquare, Send,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  NgoroFarm — Livestock Management Console (interactive prototype)   */
/*  Nairutia, Kenya · birth-to-sale digital herd records              */
/* ------------------------------------------------------------------ */

const SPECIES = { cattle: "🐄", goat: "🐐", sheep: "🐑", pig: "🐖", poultry: "🐔" };

// Color helpers — inline styles so every tint renders reliably.
const TONE = { emerald:"#059669", lime:"#5f9e2b", amber:"#e08a12", rose:"#e23a56", sky:"#0e8fd6", violet:"#7b5cf0", stone:"#79716b" };
const tint  = (c) => ({ backgroundColor: (TONE[c]||TONE.emerald) + "1f", color: TONE[c]||TONE.emerald });
const solid = (c) => TONE[c] || TONE.emerald;

/* NgoroFarm brand mark — a friendly cattle head with a growth tuft. */
function CowMark({ size = 24, tone = "white" }) {
  const head    = tone === "white" ? "#ffffff" : "#0a9d6e";
  const eye     = tone === "white" ? "#0b7a53" : "#ffffff";
  const muzzle  = tone === "white" ? "#eaf7e9" : "#d8f0dc";
  const nostril = tone === "white" ? "#0b7a53" : "#0a9d6e";
  const tuft    = tone === "white" ? "#c8f0d2" : "#5f9e2b";
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" aria-hidden="true">
      <path d="M40 33 C31 28 26 21 30 14 C23 17 24 28 33 34 C36 35 38 35 40 33 Z" fill={head}/>
      <path d="M60 33 C69 28 74 21 70 14 C77 17 76 28 67 34 C64 35 62 35 60 33 Z" fill={head}/>
      <path d="M31 40 C24 37 19 41 21 47 C26 49 31 46 33 42 Z" fill={head}/>
      <path d="M69 40 C76 37 81 41 79 47 C74 49 69 46 67 42 Z" fill={head}/>
      <path d="M50 12 C47 6 42 5 40 7 C42 12 46 15 50 15 C54 15 58 12 60 7 C58 5 53 6 50 12 Z" fill={tuft}/>
      <path d="M50 33 C39 33 31 38 30 48 C29 60 37 71 50 75 C63 71 71 60 70 48 C69 38 61 33 50 33 Z" fill={head}/>
      <circle cx="42" cy="49" r="3.1" fill={eye}/>
      <circle cx="58" cy="49" r="3.1" fill={eye}/>
      <path d="M39 60 C39 55 61 55 61 60 C61 67 55 71 50 71 C45 71 39 67 39 60 Z" fill={muzzle}/>
      <ellipse cx="45" cy="61.5" rx="1.9" ry="2.6" fill={nostril}/>
      <ellipse cx="55" cy="61.5" rx="1.9" ry="2.6" fill={nostril}/>
    </svg>
  );
}
function LogoTile({ size = 36, radius = 10 }) {
  return (
    <span className="grid place-items-center shadow-sm shrink-0" style={{ width: size, height: size, borderRadius: radius, background: "linear-gradient(135deg,#0a9d6e,#4d7c0f)" }}>
      <CowMark size={Math.round(size * 0.82)} tone="white" />
    </span>
  );
}

// --- Herd data (with pedigree links via momId / dadId) --------------
const ANIMALS = [
  { id: "NG-B-001", name: "Duke",    sp: "cattle", breed: "Boran",              sex: "M", dob: "2016-03-11", wt: 720, status: "Active", origin: "Purchased",    price: 145000, value: 210000, momId: null, dadId: null, role: "Grandsire" },
  { id: "NG-C-010", name: "Daisy",   sp: "cattle", breed: "Friesian",           sex: "F", dob: "2016-07-02", wt: 540, status: "Active", origin: "Purchased",    price: 120000, value: 180000, momId: null, dadId: null, role: "Granddam" },
  { id: "NG-B-002", name: "Titan",   sp: "cattle", breed: "Ayrshire",           sex: "M", dob: "2015-11-20", wt: 690, status: "Sold",   origin: "Purchased",    price: 130000, value: 195000, momId: null, dadId: null, role: "Grandsire" },
  { id: "NG-C-011", name: "Rosie",   sp: "cattle", breed: "Guernsey",           sex: "F", dob: "2017-01-15", wt: 505, status: "Active", origin: "Purchased",    price: 118000, value: 172000, momId: null, dadId: null, role: "Granddam" },
  { id: "NG-B-020", name: "Simba",   sp: "cattle", breed: "Friesian × Boran",   sex: "M", dob: "2019-05-04", wt: 640, status: "Active", origin: "Born on farm", price: 0,      value: 230000, momId: "NG-C-010", dadId: "NG-B-001", role: "Sire" },
  { id: "NG-C-030", name: "Malaika", sp: "cattle", breed: "Ayrshire × Guernsey",sex: "F", dob: "2019-09-18", wt: 495, status: "Active", origin: "Born on farm", price: 0,      value: 165000, momId: "NG-C-011", dadId: "NG-B-002", role: "Dam" },
  { id: "NG-C-100", name: "Nyota",   sp: "cattle", breed: "Friesian cross",     sex: "F", dob: "2022-08-12", wt: 388, status: "Active", origin: "Born on farm", price: 0,      value: 140000, momId: "NG-C-030", dadId: "NG-B-020", role: "Milking heifer" },
  { id: "NG-C-101", name: "Zawadi",  sp: "cattle", breed: "Friesian cross",     sex: "F", dob: "2024-02-03", wt: 156, status: "Active", origin: "Born on farm", price: 0,      value: 62000,  momId: "NG-C-030", dadId: "NG-B-020", role: "Weaner calf" },
  { id: "NG-C-050", name: "Wimbo",   sp: "cattle", breed: "Sahiwal",            sex: "F", dob: "2020-06-30", wt: 470, status: "Active", origin: "Purchased",    price: 112000, value: 158000, momId: null, dadId: null, role: "Dam" },
  { id: "NG-C-102", name: "Baraka",  sp: "cattle", breed: "Sahiwal cross",      sex: "M", dob: "2024-11-19", wt: 84,  status: "Active", origin: "Born on farm", price: 0,      value: 38000,  momId: "NG-C-050", dadId: "NG-B-020", role: "Bull calf" },
  { id: "NG-G-201", name: "Pili",    sp: "goat",   breed: "Galla",              sex: "F", dob: "2023-04-22", wt: 41,  status: "Active", origin: "Purchased",    price: 9000,   value: 14000,  momId: null, dadId: null, role: "Doe" },
  { id: "NG-C-045", name: "Tumaini", sp: "cattle", breed: "Friesian",           sex: "F", dob: "2021-03-10", wt: 512, status: "Dead",   origin: "Born on farm", price: 0,      value: 0,      momId: "NG-C-010", dadId: "NG-B-001", role: "—" },
];
const byId = Object.fromEntries(ANIMALS.map((a) => [a.id, a]));

const ageOf = (dob) => {
  const d = new Date(dob), now = new Date("2026-08-06");
  let m = (now.getFullYear() - d.getFullYear()) * 12 + (now.getMonth() - d.getMonth());
  const y = Math.floor(m / 12); m = m % 12;
  return y > 0 ? `${y}y ${m}m` : `${m}m`;
};
const money = (n) => "KES " + n.toLocaleString("en-KE");

// --- Timeline for the focus animal (Nyota) --------------------------
const TIMELINE = {
  "NG-C-100": [
    { date: "2022-08-12", type: "Birth",         icon: Baby,        note: "Born — 34 kg, unassisted calving",    tone: "emerald" },
    { date: "2022-08-20", type: "Vaccination",   icon: Syringe,     note: "Anthrax + Blackquarter (batch BQ-2291)", tone: "sky" },
    { date: "2022-11-02", type: "Deworming",     icon: Stethoscope, note: "Albendazole 10 ml at 190 kg",         tone: "amber" },
    { date: "2023-06-15", type: "Vaccination",   icon: Syringe,     note: "Foot & Mouth Disease (batch FMD-118)",tone: "sky" },
    { date: "2024-09-01", type: "Heat detected", icon: HeartPulse,  note: "First standing heat recorded",        tone: "rose" },
    { date: "2025-01-14", type: "AI service",    icon: Dna,         note: "Sexed semen — sire Kilifi Star",      tone: "violet" },
    { date: "2025-02-25", type: "Pregnancy +",   icon: CircleCheck, note: "Confirmed by vet, ~42 days",          tone: "emerald" },
    { date: "2025-10-30", type: "Calving",       icon: Milk,        note: "Live heifer calf, 32 kg",             tone: "emerald" },
    { date: "2026-07-28", type: "Weigh-in",      icon: WeightIcon,  note: "Monthly weight: 388 kg",              tone: "stone" },
  ],
};

const MEDICAL = [
  { date: "2026-07-19", animal: "NG-C-100", vet: "Dr. Wanjiru", diag: "Subclinical mastitis (Q3)", med: "Intramammary cephalonium", dose: "2 tubes", withdraw: "96 h milk", temp: 39.1, followup: "2026-08-02" },
  { date: "2026-06-11", animal: "NG-C-050", vet: "Dr. Otieno",  diag: "Lameness — hoof abscess",   med: "Oxytetracycline LA",       dose: "20 ml IM", withdraw: "28 d meat", temp: 38.7, followup: "2026-06-18" },
  { date: "2026-05-02", animal: "NG-B-020", vet: "Dr. Wanjiru", diag: "Routine fertility exam",     med: "—",                        dose: "—",       withdraw: "—",         temp: 38.4, followup: "—" },
];

const VACCINES = [
  { name: "Foot & Mouth Disease", due: "2026-08-14", state: "upcoming", herd: 9 },
  { name: "Lumpy Skin Disease",   due: "2026-08-09", state: "upcoming", herd: 9 },
  { name: "Anthrax",              due: "2026-07-30", state: "missed",   herd: 2 },
  { name: "Blackquarter",         due: "2026-06-20", state: "done",     herd: 9 },
  { name: "Brucellosis (S19)",    due: "2026-04-11", state: "done",     herd: 4 },
];
const vaccineTone = { upcoming: "amber", missed: "rose", done: "emerald" };

const BREEDING = [
  { dam: "NG-C-100", event: "AI service", sire: "Kilifi Star", date: "2026-08-01", status: "Awaiting PD", edd: "—" },
  { dam: "NG-C-030", event: "Pregnant",   sire: "NG-B-020",    date: "2026-03-22", status: "Confirmed",   edd: "2026-12-29" },
  { dam: "NG-C-050", event: "Heat",       sire: "—",           date: "2026-08-05", status: "Serve today", edd: "—" },
];
const statusTone = { Confirmed: "emerald", "Serve today": "rose", "Awaiting PD": "amber" };

const PAIRS = [
  { dam: "Nyota",   sire: "Kilifi Star (AI)", diversity: 92, inbreed: "0.0%",  note: "Boosts milk, unrelated line",   tone: "emerald" },
  { dam: "Malaika", sire: "Simba",            diversity: 61, inbreed: "6.25%", note: "Shares granddam — watch closely",tone: "amber" },
  { dam: "Wimbo",   sire: "Duke",             diversity: 88, inbreed: "0.0%",  note: "Adds Boran hardiness",           tone: "emerald" },
];

// --- Chart series ---------------------------------------------------
const MILK = [{ m:"Feb",yield:412 },{ m:"Mar",yield:468 },{ m:"Apr",yield:501 },{ m:"May",yield:523 },{ m:"Jun",yield:498 },{ m:"Jul",yield:545 }];
const WEIGHT_CURVE = [{ age:"0m",kg:34 },{ age:"3m",kg:96 },{ age:"6m",kg:158 },{ age:"12m",kg:232 },{ age:"18m",kg:301 },{ age:"24m",kg:355 },{ age:"now",kg:388 }];
const FINANCE = [
  { m:"Mar",income:214000,expense:138000 },{ m:"Apr",income:233000,expense:141000 },
  { m:"May",income:251000,expense:149000 },{ m:"Jun",income:242000,expense:156000 },{ m:"Jul",income:268000,expense:152000 },
];
const HERD_MIX = [
  { name:"Cows", value:6, fill:"#15803d" },{ name:"Heifers", value:2, fill:"#5f9e2b" },
  { name:"Calves", value:2, fill:"#ca8a04" },{ name:"Bulls", value:2, fill:"#78716c" },{ name:"Goats", value:1, fill:"#0e7490" },
];
const INVENTORY = [
  { item:"FMD Vaccine",        cat:"Vaccine",  qty:4,   unit:"doses", min:10 },
  { item:"Albendazole 10%",    cat:"Medicine", qty:22,  unit:"ml",    min:30 },
  { item:"Dairy Meal",         cat:"Feed",     qty:340, unit:"kg",    min:200 },
  { item:"Maclick Super",      cat:"Mineral",  qty:8,   unit:"kg",    min:15 },
  { item:"RFID ear tags",      cat:"Tags",     qty:47,  unit:"pcs",   min:25 },
  { item:"Oxytetracycline LA", cat:"Medicine", qty:6,   unit:"vials", min:5 },
];

const NAV = [
  { id:"dash",      label:"Dashboard",        icon:LayoutDashboard },
  { id:"animals",   label:"Animal register",  icon:Beef },
  { id:"health",    label:"Health & vaccines",icon:HeartPulse },
  { id:"advisory",  label:"Vet & advisory",   icon:Stethoscope },
  { id:"breeding",  label:"Reproduction",     icon:Baby },
  { id:"tree",      label:"Family tree",      icon:GitBranch },
  { id:"weight",    label:"Weight & growth",  icon:WeightIcon },
  { id:"milk",      label:"Productivity",     icon:Droplets },
  { id:"feed",      label:"Feed",             icon:Wheat },
  { id:"log",       label:"Logbook",          icon:ClipboardList },
  { id:"inventory", label:"Inventory",        icon:Boxes },
  { id:"finance",   label:"Finance",          icon:Wallet },
  { id:"coop",      label:"Kwikas Sacco",     icon:Handshake },
  { id:"money",     label:"Payments & sales",icon:CreditCard },
  { id:"reports",   label:"Reports",          icon:FileText },
];

/* Per-page accent colour — gives each section its own identity */
const VIEW_TONE = {
  dash:"emerald", animals:"sky", health:"rose", advisory:"violet", breeding:"rose",
  tree:"violet", weight:"amber", milk:"sky", feed:"lime", log:"emerald",
  inventory:"amber", finance:"emerald", coop:"sky", money:"lime", reports:"stone",
  cart:"emerald", invoice:"emerald", scan:"sky",
};

/* ================================================================== */
/* International-standard base styles: type, focus, figures, scrollbars.
   Memoized — the CSS is static, so it never needs to re-render. */
const GlobalStyle = React.memo(function GlobalStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
      :root { --nf-ring: #10b981; }
      html { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; text-rendering: optimizeLegibility; }
      body, input, select, textarea, button {
        font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      }
      body { letter-spacing: -0.011em; }
      * { -webkit-tap-highlight-color: transparent; }
      table, .nf-num { font-variant-numeric: tabular-nums; font-feature-settings: 'tnum' 1; }
      :focus-visible { outline: 2px solid var(--nf-ring); outline-offset: 2px; border-radius: 10px; }
      button:focus:not(:focus-visible), a:focus:not(:focus-visible), input:focus:not(:focus-visible),
      select:focus:not(:focus-visible), textarea:focus:not(:focus-visible) { outline: none; }
      ::selection { background: rgba(16,185,129,0.22); }
      *::-webkit-scrollbar { width: 10px; height: 10px; }
      *::-webkit-scrollbar-thumb { background: rgba(120,120,120,0.32); border-radius: 8px; border: 2px solid transparent; background-clip: padding-box; }
      *::-webkit-scrollbar-thumb:hover { background: rgba(120,120,120,0.5); background-clip: padding-box; }
      *::-webkit-scrollbar-track { background: transparent; }
      button { transition: background-color .15s ease, color .15s ease, border-color .15s ease, box-shadow .15s ease, opacity .15s ease; }
      .no-scrollbar::-webkit-scrollbar { width: 0; height: 0; display: none; }
      .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      @media (prefers-reduced-motion: reduce) {
        *, *::before, *::after { animation-duration: .001ms !important; animation-iteration-count: 1 !important; transition-duration: .001ms !important; scroll-behavior: auto !important; }
      }
    `}</style>
  );
});

/* Background palette options (light + dark gradients) */
const BG_PRESETS = [
  { key:"white",  label:"White",   swatch:"#ffffff", light:"#ffffff", dark:"linear-gradient(135deg, #0b0f0d 0%, #0f1512 100%)" },
  { key:"green",  label:"Meadow",  swatch:"#7cb342", light:"linear-gradient(135deg, #e6f4df 0%, #dcefce 100%)", dark:"linear-gradient(135deg, #0c1611 0%, #101813 40%, #14130d 100%)" },
  { key:"cream",  label:"Cream",   swatch:"#e3d3ac", light:"linear-gradient(135deg, #f7f3e8 0%, #efe7d4 100%)", dark:"linear-gradient(135deg, #151310 0%, #1a1712 40%, #181510 100%)" },
  { key:"sky",    label:"Sky",     swatch:"#7dd3fc", light:"linear-gradient(135deg, #e6f1fb 0%, #d6e8f7 100%)", dark:"linear-gradient(135deg, #0b1220 0%, #0f1826 40%, #0d1420 100%)" },
  { key:"sand",   label:"Sand",    swatch:"#fbbf77", light:"linear-gradient(135deg, #fdf1e3 0%, #fae6cf 100%)", dark:"linear-gradient(135deg, #1a1410 0%, #1f1811 40%, #1c1510 100%)" },
  { key:"slate",  label:"Slate",   swatch:"#94a3b8", light:"linear-gradient(135deg, #eef1f5 0%, #e2e8f0 100%)", dark:"linear-gradient(135deg, #0e1116 0%, #12151b 40%, #101318 100%)" },
  { key:"blossom",label:"Blossom", swatch:"#fda4af", light:"linear-gradient(135deg, #fdeef0 0%, #f9e0e6 100%)", dark:"linear-gradient(135deg, #1a1113 0%, #201519 40%, #1c1216 100%)" },
];

/* Laptop preview shell — the transform on the lid makes it the containing block
   for the app's position:fixed modals & menus, so they stay inside the screen. */
function LaptopFrame({ dark, onExit, innerRef, children }) {
  const bar = dark ? "#161a18" : "#f1f3f5";
  const edge = dark ? "#242a27" : "#e3e7ea";
  return (
    <div className="min-h-screen w-full grid place-items-center p-3 sm:p-8" style={{ background: dark ? "#0a0f0d" : "#ffffff" }}>
      {onExit && (
        <button onClick={onExit} className="fixed top-4 right-4 z-50 flex items-center gap-1.5 px-3 h-9 rounded-lg bg-white text-stone-800 text-sm font-semibold shadow-lg hover:bg-stone-100">
          <X size={15} /> Exit preview
        </button>
      )}
      <div className="w-full" style={{ maxWidth: 1120 }}>
        {/* Screen / lid */}
        <div ref={innerRef} className="relative mx-auto flex flex-col overflow-hidden"
          style={{ width: "100%", height: "min(680px, 76vh)", background: "linear-gradient(145deg, #3b4048 0%, #23262b 100%)", borderRadius: "16px 16px 5px 5px", padding: 12, boxShadow: "0 26px 50px rgba(0,0,0,0.32)", border: "1px solid #4a4f57", transform: "translateZ(0)" }}>
          {/* camera */}
          <div style={{ position: "absolute", top: 5, left: "50%", transform: "translateX(-50%)", width: 6, height: 6, borderRadius: 99, background: "#9aa0a8", zIndex: 2 }} />
          <div className="flex flex-col overflow-hidden" style={{ width: "100%", height: "100%", borderRadius: 7, background: dark ? "#0e1210" : "#ffffff" }}>
            {/* slim browser toolbar */}
            <div className="shrink-0 flex items-center gap-3 px-3" style={{ height: 36, background: bar, borderBottom: `1px solid ${edge}` }}>
              <div className="flex items-center gap-1.5 shrink-0">
                <span style={{ width: 10, height: 10, borderRadius: 99, background: "#ff5f57" }} />
                <span style={{ width: 10, height: 10, borderRadius: 99, background: "#febc2e" }} />
                <span style={{ width: 10, height: 10, borderRadius: 99, background: "#28c840" }} />
              </div>
              <div className="flex-1 flex justify-center px-4">
                <div className="flex items-center gap-1.5 px-3 h-6 rounded-md text-xs w-full" style={{ maxWidth: 340, background: dark ? "#0a0f0d" : "#ffffff", color: dark ? "#9aa39a" : "#6b7280", border: `1px solid ${edge}` }}>
                  <Lock size={10} /> app.ngorofarm.co.ke
                </div>
              </div>
              <div className="shrink-0" style={{ width: 46 }} />
            </div>
            <div className="flex-1 overflow-y-auto no-scrollbar">
              {children}
            </div>
          </div>
        </div>
        {/* Base / deck */}
        <div className="relative" style={{ width: "118%", marginLeft: "-9%", height: 15, background: "linear-gradient(180deg, #3b4048 0%, #23262b 100%)", borderRadius: "3px 3px 13px 13px", boxShadow: "0 16px 26px rgba(0,0,0,0.28)" }}>
          <div style={{ position: "absolute", top: 0, left: "50%", transform: "translateX(-50%)", width: 130, height: 7, background: "#1c1f23", borderRadius: "0 0 8px 8px" }} />
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
export default function NgoroFarm() {
  const [dark, setDark]       = useState(false);
  const [view, setView]       = useState("dash");
  const [sel, setSel]         = useState(null);
  const [query, setQuery]     = useState("");
  const [admin, setAdmin]     = useState(false);      // RBAC: Administrator unlocks edit/amend/delete
  const [authed, setAuthed]   = useState(false);      // signed in?
  const [animals, setAnimals] = useState(ANIMALS);    // live herd (CRUD in-session)
  const [history, setHistory] = useState([]);         // page history for Back
  const [online, setOnline]   = useState(true);        // connectivity (offline-capture demo)
  const [cart, setCart]       = useState([]);          // animal ids added to cart
  const [regSp, setRegSp]     = useState("all");       // register species filter (shared with nav dropdown)
  const [moneyTab, setMoneyTab] = useState("pay");     // Payments & sales active tab
  const [bg, setBg]           = useState("white");     // background palette
  const [palOpen, setPalOpen] = useState(false);       // palette menu open?
  const [palPos, setPalPos]   = useState({ top: 0, left: 0 });
  const palBtnRef = useRef(null);
  const [navMenu, setNavMenu] = useState(false);       // species dropdown open?
  const [menuPos, setMenuPos] = useState({ top: 0, left: 0 });
  const animalsBtnRef = useRef(null);
  const [framed, setFramed]   = useState(true);        // phone-frame preview?
  const frameRef = useRef(null);
  const t = useMemo(() => theme(dark), [dark]);
  const preset = BG_PRESETS.find((p) => p.key === bg) || BG_PRESETS[0];
  const bgStyle = dark ? preset.dark : preset.light;
  const pageTone = VIEW_TONE[view] || "emerald";

  // When previewing inside the phone frame, position:fixed pop-ups are relative
  // to the (transformed) frame, so shift menu coords by the frame's offset.
  const frameOff = () => {
    if (!framed || !frameRef.current) return { x: 0, y: 0 };
    const r = frameRef.current.getBoundingClientRect();
    return { x: r.left, y: r.top };
  };

  const openPalette = () => {
    const r = palBtnRef.current?.getBoundingClientRect();
    if (r) { const o = frameOff(); setPalPos({ top: r.bottom + 6 - o.y, left: Math.max(8, r.right - 224 - o.x) }); }
    setPalOpen((v) => !v);
  };

  const openNavMenu = () => {
    const r = animalsBtnRef.current?.getBoundingClientRect();
    if (r) { const o = frameOff(); setMenuPos({ top: r.bottom + 6 - o.y, left: r.left - o.x }); }
    setNavMenu((v) => !v);
  };
  const pickSpecies = (key) => { setRegSp(key); setNavMenu(false); go("animals"); };

  const navItem = (n) => {
    const active = view === n.id;
    const tone = VIEW_TONE[n.id] || "emerald";
    if (n.id === "animals") {
      return (
        <div key="animals" className={`relative shrink-0 flex items-center rounded-lg shadow-sm ${active ? "text-white" : t.muted}`} style={active ? { backgroundColor: solid(tone) } : undefined}>
          <button onClick={() => { setRegSp("all"); go("animals"); }}
            className={`flex items-center gap-2 pl-3 pr-1.5 py-2 text-sm font-bold rounded-l-lg ${active ? "" : t.hover}`}>
            <Beef size={16} style={active ? undefined : { color: solid(tone) }} className={active ? "text-white" : ""} />
            Animal register
          </button>
          <button ref={animalsBtnRef} onClick={openNavMenu} title="Filter by species"
            className={`pr-2 pl-0.5 py-2 rounded-r-lg ${active ? "" : t.hover}`}>
            <ChevronDown size={14} className={`transition-transform ${navMenu ? "rotate-180" : ""} ${active ? "text-white" : ""}`} style={active ? undefined : { color: solid(tone) }} />
          </button>
        </div>
      );
    }
    return (
      <button key={n.id} onClick={() => go(n.id)}
        className={`shrink-0 flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-bold transition-colors ${active ? "text-white shadow-sm" : `${t.muted} ${t.hover}`}`}
        style={active ? { backgroundColor: solid(tone) } : undefined}>
        <n.icon size={16} style={active ? undefined : { color: solid(tone) }} className={active ? "text-white" : ""} />
        {n.label}
      </button>
    );
  };

  // Latest-value refs so navigation callbacks can stay identity-stable.
  const viewRef = useRef(view); viewRef.current = view;
  const selRef  = useRef(sel);  selRef.current  = sel;
  const histRef = useRef(history); histRef.current = history;

  // Navigate while recording where we came from, so Back can return there.
  const go = useCallback((next) => { const v = viewRef.current; if (next !== v) setHistory((h) => [...h, v]); setView(next); }, []);
  const goBack = useCallback(() => { const h = histRef.current; if (!h.length) return; setSel(null); setView(h[h.length - 1]); setHistory(h.slice(0, -1)); }, []);
  const open = useCallback((id) => { const v = viewRef.current, s = selRef.current; if (v !== "animals" || s !== id) setHistory((h) => [...h, v]); setSel(id); setView("animals"); }, []);
  const toggleCart = useCallback((id) => setCart((c) => c.includes(id) ? c.filter((x) => x !== id) : [...c, id]), []);
  const clearCart = useCallback(() => setCart([]), []);
  const openCheckout = useCallback(() => { setMoneyTab("checkout"); go("money"); }, [go]);

  if (!authed) {
    const login = <><GlobalStyle /><Login t={t} dark={dark} setDark={setDark} framed={framed}
      onLogin={(role) => { setAdmin(role === "admin"); setAuthed(true); setHistory([]); setView("dash"); }} /></>;
    return framed ? <LaptopFrame dark={dark} onExit={() => setFramed(false)}>{login}</LaptopFrame> : login;
  }

  const body = (
    <div className={`${framed ? "min-h-full" : "min-h-screen"} w-full ${t.app}`} style={{ background: bgStyle, backgroundAttachment: framed ? "scroll" : "fixed" }}>
      <GlobalStyle />
      {/* Top navigation */}
      <header className={`sticky top-0 z-30 ${t.bar} border-b ${t.border} backdrop-blur`}>
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="h-16 flex items-center gap-3">
            <button onClick={goBack} disabled={!history.length} title="Back"
              className={`grid place-items-center w-10 h-10 rounded-lg shrink-0 ${t.chip} ${history.length ? t.hover : ""}`}
              style={{ opacity: history.length ? 1 : 0.4 }}>
              <ArrowLeft size={18} className={t.strong} />
            </button>
            <button onClick={() => go("dash")} className="flex items-center gap-2 shrink-0">
              <LogoTile size={36} radius={10} />
              <div className="leading-tight text-left hidden sm:block">
                <div className={`font-bold tracking-tight ${t.strong}`}>NgoroFarm</div>
                <div className="text-xs font-medium flex items-center gap-1" style={{ color: TONE.emerald }}><MapPin size={10} /> Nairutia, Kenya</div>
              </div>
            </button>

            <div className={`flex items-center gap-2 flex-1 min-w-0 max-w-md px-3 h-10 rounded-lg ${t.input} border ${t.border}`}>
              <Search size={16} className={t.muted} />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search RFID, name, breed, ID…"
                className={`bg-transparent outline-none text-sm w-full ${t.strong}`} onFocus={() => go("animals")} />
            </div>

            <button onClick={() => setAdmin(!admin)} title={admin ? "Administrator — edit/delete unlocked" : "Read-only — tap to enter Administrator mode"}
              className="hidden sm:flex items-center gap-1.5 h-10 px-3 rounded-lg text-xs font-semibold text-white shadow-sm shrink-0"
              style={{ backgroundColor: admin ? TONE.emerald : TONE.stone }}>
              {admin ? <ShieldCheck size={15} /> : <UserCog size={15} />}{admin ? "Administrator" : "Manager"}
            </button>
            <button onClick={() => setOnline(!online)} title={online ? "Online — tap to simulate offline" : "Offline — changes are queued locally"}
              className="hidden sm:grid place-items-center w-10 h-10 rounded-lg shrink-0"
              style={online ? tint("emerald") : tint("amber")}>
              {online ? <Cloud size={18} /> : <CloudOff size={18} />}
            </button>
            <button ref={palBtnRef} onClick={openPalette} title="Background colour" className={`hidden sm:grid place-items-center w-10 h-10 rounded-lg shrink-0 ${t.chip} ${t.hover}`}>
              <Palette size={18} className={t.muted} />
            </button>
            <button onClick={() => setFramed((f) => !f)} title="Laptop preview" className={`hidden lg:grid place-items-center w-10 h-10 rounded-lg shrink-0 ${framed ? "text-white" : `${t.chip} ${t.hover}`}`} style={framed ? { backgroundColor: TONE.emerald } : undefined}>
              <Laptop size={18} className={framed ? "text-white" : t.muted} />
            </button>
            <button onClick={() => setDark(!dark)} className={`grid place-items-center w-10 h-10 rounded-lg shrink-0 ${t.chip} ${t.hover}`}>
              {dark ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} className="text-stone-600" />}
            </button>
            <button onClick={() => go("cart")} title="Cart" className={`relative grid place-items-center w-10 h-10 rounded-lg shrink-0 ${t.chip} ${t.hover}`}>
              <ShoppingCart size={18} className={t.muted} />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 grid place-items-center rounded-full text-white font-bold" style={{ backgroundColor: TONE.emerald, fontSize: 10 }}>{cart.length}</span>
              )}
            </button>
            <button className={`relative hidden sm:grid place-items-center w-10 h-10 rounded-lg shrink-0 ${t.chip} ${t.hover}`}>
              <Bell size={18} className={t.muted} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500" />
            </button>
            <button onClick={() => setAuthed(false)} title="Sign out" className={`grid place-items-center w-10 h-10 rounded-lg shrink-0 ${t.chip} ${t.hover}`}>
              <LogOut size={18} className={t.muted} />
            </button>
            <div className={`hidden md:flex items-center gap-2 pl-3 ml-1 border-l ${t.border} shrink-0`}>
              <div className="grid place-items-center w-8 h-8 rounded-full text-white text-xs font-bold" style={{ backgroundColor: admin ? TONE.emerald : TONE.amber }}>AK</div>
              <div className="leading-tight text-xs">
                <div className={`font-semibold ${t.strong}`}>Anthony K.</div>
                <div className={t.muted}>{admin ? "Administrator" : "Farm Manager"}</div>
              </div>
            </div>
          </div>

          <div className="pb-1 space-y-1.5">
            <nav className="flex gap-1.5 overflow-x-auto sm:overflow-visible no-scrollbar">{NAV.slice(0, 8).map(navItem)}</nav>
            <nav className="flex gap-1.5 overflow-x-auto sm:overflow-visible no-scrollbar">{NAV.slice(8).map(navItem)}</nav>
          </div>
        </div>
      </header>

      {/* Background palette menu */}
      {palOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setPalOpen(false)} />
          <div className={`fixed z-50 w-56 rounded-xl border ${t.border} ${t.card} p-2`} style={{ top: palPos.top, left: palPos.left, boxShadow: t.shadow }}>
            <div className={`text-xs font-semibold ${t.muted} px-1 pb-1.5`}>Background colour</div>
            <div className="grid grid-cols-3 gap-1.5">
              {BG_PRESETS.map((p) => {
                const on = bg === p.key;
                return (
                  <button key={p.key} onClick={() => { setBg(p.key); setPalOpen(false); }}
                    className={`flex flex-col items-center gap-1.5 p-2 rounded-lg ${on ? "" : t.hover}`}
                    style={on ? { outline: `2px solid ${TONE.emerald}`, outlineOffset: -2 } : undefined}>
                    <span className="w-8 h-8 rounded-full" style={{ background: dark ? p.dark : p.light, border: "1px solid rgba(0,0,0,0.12)" }} />
                    <span className={`text-xs ${t.strong}`}>{p.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}

      {/* Species dropdown (rendered fixed so the scrolling nav doesn't clip it) */}
      {navMenu && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setNavMenu(false)} />
          <div className={`fixed z-50 w-44 rounded-xl border ${t.border} ${t.card} p-1`} style={{ top: menuPos.top, left: menuPos.left, boxShadow: t.shadow }}>
            {[
              { key:"all",    label:"All animals", emoji:"🐾" },
              { key:"cattle", label:"Cows",  emoji:SPECIES.cattle },
              { key:"goat",   label:"Goats", emoji:SPECIES.goat },
              { key:"sheep",  label:"Sheep", emoji:SPECIES.sheep },
              { key:"pig",    label:"Pigs",  emoji:SPECIES.pig },
            ].map((o) => {
              const on = regSp === o.key && view === "animals";
              return (
                <button key={o.key} onClick={() => pickSpecies(o.key)}
                  className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm font-medium ${on ? "" : `${t.strong} ${t.hover}`}`}
                  style={on ? { backgroundColor: TONE.emerald, color: "#fff" } : undefined}>
                  <span className="text-base leading-none">{o.emoji}</span>
                  <span className="flex-1 text-left">{o.label}</span>
                  {on && <CircleCheck size={15} />}
                </button>
              );
            })}
          </div>
        </>
      )}

      {!online && (
        <div className="text-sm font-medium flex items-center justify-center gap-2 py-2 px-4" style={tint("amber")}>
          <CloudOff size={15} /> Working offline — records are saved on the device and will sync when you're back online.
        </div>
      )}

      <main className="p-4 sm:p-6 max-w-6xl mx-auto">
        <div className="h-1 rounded-full mb-5" style={{ background: `linear-gradient(90deg, ${solid(pageTone)}, ${solid(pageTone)}22 45%, transparent 80%)` }} />
        {view === "dash"      && <DashboardM t={t} open={open} setView={go} animals={animals} openCheckout={openCheckout} online={online} />}
        {view === "animals"   && <RegisterM t={t} query={query} sel={sel} setSel={setSel} animals={animals} setAnimals={setAnimals} admin={admin} cart={cart} toggleCart={toggleCart} spFilter={regSp} setSp={setRegSp} />}
        {view === "cart"      && <CartM t={t} animals={animals} cart={cart} toggleCart={toggleCart} clearCart={clearCart} go={go} openCheckout={openCheckout} />}
        {view === "invoice"   && <InvoiceM t={t} animals={animals} cart={cart} go={go} />}
        {view === "scan"      && <ScanM t={t} open={open} animals={animals} />}
        {view === "health"    && <HealthM t={t} open={open} />}
        {view === "advisory"  && <AdvisoryM t={t} />}
        {view === "breeding"  && <BreedingM t={t} open={open} />}
        {view === "tree"      && <FamilyTreeM t={t} open={open} dark={dark} />}
        {view === "weight"    && <WeightViewM t={t} />}
        {view === "milk"      && <ProductivityM t={t} />}
        {view === "feed"      && <FeedM t={t} />}
        {view === "log"       && <LogbookM t={t} animals={animals} dark={dark} />}
        {view === "inventory" && <InventoryM t={t} />}
        {view === "finance"   && <FinanceM t={t} />}
        {view === "coop"      && <CooperativeM t={t} />}
        {view === "money"     && <TransactionsM t={t} tab={moneyTab} setTab={setMoneyTab} animals={animals} setAnimals={setAnimals} />}
        {view === "reports"   && <ReportsM t={t} />}
      </main>
    </div>
  );

  if (!framed) return body;

  return <LaptopFrame dark={dark} onExit={() => setFramed(false)} innerRef={frameRef}>{body}</LaptopFrame>;
}

/* ================================================================== */
/*  Views                                                             */
/* ================================================================== */

/* AI farm assistant — floating chat that calls the Anthropic API (with a
   graceful offline/preview fallback). */
function ChatBot({ t }) {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState([{ role: "assistant", content: "Habari! I'm your NgoroFarm assistant. Ask me about herd health, vaccinations, breeding & AI timing, feed rations, milk records, or M-Pesa payments." }]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const boxRef = useRef(null);
  useEffect(() => { if (boxRef.current) boxRef.current.scrollTop = boxRef.current.scrollHeight; }, [msgs, busy, open]);

  const send = async () => {
    const text = input.trim();
    if (!text || busy) return;
    const next = [...msgs, { role: "user", content: text }];
    setMsgs(next); setInput(""); setBusy(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: "You are the NgoroFarm assistant for a commercial dairy farm in Nairutia, Kenya. Help the farmer with livestock health, vaccination schedules, breeding and AI timing, feed rations and cost-per-litre, milk records, and M-Pesa/SACCO finance. Use Kenyan context (KES, common diseases like East Coast Fever, FMD, mastitis). Keep answers short, practical and friendly. For medical or dosing questions, remind them to confirm with a qualified vet.",
          messages: next.map((m) => ({ role: m.role, content: m.content })),
        }),
      });
      const data = await res.json();
      const reply = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n").trim();
      setMsgs((m) => [...m, { role: "assistant", content: reply || "Sorry, I didn't catch that — could you rephrase?" }]);
    } catch {
      setMsgs((m) => [...m, { role: "assistant", content: "I can't reach the assistant service in this preview. In the published app I'll answer here using your farm data." }]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed z-40" style={{ right: 18, bottom: 18 }}>
      {open && (
        <div className={`mb-3 rounded-2xl border ${t.border} ${t.card} shadow-xl flex flex-col overflow-hidden`} style={{ width: 330, maxWidth: "82vw", height: 460 }}>
          <div className="shrink-0 flex items-center gap-2 px-4 text-white" style={{ height: 52, background: "linear-gradient(135deg,#0a9d6e,#4d7c0f)" }}>
            <span className="grid place-items-center w-8 h-8 rounded-lg" style={{ background: "rgba(255,255,255,0.2)" }}><CowMark size={20} tone="white" /></span>
            <div className="flex-1 min-w-0"><div className="text-sm font-bold leading-tight">NgoroFarm assistant</div><div className="text-xs" style={{ color: "rgba(255,255,255,0.85)" }}>AI · farm help</div></div>
            <button onClick={() => setOpen(false)} className="grid place-items-center w-8 h-8 rounded-lg" style={{ background: "rgba(255,255,255,0.15)" }}><X size={16} /></button>
          </div>
          <div ref={boxRef} className="flex-1 overflow-y-auto p-3 space-y-2 no-scrollbar">
            {msgs.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`px-3 py-2 rounded-2xl text-sm whitespace-pre-wrap ${m.role === "user" ? "text-white" : `${t.chip} ${t.strong}`}`}
                  style={{ maxWidth: "82%", ...(m.role === "user" ? { background: solid("emerald") } : {}) }}>{m.content}</div>
              </div>
            ))}
            {busy && <div className="flex justify-start"><div className={`px-3 py-2 rounded-2xl text-sm ${t.chip} ${t.muted}`}>typing…</div></div>}
          </div>
          <div className={`shrink-0 flex items-center gap-2 p-2.5 border-t ${t.border}`}>
            <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder="Ask about your farm…" className={`flex-1 h-9 px-3 rounded-lg text-sm outline-none border ${t.border} ${t.input} ${t.strong}`} />
            <button onClick={send} disabled={busy} className="grid place-items-center w-9 h-9 rounded-lg bg-emerald-600 text-white shrink-0 disabled:opacity-50"><Send size={16} /></button>
          </div>
        </div>
      )}
      <button onClick={() => setOpen((o) => !o)} title="Farm assistant"
        className="grid place-items-center w-14 h-14 rounded-full text-white shadow-lg transition-transform hover:-translate-y-0.5 ml-auto"
        style={{ background: "linear-gradient(135deg,#0a9d6e,#4d7c0f)" }}>
        {open ? <X size={22} /> : <MessageSquare size={22} />}
      </button>
    </div>
  );
}

function Dashboard({ t, open, setView, animals, openCheckout, online }) {
  const [range, setRange] = useState("7d");
  const RANGES = [["today", "Today"], ["7d", "7 days"], ["30d", "30 days"]];
  const rangeLabel = { today: "today", "7d": "last 7 days", "30d": "last 30 days" }[range];
  // Period-aware milk figure (mock but responsive to the selected range)
  const milkKpi = { today: { v: "148 L", s: "across 6 milkers" }, "7d": { v: "142 L", s: "7-day daily average" }, "30d": { v: "138 L", s: "30-day daily average" } }[range];
  const active = animals.filter((a) => a.status === "Active");
  const herdValue = active.reduce((s, a) => s + (a.value || 0), 0);
  const cattle = active.filter((a) => a.sp === "cattle").length;

  const mix = [
    { name:"Cattle",  value: active.filter((a)=>a.sp==="cattle").length,  fill: TONE.emerald },
    { name:"Goats",   value: active.filter((a)=>a.sp==="goat").length,    fill: TONE.lime },
    { name:"Sheep",   value: active.filter((a)=>a.sp==="sheep").length,   fill: TONE.amber },
    { name:"Poultry", value: active.filter((a)=>a.sp==="poultry").length, fill: TONE.sky },
    { name:"Pigs",    value: active.filter((a)=>a.sp==="pig").length,     fill: TONE.violet },
  ].filter((x) => x.value > 0);

  const net = FINANCE.at(-1).income - FINANCE.at(-1).expense;
  const dateStr = new Date(TODAY).toLocaleDateString("en-GB", { weekday:"long", day:"numeric", month:"long" });

  const kpis = [
    { label:"Active animals", value:String(active.length), sub:`${cattle} cattle · ${active.length-cattle} other`, icon:Beef,      tone:"emerald", view:"animals",  delta:{ up:true,  v:"+1" },   spark:[{v:9},{v:10},{v:10},{v:11},{v:11},{v:12}] },
    { label:"Milk today",     value:milkKpi.v,             sub:milkKpi.s,                                          icon:Milk,      tone:"sky",     view:"milk",     delta:{ up:true,  v:"9.4%" }, spark:[{v:120},{v:128},{v:132},{v:130},{v:140},{v:148}] },
    { label:"Herd value",     value:money(herdValue),      sub:"live valuation",                                   icon:Wallet,    tone:"lime",    view:"finance",  delta:{ up:true,  v:"3.1%" }, spark:[{v:70},{v:72},{v:74},{v:76},{v:79},{v:82}] },
    { label:"Needs attention",value:"3",                   sub:"1 overdue · 2 due",                                icon:TriangleAlert, tone:"rose",view:"health",   delta:{ up:false, v:"-2" },   spark:[{v:6},{v:5},{v:5},{v:4},{v:4},{v:3}] },
  ];

  const attn = [
    { tone:"rose",    icon:Syringe,  title:"Anthrax vaccine missed", body:"2 animals overdue since 30 Jul", view:"health" },
    { tone:"amber",   icon:Boxes,    title:"Low stock: FMD vaccine", body:"4 doses left · reorder at 10",   view:"inventory" },
    { tone:"emerald", icon:Droplets, title:"Wimbo in standing heat", body:"AI window closes 6 pm today",    view:"breeding" },
  ];
  const quick = [
    { icon:Plus,     label:"Register animal", tone:"emerald", view:"animals" },
    { icon:ScanLine, label:"Scan a tag",      tone:"sky",     view:"scan" },
    { icon:Syringe,  label:"Vaccination",     tone:"amber",   view:"health" },
    { icon:Truck,    label:"Check-out",       tone:"violet",  view:"checkout" },
  ];
  const recents = [
    { i:Milk,    c:"emerald", txt:"Evening milking logged — 24.6 L",   w:"35 min ago" },
    { i:Syringe, c:"sky",     txt:"Deworming: 4 calves",               w:"2 h ago" },
    { i:Baby,    c:"lime",    txt:"Baraka registered (NG-C-102)",      w:"Yesterday" },
    { i:Wallet,  c:"amber",   txt:"Feed purchase — KES 18,400",        w:"Yesterday" },
    { i:Skull,   c:"rose",    txt:"Tumaini marked deceased",           w:"3 d ago" },
  ];

  // Benchmarked livestock KPIs (higher-better unless noted) — vs on-farm targets.
  const deaths = animals.filter((a) => a.status === "Dead").length;
  const mortality = animals.length ? +(deaths / animals.length * 100).toFixed(1) : 0;
  const perf = [
    { label:"Vaccination compliance", value:88,        unit:"%",       target:95,   higher:true },
    { label:"Calving rate",           value:82,        unit:"%",       target:85,   higher:true },
    { label:"Avg daily gain",         value:0.72,      unit:" kg/d",   target:0.80, higher:true },
    { label:"Mortality rate",         value:mortality, unit:"%",       target:3,    higher:false },
  ];

  const incomeNow = FINANCE.at(-1).income;
  const margin = incomeNow ? Math.round(net / incomeNow * 100) : 0;

  const upcoming = [
    { day:"Today", icon:Syringe,     tone:"rose",   txt:"FMD booster — 3 cattle",         tag:"Vaccination", view:"health" },
    { day:"Thu",   icon:Baby,        tone:"lime",   txt:"Malaika expected to calve",      tag:"Reproduction", view:"breeding" },
    { day:"Fri",   icon:Droplets,    tone:"sky",    txt:"Dry off Nyota (60d pre-calving)",tag:"Productivity", view:"milk" },
    { day:"Sat",   icon:Scale,       tone:"amber",  txt:"Monthly weigh-in — all calves",  tag:"Weight",      view:"weight" },
    { day:"Sun",   icon:Stethoscope, tone:"violet", txt:"Vet visit — pregnancy checks",   tag:"Advisory",    view:"advisory" },
    { day:"Mon",   icon:Wheat,       tone:"emerald",txt:"Reorder dairy meal (2 bags left)",tag:"Feed",       view:"feed" },
  ];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider" style={{ color: solid("emerald") }}>NgoroFarm · Nairutia</div>
          <h1 className={`text-2xl sm:text-3xl font-bold tracking-tight mt-1 ${t.strong}`}>Karibu, Anthony</h1>
          <p className={`text-sm ${t.muted} mt-1`}>{dateStr}</p>
          <p className={`text-sm mt-2 ${t.strong}`}>
            <b style={{ color: solid("rose") }}>{attn.length}</b> need attention today ·{" "}
            <b style={{ color: solid("sky") }}>{upcoming.length}</b> scheduled this week ·{" "}
            herd value <b style={{ color: solid("emerald") }}>{money(herdValue)}</b>
          </p>
        </div>
        <div className="flex flex-col sm:items-end gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full inline-flex items-center gap-1.5 w-fit" style={tint(online ? "emerald" : "amber")}>
            {online ? <><Cloud size={12} /> Synced · 6:12 AM</> : <><CloudOff size={12} /> Offline · local</>}
          </span>
          <div className={`flex gap-1 p-1 rounded-xl ${t.chip} w-fit`}>
            {RANGES.map(([k, l]) => (
              <button key={k} onClick={() => setRange(k)} className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${range === k ? "bg-emerald-600 text-white shadow-sm" : `${t.muted} ${t.hover}`}`}>{l}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {quick.map((q) => (
          <button key={q.label} onClick={() => q.view === "checkout" ? openCheckout() : setView(q.view)}
            className={`flex items-center gap-3 p-3 rounded-2xl border ${t.border} ${t.card} ${t.hover} transition-transform hover:-translate-y-0.5`} style={{ boxShadow: t.shadow }}>
            <span className="grid place-items-center w-10 h-10 rounded-xl" style={tint(q.tone)}><q.icon size={18} /></span>
            <span className={`text-sm font-bold ${t.strong}`}>{q.label}</span>
          </button>
        ))}
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {kpis.map((k) => (
          <button key={k.label} onClick={() => setView(k.view)}
            className={`relative overflow-hidden text-left p-4 rounded-2xl border ${t.border} ${t.card} transition-transform hover:-translate-y-0.5`}
            style={{ boxShadow: t.shadow }}>
            <div className="absolute inset-0 pointer-events-none" style={{ background: `linear-gradient(160deg, ${solid(k.tone)}1f 0%, transparent 55%)` }} />
            <div className="relative">
              <div className="flex items-center justify-between">
                <span className="grid place-items-center w-9 h-9 rounded-lg" style={tint(k.tone)}><k.icon size={17} /></span>
                {k.delta && <span className="text-xs font-semibold flex items-center gap-0.5" style={{ color: solid(k.delta.up ? "emerald" : "rose") }}>{k.delta.up ? <ArrowUpRight size={13}/> : <ArrowDownRight size={13}/>}{k.delta.v}</span>}
              </div>
              <div className={`text-2xl font-bold mt-3 ${t.strong}`} style={{ letterSpacing: "-0.02em" }}>{k.value}</div>
              <div className={`text-xs font-semibold ${t.strong}`}>{k.label}</div>
              <div className={`text-xs ${t.muted} mt-0.5`}>{k.sub}</div>
              <div className="h-9 -mx-1 mt-2">
                <ResponsiveContainer>
                  <AreaChart data={k.spark} margin={{ top: 2, bottom: 0, left: 0, right: 0 }}>
                    <Area dataKey="v" type="monotone" stroke={solid(k.tone)} strokeWidth={2} fill={solid(k.tone)} fillOpacity={0.14} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Insight grid */}
      <div className="grid lg:grid-cols-3 gap-4 sm:gap-5 items-start">
        {/* Priorities */}
        <div className="lg:col-span-2 space-y-4 sm:space-y-5">
          <Card t={t}>
            <CardTitle t={t} icon={TriangleAlert} title="Needs attention"
              right={<span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={tint("rose")}>{attn.length} now</span>} />
            <div className="space-y-1">
              {attn.map((x) => (
                <button key={x.title} onClick={() => setView(x.view)} className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-left ${t.hover} transition-colors`}>
                  <span className="grid place-items-center w-9 h-9 rounded-lg shrink-0" style={tint(x.tone)}><x.icon size={16} /></span>
                  <div className="flex-1 min-w-0"><div className={`text-sm font-semibold ${t.strong}`}>{x.title}</div><div className={`text-xs ${t.muted}`}>{x.body}</div></div>
                  <ChevronRight size={15} className={`${t.muted} shrink-0`} />
                </button>
              ))}
            </div>
          </Card>

          <Card t={t}>
            <CardTitle t={t} icon={Calendar} title="This week"
              right={<span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={tint("sky")}>{upcoming.length} scheduled</span>} />
            <div className="space-y-1">
              {upcoming.map((u) => (
                <button key={u.txt} onClick={() => setView(u.view)} className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-left ${t.hover} transition-colors`}>
                  <span className={`grid place-items-center w-11 shrink-0 text-xs font-bold py-1.5 rounded-lg ${t.chip} ${t.strong}`}>{u.day}</span>
                  <span className="grid place-items-center w-9 h-9 rounded-lg shrink-0" style={tint(u.tone)}><u.icon size={16} /></span>
                  <div className="min-w-0 flex-1"><div className={`text-sm font-semibold ${t.strong} truncate`}>{u.txt}</div><div className={`text-xs ${t.muted}`}>{u.tag}</div></div>
                  <ChevronRight size={15} className={`${t.muted} shrink-0`} />
                </button>
              ))}
            </div>
          </Card>
        </div>

        {/* Snapshot */}
        <div className="space-y-4 sm:space-y-5">
          <Card t={t}>
            <CardTitle t={t} icon={Beef} title="Herd composition" />
            <div className="relative h-44">
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={mix} dataKey="value" nameKey="name" innerRadius={48} outerRadius={72} paddingAngle={2} stroke="none">
                    {mix.map((d,i) => <Cell key={i} fill={d.fill} />)}
                  </Pie>
                  <Tooltip contentStyle={t.tip} />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 grid place-items-center pointer-events-none">
                <div className="text-center"><div className={`text-2xl font-bold ${t.strong}`}>{active.length}</div><div className={`text-xs ${t.muted}`}>animals</div></div>
              </div>
            </div>
            <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs mt-1 justify-center">
              {mix.map((d) => <span key={d.name} className={`flex items-center gap-1 ${t.muted}`}><span className="w-2.5 h-2.5 rounded-sm" style={{ background:d.fill }} />{d.name} · {d.value}</span>)}
            </div>
          </Card>

          <Card t={t}>
            <CardTitle t={t} icon={TrendingUp} title="Performance" right={<span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={tint("emerald")}>{perf.filter((p)=>(p.higher?p.value/p.target:p.target/(p.value||1))>=1).length}/{perf.length} on target</span>} />
            <div className="space-y-3.5">
              {perf.map((p) => {
                const attain = p.higher ? p.value / p.target : p.target / (p.value || 0.0001);
                const pct = Math.max(6, Math.min(100, Math.round(attain * 100)));
                const tone = attain >= 1 ? "emerald" : attain >= 0.9 ? "amber" : "rose";
                return (
                  <div key={p.label}>
                    <div className="flex items-baseline justify-between gap-2">
                      <span className={`text-xs font-semibold ${t.strong}`}>{p.label}</span>
                      <span className={`text-xs nf-num ${t.muted}`}>{p.value}{p.unit} / {p.target}{p.unit}</span>
                    </div>
                    <div className={`mt-1.5 h-1.5 rounded-full ${t.track} overflow-hidden`}>
                      <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: solid(tone) }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>

      {/* Recent activity */}
      <Card t={t}>
        <CardTitle t={t} icon={Clock} title="Recent activity" />
        <ul className="space-y-3 text-sm">
          {recents.map((a,i) => (
            <li key={i} className="flex items-start gap-3">
              <span className="mt-0.5 grid place-items-center w-7 h-7 rounded-lg" style={tint(a.c)}><a.i size={14} /></span>
              <div className="flex-1"><div className={t.strong}>{a.txt}</div><div className={`text-xs ${t.muted}`}>{a.w}</div></div>
            </li>
          ))}
        </ul>
      </Card>

      <ChatBot t={t} />
    </div>
  );
}

/* ================================================================== */
/*  Invoice — printable document generated from the cart              */
/* ================================================================== */
/* ---- Shared invoice document (used by cart + check-out) ----------- */
function IRow({ k, v }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "3px 0", fontSize: 13 }}>
      <span style={{ color: "#6b7280" }}>{k}</span>
      <span style={{ color: "#111827", fontWeight: 600 }}>{v}</span>
    </div>
  );
}

function InvoiceDoc({ invNo, billTo, details, items, subtotal, vat, total, extra, footerNote }) {
  const ink = "#111827", sub = "#6b7280", line = "#e5e7eb", green = "#15803d", green2 = "#4d7c0f", soft = "#f6faf4";
  return (
    <div className="mx-auto w-full max-w-3xl rounded-2xl overflow-hidden shadow-lg" style={{ background: "#fff", color: ink, border: `1px solid ${line}` }}>
      {/* Header band */}
      <div style={{ background: `linear-gradient(120deg, ${green} 0%, ${green2} 100%)`, color: "#fff", padding: "26px 32px", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", right: -12, top: -26, opacity: 0.12 }}><CowMark size={150} tone="white" /></div>
        <div style={{ position: "relative", display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16, flexWrap: "wrap" }}>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <div style={{ display: "grid", placeItems: "center", width: 46, height: 46, borderRadius: 14, background: "rgba(255,255,255,0.18)" }}><CowMark size={30} tone="white" /></div>
            <div>
              <div style={{ fontSize: 20, fontWeight: 800, letterSpacing: -0.3 }}>NgoroFarm</div>
              <div style={{ fontSize: 12, opacity: 0.9 }}>Livestock records · Nairutia, Kenya</div>
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 26, fontWeight: 800, letterSpacing: 2 }}>INVOICE</div>
            <div style={{ fontSize: 12, opacity: 0.92, marginTop: 2 }}>{invNo}</div>
          </div>
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: "26px 32px" }}>
        <div className="grid sm:grid-cols-2 gap-3">
          <div style={{ background: soft, border: `1px solid ${line}`, borderRadius: 12, padding: 14 }}>
            <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, color: sub, marginBottom: 8 }}>Bill to</div>
            {billTo}
          </div>
          <div style={{ background: soft, border: `1px solid ${line}`, borderRadius: 12, padding: 14 }}>
            <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, color: sub, marginBottom: 8 }}>Details</div>
            {details}
          </div>
        </div>

        <div className="mt-5 overflow-x-auto">
          <table className="w-full" style={{ minWidth: 480, borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: green, color: "#fff" }}>
                <th style={{ textAlign: "left", padding: "9px 12px", fontWeight: 600 }}>Description</th>
                <th style={{ textAlign: "center", padding: "9px 12px", fontWeight: 600 }}>Qty</th>
                <th style={{ textAlign: "right", padding: "9px 12px", fontWeight: 600 }}>Unit price</th>
                <th style={{ textAlign: "right", padding: "9px 12px", fontWeight: 600 }}>Amount</th>
              </tr>
            </thead>
            <tbody>
              {items.map((it, i) => (
                <tr key={i} style={{ background: i % 2 ? "#fafafa" : "#fff", borderBottom: `1px solid ${line}` }}>
                  <td style={{ padding: "11px 12px" }}>
                    <div style={{ fontWeight: 600, color: ink }}>{it.title}</div>
                    {it.subtitle && <div style={{ fontSize: 12, color: sub }}>{it.subtitle}</div>}
                  </td>
                  <td style={{ textAlign: "center", padding: "11px 12px", color: ink }}>{it.qty}</td>
                  <td style={{ textAlign: "right", padding: "11px 12px", color: ink }}>{it.unit}</td>
                  <td style={{ textAlign: "right", padding: "11px 12px", fontWeight: 600, color: ink }}>{it.amount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-end mt-5">
          <div style={{ width: 280 }}>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 2px", fontSize: 14, color: ink }}><span style={{ color: sub }}>Subtotal</span><span>{money(subtotal)}</span></div>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 2px", fontSize: 14, color: ink }}><span style={{ color: sub }}>VAT (16%)</span><span>{money(vat)}</span></div>
            {extra}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8, background: green, color: "#fff", borderRadius: 12, padding: "12px 16px" }}>
              <span style={{ fontSize: 13, fontWeight: 600, opacity: 0.92 }}>Total due</span>
              <span style={{ fontSize: 20, fontWeight: 800 }}>{money(total)}</span>
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-8 mt-8">
          {["Authorized by (NgoroFarm)", "Received by (Buyer)"].map((s) => (
            <div key={s}>
              <div style={{ height: 1, background: "#d1d5db", marginBottom: 6, marginTop: 18 }} />
              <div style={{ fontSize: 11, color: sub }}>{s}</div>
            </div>
          ))}
        </div>

        <div style={{ height: 1, background: line, margin: "22px 0 14px" }} />
        <div style={{ fontSize: 12, color: sub }}>{footerNote}</div>
      </div>
    </div>
  );
}

function Invoice({ t, animals, cart, go }) {
  const items = cart.map((id) => animals.find((a) => a.id === id)).filter(Boolean);
  const subtotal = items.reduce((s, a) => s + (a.value || 0), 0);
  const vat = Math.round(subtotal * 0.16);
  const grand = subtotal + vat;

  const [buyer, setBuyer] = useState("");
  const [customBuyer, setCustomBuyer] = useState("");
  const [phone, setPhone] = useState("");
  const [invNo] = useState(() => "INV-2026-" + Math.floor(1000 + Math.random() * 9000));
  const due = "2026-08-20";
  const BUYERS = ["Nyeri Livestock Market", "Karatina Cattle Auction", "Dagoretti Market", "Kenya Meat Commission", "Mwea Farmers SACCO", "Individual buyer", "Other…"];

  // Fixed "paper" palette so the invoice reads like a real document in any theme.
  const ink = "#1c1917", sub = "#78716c", line = "#e7e5e4", green = "#15803d";
  const paperInput = { border: `1px solid ${line}`, borderRadius: 8, padding: "6px 10px", fontSize: 14, color: ink, outline: "none", width: "100%", background: "#fff" };

  if (items.length === 0) return (
    <div className="space-y-5">
      <Head t={t} title="Invoice" sub="Generated from your cart" />
      <Card t={t}><div className="flex flex-col items-center text-center py-10">
        <span className="grid place-items-center w-14 h-14 rounded-full mb-3" style={tint("emerald")}><FileText size={24} /></span>
        <div className={`font-semibold ${t.strong}`}>Nothing to invoice</div>
        <div className={`text-sm ${t.muted} mt-1`}>Add animals to the cart first.</div>
        <button onClick={() => go("animals")} className="mt-4 flex items-center gap-1.5 px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700"><Beef size={16} /> Go to register</button>
      </div></Card>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <button onClick={() => go("cart")} className={`text-sm ${t.muted} flex items-center gap-1 hover:underline`}><ChevronRight size={14} className="rotate-180" /> Back to cart</button>
        <button onClick={() => window.print()} className="flex items-center gap-1.5 px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700"><Printer size={16} /> Print / Save PDF</button>
      </div>

      {/* Paper */}
      <InvoiceDoc
        invNo={invNo}
        subtotal={subtotal} vat={vat} total={grand}
        billTo={<>
          <select style={paperInput} value={buyer} onChange={(e) => setBuyer(e.target.value)}>
            <option value="">Select buyer…</option>
            {BUYERS.map((b) => <option key={b} value={b}>{b}</option>)}
          </select>
          {buyer === "Other…" && <input style={{ ...paperInput, marginTop: 8 }} value={customBuyer} onChange={(e) => setCustomBuyer(e.target.value)} placeholder="Enter buyer name" />}
          <input style={{ ...paperInput, marginTop: 8 }} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone / M-Pesa number" />
        </>}
        details={<>
          <IRow k="Issued" v={TODAY} />
          <IRow k="Due" v={due} />
          <div style={{ height: 1, background: line, margin: "8px 0" }} />
          <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, color: sub, marginBottom: 4 }}>Pay to</div>
          <div style={{ fontSize: 13, color: ink }}>M-Pesa Paybill <b>4••••2</b></div>
          <div style={{ fontSize: 13, color: ink }}>Account: {invNo}</div>
        </>}
        items={items.map((a) => ({ title: `${a.name} · ${a.id}`, subtitle: `${a.breed} · ${a.sex === "M" ? "Male" : "Female"} · ${ageOf(a.dob)}`, qty: 1, unit: money(a.value), amount: money(a.value) }))}
        footerNote={<><b style={{ color: ink }}>Terms:</b> Payment due by {due}. Animals released on cleared payment. Livestock sold as seen; movement permit issued on dispatch.<span style={{ display: "block", marginTop: 6 }}>Thank you for your business — NgoroFarm, Nairutia.</span></>}
      />

      <p className={`text-xs ${t.muted} text-center`}>{items.length} line item{items.length === 1 ? "" : "s"} · generated from your cart · VAT at Kenya's 16% standard rate.</p>
    </div>
  );
}

/* ================================================================== */
/*  Cart — animals selected, with running total                       */
/* ================================================================== */
function Cart({ t, animals, cart, toggleCart, clearCart, go, openCheckout }) {
  const items = cart.map((id) => animals.find((a) => a.id === id)).filter(Boolean);
  const subtotal = items.reduce((s, a) => s + (a.value || 0), 0);
  const VAT_RATE = 0.16;                               // Kenya standard VAT
  const vat = Math.round(subtotal * VAT_RATE);
  const grand = subtotal + vat;

  return (
    <div className="space-y-5">
      <Head t={t} title="Cart" sub="Animals selected — review and total up"
        action={items.length > 0 ? <button onClick={clearCart} className={`flex items-center gap-1.5 px-3 h-10 rounded-lg text-sm font-medium border ${t.border} ${t.muted} ${t.hover}`}><Trash2 size={15} /> Clear</button> : null} />

      {items.length === 0 ? (
        <Card t={t}>
          <div className="flex flex-col items-center text-center py-10">
            <span className="grid place-items-center w-14 h-14 rounded-full mb-3" style={tint("emerald")}><ShoppingCart size={24} /></span>
            <div className={`font-semibold ${t.strong}`}>Your cart is empty</div>
            <div className={`text-sm ${t.muted} mt-1`}>Add animals from the register to total up their value.</div>
            <button onClick={() => go("animals")} className="mt-4 flex items-center gap-1.5 px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700"><Beef size={16} /> Go to register</button>
          </div>
        </Card>
      ) : (
        <div className="grid lg:grid-cols-3 gap-4">
          <Card t={t} className="lg:col-span-2">
            <CardTitle t={t} icon={ShoppingCart} title={`${items.length} animal${items.length === 1 ? "" : "s"} in cart`} />
            <div className="space-y-2">
              {items.map((a) => (
                <div key={a.id} className={`flex items-center gap-3 p-3 rounded-xl border ${t.border}`}>
                  <div className="grid place-items-center w-11 h-11 rounded-lg text-xl" style={{ backgroundColor: TONE.emerald + "1a" }}>{SPECIES[a.sp]}</div>
                  <button onClick={() => go("animals")} className="min-w-0 flex-1 text-left">
                    <div className={`text-sm font-semibold ${t.strong} truncate`}>{a.name} <span className={`font-normal ${t.muted}`}>· {a.id}</span></div>
                    <div className={`text-xs ${t.muted}`}>{a.breed} · {a.sex === "M" ? "Male" : "Female"}</div>
                  </button>
                  <div className={`text-sm font-bold ${t.strong} shrink-0`}>{money(a.value)}</div>
                  <button onClick={() => toggleCart(a.id)} title="Remove" className={`grid place-items-center w-8 h-8 rounded-lg border ${t.border} ${t.chip} shrink-0`} style={{ color: TONE.rose }}><Minus size={15} /></button>
                </div>
              ))}
            </div>
          </Card>

          <Card t={t}>
            <CardTitle t={t} icon={Receipt} title="Summary" />
            <div className={`rounded-xl border ${t.border} ${t.chip} divide-y ${t.divide}`}>
              <Row t={t} k="Animals" v={String(items.length)} />
              <Row t={t} k="Subtotal" v={money(subtotal)} />
              <Row t={t} k="VAT (16%)" v={money(vat)} />
              <Row t={t} k="Avg / animal" v={money(Math.round(subtotal / items.length))} />
            </div>
            <div className="flex items-center justify-between mt-3 px-1">
              <span className={`text-sm font-medium ${t.strong}`}>Total (incl. VAT)</span>
              <span className="text-xl font-bold" style={{ color: TONE.emerald }}>{money(grand)}</span>
            </div>
            <button onClick={() => go("invoice")} className="mt-4 w-full flex items-center justify-center gap-2 h-11 rounded-xl bg-emerald-600 text-white text-sm font-semibold shadow-sm hover:bg-emerald-700">
              <FileText size={17} /> Generate invoice
            </button>
            <button onClick={openCheckout} className={`mt-2 w-full flex items-center justify-center gap-2 h-10 rounded-xl text-sm font-medium border ${t.border} ${t.strong} ${t.hover}`}>
              <Truck size={16} /> Check out these animals
            </button>
          </Card>
        </div>
      )}
    </div>
  );
}

function Register({ t, query, sel, setSel, animals, setAnimals, admin, cart, toggleCart, spFilter, setSp }) {
  const [form, setForm]     = useState(null);   // null | "new" | animal object (edit)
  const [toDelete, setDel]  = useState(null);   // animal pending deletion
  const [flash, setFlash]   = useState(null);   // transient confirmation banner
  const [stFilter, setSt]   = useState("all");  // status filter
  const [sort, setSort]     = useState("name"); // sort key

  const idIndex = useMemo(() => Object.fromEntries(animals.map((a) => [a.id, a])), [animals]);
  const species = useMemo(() => [...new Set(animals.map((a) => a.sp))], [animals]);
  const statuses = useMemo(() => [...new Set(animals.map((a) => a.status))], [animals]);
  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    const arr = animals.filter((a) =>
      (!q || [a.name, a.id, a.breed, a.sp, a.status].join(" ").toLowerCase().includes(q)) &&
      (spFilter === "all" || a.sp === spFilter) &&
      (stFilter === "all" || a.status === stFilter));
    const cmp = {
      name:   (a, b) => a.name.localeCompare(b.name),
      age:    (a, b) => (a.dob < b.dob ? -1 : a.dob > b.dob ? 1 : 0),
      weight: (a, b) => (b.wt || 0) - (a.wt || 0),
      value:  (a, b) => (b.value || 0) - (a.value || 0),
    }[sort];
    return [...arr].sort(cmp);
  }, [query, spFilter, stFilter, sort, animals]);

  const activeCount = animals.filter((a) => a.status === "Active").length;
  const herdValue = animals.reduce((s, a) => s + (a.value || 0), 0);

  const note = (msg) => { setFlash(msg); setTimeout(() => setFlash(null), 2600); };
  const save = (data) => {
    setAnimals((prev) => {
      const exists = prev.some((x) => x.id === data.id);
      return exists ? prev.map((x) => (x.id === data.id ? data : x)) : [...prev, data];
    });
    note(form === "new" ? `${data.name} registered (${data.id})` : `${data.name} updated`);
    setForm(null);
  };
  const remove = (a) => {
    setAnimals((prev) => prev.filter((x) => x.id !== a.id));
    setDel(null); setSel(null);
    note(`${a.name} (${a.id}) removed from register`);
  };

  const animal = sel ? idIndex[sel] : null;
  if (animal) return (
    <>
      <Profile t={t} a={animal} admin={admin} back={() => setSel(null)}
        onEdit={() => setForm(animal)} onDelete={() => setDel(animal)}
        inCart={cart.includes(animal.id)} toggleCart={() => toggleCart(animal.id)} />
      {form && <AnimalForm t={t} mode={form === "new" ? "new" : "edit"} initial={form === "new" ? null : form}
        animals={animals} onCancel={() => setForm(null)} onSave={save} />}
      {toDelete && <Confirm t={t} animal={toDelete} onCancel={() => setDel(null)} onConfirm={() => remove(toDelete)} />}
    </>
  );

  return (
    <div className="space-y-5">
      <Head t={t} title="Animal register" sub="Search, filter and sort your herd"
        action={<button onClick={() => setForm("new")} className="flex items-center gap-1.5 px-3.5 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700"><Plus size={16}/> Register animal</button>} />

      {flash && (
        <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium" style={tint("emerald")}>
          <CircleCheck size={16} /> {flash}
        </div>
      )}

      {/* Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Stat t={t} label="Total animals" value={String(animals.length)} sub={`${species.length} species`} icon={Beef} tone="emerald" />
        <Stat t={t} label="Active" value={String(activeCount)} sub={`${animals.length - activeCount} exited`} icon={CircleCheck} tone="lime" />
        <Stat t={t} label="Females" value={String(animals.filter((a) => a.sex === "F").length)} sub={`${animals.filter((a) => a.sex === "M").length} males`} icon={HeartPulse} tone="rose" />
        <Stat t={t} label="Herd value" value={money(herdValue)} sub="live valuation" icon={Wallet} tone="sky" />
      </div>

      {/* Filter + sort toolbar */}
      <Card t={t}>
        <div className="flex flex-wrap items-center gap-2 justify-between">
          <div className="flex flex-wrap gap-1.5">
            {["all", ...species].map((sp) => {
              const on = spFilter === sp;
              const count = sp === "all" ? animals.length : animals.filter((a) => a.sp === sp).length;
              return (
                <button key={sp} onClick={() => setSp(sp)}
                  className={`flex items-center gap-1.5 px-2.5 h-8 rounded-lg text-xs font-medium border ${t.border} ${on ? "text-white shadow-sm" : `${t.chip} ${t.strong}`}`}
                  style={on ? { backgroundColor: TONE.emerald, borderColor: TONE.emerald } : undefined}>
                  {sp === "all" ? "All" : <>{SPECIES[sp]} <span className="capitalize">{sp}</span></>}
                  <span className={on ? "opacity-80" : t.muted}>{count}</span>
                </button>
              );
            })}
          </div>
          <div className="flex items-center gap-2">
            <select value={stFilter} onChange={(e) => setSt(e.target.value)} className={`h-8 px-2 rounded-lg text-xs font-medium outline-none border ${t.border} ${t.input} ${t.strong}`}>
              <option value="all">All statuses</option>
              {statuses.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
            <select value={sort} onChange={(e) => setSort(e.target.value)} className={`h-8 px-2 rounded-lg text-xs font-medium outline-none border ${t.border} ${t.input} ${t.strong}`}>
              <option value="name">Sort: Name</option>
              <option value="age">Sort: Oldest</option>
              <option value="weight">Sort: Weight</option>
              <option value="value">Sort: Value</option>
            </select>
          </div>
        </div>
      </Card>

      <div className={`text-xs ${t.muted}`}>Showing {list.length} of {animals.length} animals</div>

      {list.length === 0 ? (
        <Card t={t}><Empty t={t} msg="No animals match these filters. Try clearing the search or filters." /></Card>
      ) : (
        <div className="space-y-2">
          {list.map((a) => (
            <div key={a.id} className={`group flex items-center gap-3 p-3 rounded-xl border ${t.border} ${t.card} ${t.hover} transition-colors`}>
              <button onClick={() => setSel(a.id)} className="flex items-center gap-3 flex-1 min-w-0 text-left">
                <div className="grid place-items-center w-11 h-11 rounded-lg text-xl shrink-0" style={{ backgroundColor: TONE.emerald + "1a" }}>{SPECIES[a.sp]}</div>
                <div className="min-w-0 flex-1">
                  <div className={`font-semibold ${t.strong} flex items-center gap-2`}><span className="truncate">{a.name}</span><StatusDot status={a.status} /></div>
                  <div className={`text-xs ${t.muted} truncate`}>{a.id} · {a.breed}</div>
                </div>
                <div className="hidden md:flex items-center gap-6 shrink-0 mr-2">
                  <div className="text-right"><div className={`text-xs ${t.muted}`}>Sex</div><div className={`text-sm ${t.strong}`}>{a.sex === "M" ? "Male" : "Female"}</div></div>
                  <div className="text-right"><div className={`text-xs ${t.muted}`}>Age</div><div className={`text-sm ${t.strong}`}>{ageOf(a.dob)}</div></div>
                  <div className="text-right"><div className={`text-xs ${t.muted}`}>Weight</div><div className={`text-sm nf-num ${t.strong}`}>{a.wt} kg</div></div>
                </div>
              </button>
              <div className={`text-sm font-bold ${t.strong} shrink-0 w-24 text-right hidden sm:block`}>{money(a.value)}</div>
              <button onClick={() => toggleCart(a.id)} title={cart.includes(a.id) ? "In cart" : "Add to cart"}
                className={`flex items-center gap-1.5 px-2.5 h-8 rounded-lg text-xs font-semibold border shrink-0 ${t.border} ${cart.includes(a.id) ? "text-white" : `${t.chip} ${t.strong}`}`}
                style={cart.includes(a.id) ? { backgroundColor: TONE.emerald, borderColor: TONE.emerald } : undefined}>
                {cart.includes(a.id) ? <CircleCheck size={13} /> : <ShoppingCart size={13} />}<span className="hidden sm:inline">{cart.includes(a.id) ? "In cart" : "Add"}</span>
              </button>
              {admin && (
                <div className="flex gap-1 shrink-0 opacity-60 sm:opacity-0 sm:group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                  <button onClick={() => setForm(a)} title="Edit" className={`grid place-items-center w-8 h-8 rounded-lg border ${t.border} ${t.chip}`} style={{ color: TONE.sky }}><Pencil size={13} /></button>
                  <button onClick={() => setDel(a)} title="Delete" className={`grid place-items-center w-8 h-8 rounded-lg border ${t.border} ${t.chip}`} style={{ color: TONE.rose }}><Trash2 size={13} /></button>
                </div>
              )}
              <ChevronRight size={16} className={`${t.muted} shrink-0 hidden sm:block`} />
            </div>
          ))}
        </div>
      )}

      {form && <AnimalForm t={t} mode={form === "new" ? "new" : "edit"} initial={form === "new" ? null : form}
        animals={animals} onCancel={() => setForm(null)} onSave={save} />}
      {toDelete && <Confirm t={t} animal={toDelete} onCancel={() => setDel(null)} onConfirm={() => remove(toDelete)} />}
    </div>
  );
}

/* ---- Create / edit form (admin only) ------------------------------ */
const BLANK = { id:"", name:"", sp:"cattle", breed:"", sex:"F", dob:"", wt:0, status:"Active", origin:"Born on farm", price:0, value:0, momId:null, dadId:null, role:"", rfid:"" };
const SP_LETTER = { cattle:"C", goat:"G", sheep:"S", pig:"P", poultry:"K" };
function AnimalForm({ t, mode, initial, animals, onCancel, onSave }) {
  const [f, setF]   = useState(initial ? { rfid:"", ...initial } : { ...BLANK });
  const [err, setErr] = useState("");
  const [reader, setReader] = useState("USB");   // RFID reader source
  const [scan, setScan]     = useState("idle");  // idle | scanning | done
  const [cam, setCam]       = useState(false);   // camera scanner open
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const dams  = animals.filter((a) => a.sex === "F");
  const sires = animals.filter((a) => a.sex === "M");

  const nextMgmtId = (sp) => {
    const letter = SP_LETTER[sp] || "X";
    const nums = animals.map((a) => { const m = /^NG-[A-Z]-(\d+)$/.exec(a.id); return m ? +m[1] : 0; });
    const n = Math.max(100, ...nums) + 1;
    return `NG-${letter}-${String(n).padStart(3, "0")}`;
  };
  const genRfid = () => {
    let r;
    do { r = "900" + String(Math.floor(Math.random() * 1e12)).padStart(12, "0"); }
    while (animals.some((a) => a.rfid === r));
    return r;
  };
  const runScan = () => {
    setErr(""); setScan("scanning");
    setTimeout(() => {
      const rfid = genRfid();
      setF((p) => ({ ...p, rfid, id: p.id?.trim() ? p.id : nextMgmtId(p.sp) }));
      setScan("done");
    }, 1400);
  };

  const submit = () => {
    const id = f.id.trim(), name = f.name.trim();
    if (!id || !name) { setErr("Tag ID and name are required."); return; }
    if (mode === "new" && animals.some((a) => a.id === id)) { setErr(`Tag ${id} already exists.`); return; }
    onSave({ ...f, id, name,
      wt: Number(f.wt) || 0, price: Number(f.price) || 0, value: Number(f.value) || 0,
      momId: f.momId || null, dadId: f.dadId || null });
  };

  const field = "w-full h-10 px-3 rounded-lg text-sm outline-none border " + t.border + " " + t.input + " " + t.strong;
  const lbl   = `text-xs font-medium ${t.muted} mb-1 block`;

  return (
    <Modal t={t} onCancel={onCancel} title={mode === "new" ? "Register animal" : `Edit ${initial.name}`}
      icon={mode === "new" ? Plus : Pencil}
      footer={
        <>
          <button onClick={onCancel} className={`px-4 h-10 rounded-lg text-sm font-medium border ${t.border} ${t.muted} ${t.hover}`}>Cancel</button>
          <button onClick={submit} className="flex items-center gap-1.5 px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700"><Save size={15}/> {mode === "new" ? "Register" : "Save changes"}</button>
        </>
      }>
      {err && <div className="mb-3 px-3 py-2 rounded-lg text-sm" style={tint("rose")}>{err}</div>}

      {/* RFID capture */}
      <div className={`mb-4 p-3.5 rounded-xl border ${t.border} ${t.chip}`}>
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <span className="grid place-items-center w-8 h-8 rounded-lg" style={tint("sky")}><Radio size={16}/></span>
            <div className="leading-tight">
              <div className={`text-sm font-semibold ${t.strong}`}>RFID tag capture</div>
              <div className={`text-xs ${t.muted}`}>Scan the animal's ear tag to register it</div>
            </div>
          </div>
          <div className={`flex gap-1 p-1 rounded-lg ${t.input} border ${t.border}`}>
            {["USB","Bluetooth","NFC"].map((r) => (
              <button key={r} onClick={() => setReader(r)} disabled={scan==="scanning"}
                className={`text-xs px-2 py-1 rounded-md font-medium ${reader===r ? "text-white shadow-sm" : t.muted}`}
                style={reader===r ? { backgroundColor: TONE.sky } : undefined}>{r}</button>
            ))}
          </div>
        </div>

        {scan === "scanning" ? (
          <div className={`flex items-center gap-3 h-11 px-3 rounded-lg border ${t.border} ${t.input}`}>
            <span className="relative grid place-items-center w-6 h-6">
              <span className="absolute inline-flex w-6 h-6 rounded-full opacity-60 animate-ping" style={{ backgroundColor: TONE.sky + "55" }} />
              <Radio size={16} style={{ color: TONE.sky }} className="animate-pulse" />
            </span>
            <span className={`text-sm ${t.strong}`}>Scanning via {reader} reader…</span>
          </div>
        ) : f.rfid ? (
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 flex-1 h-11 px-3 rounded-lg" style={tint("emerald")}>
              <CircleCheck size={16}/>
              <span className="text-sm font-medium">Tag captured</span>
              <span className="text-sm font-mono ml-auto tracking-wide">{f.rfid}</span>
            </div>
            <button onClick={runScan} className={`h-11 px-3 rounded-lg text-sm font-medium border ${t.border} ${t.muted} ${t.hover} shrink-0`}>Re-scan</button>
          </div>
        ) : (
          <button onClick={runScan} className="w-full flex items-center justify-center gap-2 h-11 rounded-lg text-white text-sm font-semibold shadow-sm" style={{ backgroundColor: TONE.sky }}>
            <ScanLine size={17}/> Scan RFID tag
          </button>
        )}

        <button onClick={() => setCam(true)} className={`mt-2 w-full flex items-center justify-center gap-2 h-10 rounded-lg text-sm font-medium border ${t.border} ${t.strong} ${t.hover}`}>
          <Camera size={16}/> Scan QR / barcode with camera
        </button>
      </div>

      <div className="grid sm:grid-cols-2 gap-3">
        <div><label className={lbl}>Management tag ID{f.rfid && <span className={t.muted}> · from scan, editable</span>}</label>
          <input className={field} disabled={mode === "edit"} value={f.id} onChange={(e)=>set("id", e.target.value)} placeholder="Scan a tag or type e.g. NG-C-103" />
        </div>
        <div><label className={lbl}>RFID / EPC number</label>
          <input className={`${field} font-mono`} value={f.rfid || ""} onChange={(e)=>set("rfid", e.target.value)} placeholder="Captured on scan" />
        </div>
        <div><label className={lbl}>Name</label>
          <input className={field} value={f.name} onChange={(e)=>set("name", e.target.value)} placeholder="Amani" />
        </div>
        <div><label className={lbl}>Species</label>
          <select className={field} value={f.sp} onChange={(e)=>set("sp", e.target.value)}>{Object.keys(SPECIES).map((s)=><option key={s} value={s}>{s}</option>)}</select>
        </div>
        <div><label className={lbl}>Breed</label>
          <input className={field} value={f.breed} onChange={(e)=>set("breed", e.target.value)} placeholder="Friesian cross" />
        </div>
        <div><label className={lbl}>Sex</label>
          <select className={field} value={f.sex} onChange={(e)=>set("sex", e.target.value)}><option value="F">Female</option><option value="M">Male</option></select>
        </div>
        <div><label className={lbl}>Date of birth</label>
          <input type="date" className={field} value={f.dob} onChange={(e)=>set("dob", e.target.value)} />
        </div>
        <div><label className={lbl}>Weight (kg)</label>
          <input type="number" className={field} value={f.wt} onChange={(e)=>set("wt", e.target.value)} />
        </div>
        <div><label className={lbl}>Status</label>
          <select className={field} value={f.status} onChange={(e)=>set("status", e.target.value)}>{["Active","Sold","Dead","Missing"].map((s)=><option key={s} value={s}>{s}</option>)}</select>
        </div>
        <div><label className={lbl}>Origin</label>
          <select className={field} value={f.origin} onChange={(e)=>set("origin", e.target.value)}><option>Born on farm</option><option>Purchased</option><option>Donated</option></select>
        </div>
        <div><label className={lbl}>Role / class</label>
          <input className={field} value={f.role} onChange={(e)=>set("role", e.target.value)} placeholder="Milking heifer" />
        </div>
        <div><label className={lbl}>Purchase price (KES)</label>
          <input type="number" className={field} value={f.price} onChange={(e)=>set("price", e.target.value)} />
        </div>
        <div><label className={lbl}>Current value (KES)</label>
          <input type="number" className={field} value={f.value} onChange={(e)=>set("value", e.target.value)} />
        </div>
        <div><label className={lbl}>Dam (mother)</label>
          <select className={field} value={f.momId || ""} onChange={(e)=>set("momId", e.target.value || null)}>
            <option value="">— none / external —</option>
            {dams.filter((d)=>d.id!==f.id).map((d)=><option key={d.id} value={d.id}>{d.name} ({d.id})</option>)}
          </select>
        </div>
        <div><label className={lbl}>Sire (father)</label>
          <select className={field} value={f.dadId || ""} onChange={(e)=>set("dadId", e.target.value || null)}>
            <option value="">— none / external —</option>
            {sires.filter((s)=>s.id!==f.id).map((s)=><option key={s.id} value={s.id}>{s.name} ({s.id})</option>)}
          </select>
        </div>
      </div>
      {cam && <CameraScanner t={t} title="Scan animal tag"
        hint="Point the camera at the QR / barcode on the ear tag."
        onClose={() => setCam(false)}
        onDetect={(value) => { setCam(false); setScan("done");
          setF((p) => ({ ...p, rfid: value, id: p.id?.trim() ? p.id : nextMgmtId(p.sp) })); }} />}
    </Modal>
  );
}
function Confirm({ t, animal, onCancel, onConfirm }) {
  return (
    <Modal t={t} onCancel={onCancel} title="Delete animal" icon={Trash2} tone="rose" narrow
      footer={
        <>
          <button onClick={onCancel} className={`px-4 h-10 rounded-lg text-sm font-medium border ${t.border} ${t.muted} ${t.hover}`}>Cancel</button>
          <button onClick={onConfirm} className="flex items-center gap-1.5 px-4 h-10 rounded-lg bg-rose-600 text-white text-sm font-medium shadow-sm hover:bg-rose-700"><Trash2 size={15}/> Delete permanently</button>
        </>
      }>
      <p className={`text-sm ${t.strong}`}>Remove <b>{animal.name}</b> ({animal.id}) from the register?</p>
      <p className={`text-sm ${t.muted} mt-1`}>This deletes the animal and detaches it from any pedigree links. In production this would be a soft-delete written to the audit log, reversible by an Auditor.</p>
    </Modal>
  );
}

/* ---- Generic modal shell ------------------------------------------ */
function Modal({ t, title, icon: Icon, tone = "emerald", narrow, footer, onCancel, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-4 overflow-y-auto" style={{ backgroundColor: "rgba(0,0,0,0.5)" }} onClick={onCancel}>
      <div onClick={(e)=>e.stopPropagation()} className={`w-full ${narrow ? "max-w-md" : "max-w-2xl"} my-8 rounded-2xl border ${t.border} ${t.card} shadow-xl flex flex-col`} style={{ maxHeight: "calc(100vh - 4rem)" }}>
        <div className={`flex items-center gap-2 px-5 h-14 border-b ${t.border} shrink-0`}>
          <span className="grid place-items-center w-8 h-8 rounded-lg" style={tint(tone)}><Icon size={16} /></span>
          <h3 className={`font-semibold ${t.strong}`}>{title}</h3>
          <button onClick={onCancel} className={`ml-auto ${t.muted} ${t.hover} w-8 h-8 grid place-items-center rounded-lg`}><X size={18} /></button>
        </div>
        <div className="p-5 overflow-y-auto">{children}</div>
        <div className={`flex justify-end gap-2 px-5 py-3.5 border-t ${t.border} shrink-0`}>{footer}</div>
      </div>
    </div>
  );
}

/* ---- Mobile camera scanner (QR / barcode) ------------------------- */
function CameraScanner({ t, title = "Camera scanner", hint, onClose, onDetect }) {
  const videoRef  = useRef(null);
  const streamRef = useRef(null);
  const rafRef    = useRef(0);
  const doneRef   = useRef(false);
  const [status, setStatus] = useState("starting"); // starting | scanning | error
  const [live, setLive]     = useState(false);       // on-device detection running
  const [msg, setMsg]       = useState("");
  const [manual, setManual] = useState("");

  const stop = () => {
    cancelAnimationFrame(rafRef.current);
    if (streamRef.current) streamRef.current.getTracks().forEach((tr) => tr.stop());
    streamRef.current = null;
  };
  const finish = (value) => {
    if (doneRef.current) return;
    doneRef.current = true; stop(); onDetect(String(value).trim());
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw { name: "Unsupported" };
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false });
        if (cancelled) { stream.getTracks().forEach((tr) => tr.stop()); return; }
        streamRef.current = stream;
        const v = videoRef.current;
        if (v) { v.srcObject = stream; await v.play().catch(() => {}); }
        setStatus("scanning");
        if ("BarcodeDetector" in window) {
          setLive(true);
          const det = new window.BarcodeDetector({ formats: ["qr_code","code_128","ean_13","ean_8","code_39","data_matrix","itf","codabar"] });
          const tick = async () => {
            if (cancelled || doneRef.current) return;
            const vv = videoRef.current;
            if (vv && vv.readyState >= 2) {
              try { const codes = await det.detect(vv); if (codes && codes.length) return finish(codes[0].rawValue); } catch {}
            }
            rafRef.current = requestAnimationFrame(tick);
          };
          rafRef.current = requestAnimationFrame(tick);
        } else {
          setLive(false);
          setMsg("Camera is live, but this browser can't auto-read codes. Read the number off the tag and type it below.");
        }
      } catch (e) {
        setStatus("error");
        const n = e && e.name;
        setMsg(
          n === "NotAllowedError" ? "Camera access was blocked. Allow the camera in your browser, or type the tag code below."
          : n === "NotFoundError" ? "No camera found on this device. Type the tag code below."
          : "Camera isn't available in this preview. Open NgoroFarm on a phone (or a window with camera access) to scan — or type the code below."
        );
      }
    })();
    return () => { cancelled = true; stop(); };
  }, []);

  return (
    <div className="fixed inset-0 flex items-center justify-center p-4" style={{ backgroundColor: "rgba(0,0,0,0.8)", zIndex: 60 }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className={`w-full max-w-md rounded-2xl overflow-hidden border ${t.border} ${t.card} shadow-xl`}>
        <div className={`flex items-center gap-2 px-4 h-14 border-b ${t.border}`}>
          <span className="grid place-items-center w-8 h-8 rounded-lg" style={tint("sky")}><Camera size={16} /></span>
          <h3 className={`font-semibold ${t.strong}`}>{title}</h3>
          <button onClick={onClose} className={`ml-auto ${t.muted} ${t.hover} w-8 h-8 grid place-items-center rounded-lg`}><X size={18} /></button>
        </div>

        <div className="relative bg-black" style={{ aspectRatio: "1 / 1" }}>
          <video ref={videoRef} muted autoPlay playsInline className="w-full h-full" style={{ objectFit: "cover" }} />
          {status === "scanning" ? (
            <>
              <div className="absolute inset-0 grid place-items-center pointer-events-none">
                <div className="rounded-2xl" style={{ width: "64%", height: "64%", boxShadow: "0 0 0 100vmax rgba(0,0,0,0.4)", border: "2px solid rgba(255,255,255,0.9)" }} />
              </div>
              {live && <div className="absolute left-6 right-6 h-0.5 animate-pulse" style={{ top: "50%", backgroundColor: TONE.sky }} />}
            </>
          ) : (
            <div className="absolute inset-0 grid place-items-center p-6 text-center">
              <div>
                <Camera size={40} className="mx-auto mb-2" style={{ color: "rgba(255,255,255,0.5)" }} />
                <p className="text-sm" style={{ color: "rgba(255,255,255,0.8)" }}>{status === "starting" ? "Starting camera…" : "Camera unavailable"}</p>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 space-y-3">
          <p className={`text-xs ${t.muted}`}>{msg || hint || "Point the rear camera at the QR code or barcode on the ear tag."}</p>
          <div className="flex gap-2">
            <input value={manual} onChange={(e) => setManual(e.target.value)} placeholder="Or type the tag code"
              className={`flex-1 h-10 px-3 rounded-lg text-sm outline-none border ${t.border} ${t.input} ${t.strong} font-mono`} />
            <button onClick={() => manual.trim() && finish(manual)} className="px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700">Use</button>
          </div>
          <button onClick={() => finish("900" + String(Math.floor(Math.random() * 1e12)).padStart(12, "0"))}
            className={`w-full h-9 rounded-lg text-xs font-medium border ${t.border} ${t.muted} ${t.hover}`}>Simulate a tag (demo)</button>
        </div>
      </div>
    </div>
  );
}

/* ---- Sign-in screen ----------------------------------------------- */
function Login({ t, dark, setDark, onLogin, framed }) {
  const [role, setRole]   = useState("manager");
  const [email, setEmail] = useState("manager@ngorofarm.co.ke");
  const [pw, setPw]       = useState("ngorofarm");
  const [show, setShow]   = useState(false);
  const [err, setErr]     = useState("");
  const [bio, setBio]     = useState("idle");   // idle | scanning | done
  const bioCancel = useRef(false);

  const bioSupported = typeof window !== "undefined" && !!window.PublicKeyCredential;
  const bioSignIn = async () => {
    setErr(""); bioCancel.current = false; setBio("scanning");
    // Best-effort real platform authenticator (WebAuthn). Sandboxes usually
    // block it, so we fall through to the simulated scan either way.
    try {
      if (window.PublicKeyCredential && navigator.credentials && navigator.credentials.get) {
        const challenge = new Uint8Array(32); crypto.getRandomValues(challenge);
        await Promise.race([
          navigator.credentials.get({ publicKey: { challenge, timeout: 8000, userVerification: "preferred", rpId: location.hostname } }),
          new Promise((res) => setTimeout(res, 1400)),
        ]);
      } else {
        await new Promise((res) => setTimeout(res, 1400));
      }
    } catch { /* unsupported / blocked — continue with demo verification */ }
    if (bioCancel.current) return;
    setBio("done");
    setTimeout(() => { if (!bioCancel.current) onLogin(role); }, 600);
  };
  const cancelBio = () => { bioCancel.current = true; setBio("idle"); };

  const pick = (r) => { setRole(r); setEmail(r === "admin" ? "admin@ngorofarm.co.ke" : "manager@ngorofarm.co.ke"); setErr(""); };
  const submit = () => {
    if (!email.trim() || !pw.trim()) { setErr("Enter your email and password to continue."); return; }
    onLogin(role);
  };
  const onKey = (e) => { if (e.key === "Enter") submit(); };

  const field = `w-full h-11 pl-10 pr-3 rounded-lg text-sm outline-none border ${t.border} ${t.input} ${t.strong}`;
  const brandGrad = "linear-gradient(150deg, #065f46 0%, #15803d 55%, #4d7c0f 100%)";
  const feats = [
    { i: Beef,          txt: "Birth-to-sale herd records" },
    { i: ScanLine,      txt: "RFID & mobile-camera tag scanning" },
    { i: Syringe,       txt: "Vaccination & production logbooks" },
    { i: Truck,         txt: "M-Pesa check-out at point of sale" },
  ];

  return (
    <div className={`${framed ? "min-h-full" : "min-h-screen"} w-full grid lg:grid-cols-2`} style={{ background: t.bg }}>
      {/* Brand panel */}
      <div className="hidden lg:flex flex-col justify-between p-10 text-white relative overflow-hidden" style={{ background: brandGrad }}>
        <div className="absolute -right-10 -bottom-16 opacity-10"><CowMark size={230} tone="white" /></div>
        <div className="relative flex items-center gap-2">
          <div className="grid place-items-center w-10 h-10 rounded-xl" style={{ backgroundColor:"rgba(255,255,255,0.15)" }}><CowMark size={28} tone="white" /></div>
          <div className="leading-tight"><div className="font-bold text-lg tracking-tight">NgoroFarm</div>
            <div className="text-xs flex items-center gap-1" style={{ color:"rgba(255,255,255,0.85)" }}><MapPin size={11}/> Nairutia, Kenya</div></div>
        </div>
        <div className="relative">
          <h2 className="text-3xl font-bold leading-tight">Every animal,<br/>from birth to sale.</h2>
          <p className="mt-3 text-sm max-w-sm" style={{ color:"rgba(255,255,255,0.85)" }}>The digital herd record for the modern Kenyan farm — records, health, breeding and finance in one place.</p>
          <ul className="mt-6 space-y-2.5">
            {feats.map((f) => (
              <li key={f.txt} className="flex items-center gap-2.5 text-sm">
                <span className="grid place-items-center w-7 h-7 rounded-lg" style={{ backgroundColor:"rgba(255,255,255,0.15)" }}><f.i size={14}/></span>{f.txt}
              </li>
            ))}
          </ul>
        </div>
        <div className="relative text-xs" style={{ color:"rgba(255,255,255,0.7)" }}>© 2026 NgoroFarm · Nairutia</div>
      </div>

      {/* Form panel */}
      <div className="flex items-center justify-center p-6 relative">
        <button onClick={() => setDark(!dark)} className={`absolute top-5 right-5 grid place-items-center w-10 h-10 rounded-lg ${t.chip} ${t.hover}`}>
          {dark ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} className="text-stone-600" />}
        </button>

        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2 mb-6">
            <LogoTile size={40} radius={12} />
            <div className="leading-tight"><div className={`font-bold text-lg ${t.strong}`}>NgoroFarm</div>
              <div className="text-xs flex items-center gap-1" style={{ color: TONE.emerald }}><MapPin size={11}/> Nairutia, Kenya</div></div>
          </div>

          <h1 className={`text-2xl font-bold tracking-tight ${t.strong}`}>Sign in</h1>
          <p className={`text-sm ${t.muted} mt-1`}>Welcome back. Choose your role to continue.</p>

          <div className={`flex gap-1 p-1 rounded-xl ${t.chip} mt-5`}>
            {[{k:"manager",label:"Manager",icon:UserCog},{k:"admin",label:"Administrator",icon:ShieldCheck}].map((x)=>(
              <button key={x.k} onClick={()=>pick(x.k)} className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm font-medium transition-colors ${role===x.k ? "bg-emerald-600 text-white shadow-sm" : `${t.muted} ${t.hover}`}`}>
                <x.icon size={15}/> {x.label}
              </button>
            ))}
          </div>

          {err && <div className="mt-4 px-3 py-2 rounded-lg text-sm" style={tint("rose")}>{err}</div>}

          <div className="mt-4 space-y-3">
            <div>
              <label className={`text-xs font-medium ${t.muted} mb-1 block`}>Email</label>
              <div className="relative"><Mail size={16} className={`absolute left-3 top-3.5 ${t.muted}`} />
                <input className={field} value={email} onChange={(e)=>setEmail(e.target.value)} onKeyDown={onKey} placeholder="you@ngorofarm.co.ke" /></div>
            </div>
            <div>
              <label className={`text-xs font-medium ${t.muted} mb-1 block`}>Password</label>
              <div className="relative"><Lock size={16} className={`absolute left-3 top-3.5 ${t.muted}`} />
                <input type={show ? "text" : "password"} className={field} value={pw} onChange={(e)=>setPw(e.target.value)} onKeyDown={onKey} placeholder="••••••••" />
                <button onClick={()=>setShow(!show)} className={`absolute right-3 top-3 ${t.muted}`}>{show ? <EyeOff size={17}/> : <Eye size={17}/>}</button></div>
            </div>
          </div>

          <div className="flex items-center justify-between mt-3 text-xs">
            <label className={`flex items-center gap-2 ${t.muted}`}><input type="checkbox" defaultChecked className="accent-emerald-600" /> Keep me signed in</label>
            <button className="font-medium" style={{ color: TONE.emerald }}>Forgot password?</button>
          </div>

          <button onClick={submit} className="w-full flex items-center justify-center gap-2 h-11 rounded-lg bg-emerald-600 text-white text-sm font-semibold shadow-sm hover:bg-emerald-700 mt-5">
            <LogIn size={17}/> Sign in as {role === "admin" ? "Administrator" : "Manager"}
          </button>

          <div className="flex items-center gap-3 my-4">
            <div className={`flex-1 border-t ${t.border}`} />
            <span className={`text-xs ${t.muted}`}>or</span>
            <div className={`flex-1 border-t ${t.border}`} />
          </div>

          <button onClick={bioSignIn} className={`w-full flex items-center justify-center gap-2 h-11 rounded-lg border ${t.border} ${t.chip} ${t.strong} text-sm font-semibold ${t.hover}`}>
            <Fingerprint size={18} style={{ color: TONE.emerald }} /> Sign in with fingerprint / Face ID
          </button>

          <p className={`text-xs ${t.muted} mt-4 text-center`}>Demo — any email and password works. Your role sets what you can edit.</p>
        </div>
      </div>

      {bio !== "idle" && (
        <Modal t={t} title="Biometric sign-in" icon={Fingerprint} tone="emerald" narrow
          onCancel={bio === "scanning" ? cancelBio : undefined}
          footer={bio === "scanning" ? <button onClick={cancelBio} className={`px-4 h-10 rounded-lg text-sm font-medium border ${t.border} ${t.muted} ${t.hover}`}>Cancel</button> : null}>
          <div className="flex flex-col items-center text-center py-4">
            {bio === "scanning" ? (
              <>
                <span className="relative grid place-items-center w-20 h-20 mb-3">
                  <span className="absolute inline-flex w-20 h-20 rounded-full opacity-60 animate-ping" style={{ backgroundColor: TONE.emerald + "44" }} />
                  <span className="grid place-items-center w-20 h-20 rounded-full" style={tint("emerald")}><Fingerprint size={34} /></span>
                </span>
                <div className={`font-semibold ${t.strong}`}>Verifying your identity…</div>
                <div className={`text-sm ${t.muted} mt-1`}>Touch the fingerprint sensor or look at your device.</div>
                {!bioSupported && <div className={`text-xs ${t.muted} mt-2`}>(No platform authenticator detected — running demo verification.)</div>}
              </>
            ) : (
              <>
                <span className="grid place-items-center w-20 h-20 rounded-full mb-3" style={tint("emerald")}><CircleCheck size={38} /></span>
                <div className={`font-semibold ${t.strong}`}>Verified</div>
                <div className={`text-sm ${t.muted} mt-1`}>Signing you in…</div>
              </>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}

function Profile({ t, a, back, admin, onEdit, onDelete, inCart, toggleCart }) {
  const [tab, setTab] = useState("overview");
  const events = TIMELINE[a.id] || TIMELINE["NG-C-100"];
  const meds = MEDICAL.filter((m) => m.animal === a.id);
  const tabs = ["overview","timeline","medical","documents"];
  return (
    <div className="space-y-5">
      <button onClick={back} className={`text-sm ${t.muted} flex items-center gap-1 hover:underline`}><ChevronRight size={14} className="rotate-180" /> Back to register</button>
      <Card t={t}>
        <div className="flex flex-col sm:flex-row gap-5">
          <div className="grid place-items-center w-24 h-24 rounded-2xl text-6xl shrink-0" style={{ backgroundColor: TONE.emerald + "1a" }}>{SPECIES[a.sp]}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 flex-wrap">
              <h2 className={`text-2xl font-bold tracking-tight ${t.strong}`}>{a.name}</h2>
              <StatusPill status={a.status} />
              <span className={`text-sm ${t.muted}`}>{a.role}</span>
            </div>
            <div className={`mt-1 text-sm ${t.muted}`}>{a.breed} · {a.sex === "M" ? "Male" : "Female"} · born {a.dob} ({ageOf(a.dob)})</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
              <Meta t={t} label="RFID tag" value={a.rfid || a.id.replace(/-/g,"")} />
              <Meta t={t} label="Origin" value={a.origin} />
              <Meta t={t} label="Weight" value={`${a.wt} kg`} />
              <Meta t={t} label="Value" value={money(a.value)} />
            </div>
          </div>
          <div className="flex sm:flex-col gap-2 shrink-0">
            <div className={`grid place-items-center w-20 h-20 rounded-xl border ${t.border} ${t.chip}`}><QrCode size={52} className={t.strong} /></div>
            {admin ? (
              <div className="flex gap-2">
                <button onClick={onEdit} className="flex-1 text-xs flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg text-white font-medium shadow-sm" style={{ backgroundColor: TONE.sky }}><Pencil size={12}/> Edit</button>
                <button onClick={onDelete} className="flex-1 text-xs flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg text-white font-medium shadow-sm" style={{ backgroundColor: TONE.rose }}><Trash2 size={12}/> Delete</button>
              </div>
            ) : (
              <button className={`text-xs flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg border ${t.border} ${t.muted} ${t.hover}`}><Printer size={12}/> Print label</button>
            )}
            <button onClick={toggleCart}
              className={`text-xs flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg font-medium border ${t.border} ${inCart ? "text-white" : `${t.chip} ${t.strong}`}`}
              style={inCart ? { backgroundColor: TONE.emerald, borderColor: TONE.emerald } : undefined}>
              {inCart ? <><CircleCheck size={12}/> In cart</> : <><ShoppingCart size={12}/> Add to cart</>}
            </button>
          </div>
        </div>
      </Card>

      <div className={`flex gap-1 p-1 rounded-xl ${t.chip} w-full sm:w-fit`}>
        {tabs.map((x) => (
          <button key={x} onClick={() => setTab(x)} className={`px-4 py-1.5 rounded-lg text-sm capitalize font-medium transition-colors ${tab === x ? "bg-emerald-600 text-white shadow-sm" : `${t.muted} ${t.hover}`}`}>{x}</button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="grid md:grid-cols-2 gap-4">
          <Card t={t}>
            <CardTitle t={t} icon={HeartPulse} title="Health alerts" />
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2" style={{ color: TONE.rose }}><TriangleAlert size={15} /> Mastitis follow-up due Aug 2</li>
              <li className="flex items-center gap-2" style={{ color: TONE.amber }}><Clock size={15} /> FMD booster due Aug 14</li>
              <li className={`flex items-center gap-2 ${t.muted}`}><CircleCheck size={15} style={{ color: TONE.emerald }}/> Deworming up to date</li>
            </ul>
          </Card>
          <Card t={t}>
            <CardTitle t={t} icon={WeightIcon} title="Growth" />
            <div className="h-40">
              <ResponsiveContainer>
                <LineChart data={WEIGHT_CURVE} margin={{ left:-20, right:8, top:8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={t.grid} vertical={false} />
                  <XAxis dataKey="age" tick={{ fill:t.axis, fontSize:11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill:t.axis, fontSize:11 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={t.tip} />
                  <Line type="monotone" dataKey="kg" stroke="#16a34a" strokeWidth={2.5} dot={{ r:3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      )}

      {tab === "timeline" && (
        <Card t={t}>
          <CardTitle t={t} icon={Clock} title="Life timeline" />
          <ol className="relative ml-2 space-y-5 pl-6 pt-1" style={{ borderLeft: `2px solid ${TONE.emerald}33` }}>
            {events.map((e,i) => (
              <li key={i} className="relative">
                <span className={`absolute grid place-items-center w-6 h-6 rounded-full ring-4 ${t.ring}`} style={{ ...tint(e.tone), left: "-31px" }}><e.icon size={12} /></span>
                <div className="flex items-baseline gap-2 flex-wrap"><span className={`font-semibold text-sm ${t.strong}`}>{e.type}</span><span className={`text-xs ${t.muted}`}>{e.date}</span></div>
                <div className={`text-sm ${t.muted}`}>{e.note}</div>
              </li>
            ))}
          </ol>
        </Card>
      )}

      {tab === "medical" && (
        <Card t={t} className="overflow-x-auto">
          <CardTitle t={t} icon={Stethoscope} title="Medical records" />
          {meds.length === 0 ? <Empty t={t} msg="No treatments recorded yet. Log the first one to start this animal's health history." /> : (
            <table style={{ minWidth: 560 }} className="w-full text-sm">
              <thead><tr className={`text-left ${t.muted} text-xs`}>{["Date","Vet","Diagnosis","Medication","Withdrawal","Temp","Follow-up"].map(h=><th key={h} className="py-2 font-medium">{h}</th>)}</tr></thead>
              <tbody>
                {meds.map((m,i)=>(
                  <tr key={i} className={`border-t ${t.border}`}>
                    <td className={`py-2.5 ${t.strong}`}>{m.date}</td><td className={t.muted}>{m.vet}</td>
                    <td className={t.strong}>{m.diag}</td><td className={t.muted}>{m.med} · {m.dose}</td>
                    <td style={{ color: TONE.amber }}>{m.withdraw}</td><td className={t.muted}>{m.temp}°C</td><td className={t.muted}>{m.followup}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}

      {tab === "documents" && (
        <div className="grid sm:grid-cols-3 gap-3">
          {["Purchase receipt","Vet certificate","Insurance cover","AI service card","Photo — Jun 2026","Weigh sheet"].map((d)=>(
            <div key={d} className={`p-4 rounded-xl border ${t.border} ${t.card} flex items-center gap-3`}>
              <FileText size={20} style={{ color: TONE.emerald }} />
              <div className="text-sm"><div className={`font-medium ${t.strong}`}>{d}</div><div className={`text-xs ${t.muted}`}>PDF · 240 KB</div></div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Scan({ t, open, animals }) {
  const [state, setState]   = useState("idle");   // idle | scanning
  const [cam, setCam]       = useState(false);
  const [result, setResult] = useState(null);     // { a } | { notFound: value }

  const norm  = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  const match = (value) => {
    const n = norm(value); if (!n) return null;
    return animals.find((a) => norm(a.id) === n || (a.rfid && norm(a.rfid) === n))
        || animals.find((a) => norm(a.id).includes(n) || (a.rfid && norm(a.rfid).includes(n)));
  };
  const simulate = () => {
    setState("scanning"); setResult(null);
    setTimeout(() => { setState("idle"); const a = animals.find((x) => x.id === "NG-C-100") || animals[0]; setResult(a ? { a } : null); }, 1200);
  };
  const onDetect = (value) => { setCam(false); const a = match(value); setResult(a ? { a } : { notFound: value }); };

  const a = result && result.a;
  return (
    <div className="space-y-5">
      <Head t={t} title="Scan RFID / QR" sub="Phone camera for QR / barcode · USB, Bluetooth or NFC reader" />
      <div className="grid md:grid-cols-2 gap-4">
        <Card t={t} className="flex flex-col items-center justify-center py-10">
          <div className={`relative grid place-items-center w-44 h-44 rounded-full border-4 ${state==="scanning" ? "animate-pulse" : ""}`}
               style={{ borderColor: state==="scanning" ? "#10b981" : TONE.emerald + "33" }}>
            <Radio size={64} style={{ color: state==="scanning" ? "#10b981" : TONE.emerald + "80" }} />
            {state==="scanning" && <span className="absolute inset-0 rounded-full border-4 border-transparent border-t-emerald-500 animate-spin" />}
          </div>
          <p className={`mt-5 text-sm ${t.muted}`}>
            {state==="scanning" ? "Reading tag…" : "Scan a tag with your phone camera or a reader"}
          </p>
          <div className="flex flex-wrap justify-center gap-2 mt-4">
            <button onClick={() => setCam(true)} className="flex items-center gap-1.5 px-4 h-10 rounded-lg text-white text-sm font-medium shadow-sm" style={{ backgroundColor: TONE.sky }}><Camera size={16}/> Scan with camera</button>
            <button onClick={simulate} className="flex items-center gap-1.5 px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700"><Radio size={16}/> Simulate reader</button>
          </div>
        </Card>

        <Card t={t}>
          {a ? (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="grid place-items-center w-14 h-14 rounded-xl text-3xl" style={{ backgroundColor: TONE.emerald + "1a" }}>{SPECIES[a.sp]}</div>
                <div className="flex-1 min-w-0"><div className={`text-lg font-bold ${t.strong}`}>{a.name}</div><div className={`text-xs ${t.muted}`}>{a.id} · {a.breed} · {ageOf(a.dob)}</div></div>
                <StatusPill status={a.status} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Meta t={t} label="Current weight" value={`${a.wt} kg`} />
                <Meta t={t} label="RFID tag" value={a.rfid || a.id.replace(/-/g,"")} />
              </div>
              {a.id === "NG-C-100" && (
                <div className="space-y-1.5 text-sm">
                  <div className="flex items-center gap-2" style={{ color: TONE.rose }}><TriangleAlert size={15}/> Mastitis follow-up due Aug 2</div>
                  <div className="flex items-center gap-2" style={{ color: TONE.amber }}><Syringe size={15}/> FMD booster due Aug 14</div>
                </div>
              )}
              <button onClick={() => open(a.id)} className="w-full h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700">Open full profile</button>
            </div>
          ) : result && result.notFound ? (
            <div className="flex flex-col items-center text-center py-8">
              <span className="grid place-items-center w-12 h-12 rounded-full mb-3" style={tint("amber")}><TriangleAlert size={22}/></span>
              <div className={`font-semibold ${t.strong}`}>No animal matches this tag</div>
              <div className={`text-sm ${t.muted} mt-1`}>Scanned <span className="font-mono">{result.notFound}</span></div>
              <div className={`text-xs ${t.muted} mt-1`}>Register it from the Animal register to link this tag.</div>
            </div>
          ) : (
            <Empty t={t} msg="Scan a tag to instantly pull up the animal's live profile, alerts and last treatment." />
          )}
        </Card>
      </div>

      {cam && <CameraScanner t={t} title="Scan animal tag"
        hint="Point the camera at the QR / barcode on the ear tag to look up the animal."
        onClose={() => setCam(false)} onDetect={onDetect} />}
    </div>
  );
}

const VAX_SUGGEST = ["Foot & Mouth Disease","Lumpy Skin Disease","Anthrax","Blackquarter","Brucellosis (S19)","Rift Valley Fever","Rabies","CBPP","East Coast Fever","Enterotoxaemia","PPR (goats)","Newcastle (poultry)"];
const VAX_TARGETS = ["All cattle","Milking herd","Heifers","Calves","Bulls","All goats","Poultry"];
const VAX_SEED = [
  { vaccine:"Foot & Mouth Disease", target:"All cattle",   given:"2026-02-14", due:"2026-08-14", dose:"2 ml S/C",  batch:"FMD-118",  expiry:"2026-09-30", by:"Dr. Wanjiru", status:"Scheduled" },
  { vaccine:"Lumpy Skin Disease",   target:"All cattle",   given:"2025-08-10", due:"2026-08-09", dose:"1 ml S/C",  batch:"LSD-77",   expiry:"2026-08-31", by:"Dr. Wanjiru", status:"Scheduled" },
  { vaccine:"Anthrax",              target:"All cattle",   given:"2025-07-30", due:"2026-07-30", dose:"1 ml S/C",  batch:"ANX-204",  expiry:"2026-07-15", by:"—",           status:"Scheduled" },
  { vaccine:"Blackquarter",         target:"Calves",       given:"2026-06-20", due:"2026-12-20", dose:"2 ml S/C",  batch:"BQ-2291",  expiry:"2027-01-31", by:"J. Kamau",    status:"Done" },
  { vaccine:"Brucellosis (S19)",    target:"Heifers",      given:"2026-04-11", due:"2027-04-11", dose:"2 ml S/C",  batch:"S19-014",  expiry:"2027-06-30", by:"Dr. Wanjiru", status:"Done" },
];
const VAX_BLANK = { vaccine:"", target:"All cattle", given:"", due:"", dose:"", batch:"", expiry:"", by:"", status:"Scheduled" };
const TODAY = "2026-08-06";

function VaccineCalendar({ t }) {
  const [rows, setRows] = useState(VAX_SEED);
  const update = (i, k, v) => setRows((r) => r.map((row, idx) => idx === i ? { ...row, [k]: v } : row));
  const addRow = () => setRows((r) => [...r, { ...VAX_BLANK }]);
  const delRow = (i) => setRows((r) => r.filter((_, idx) => idx !== i));
  const overdue = (row) => row.due && row.due < TODAY && row.status !== "Done";
  const expired = (row) => row.expiry && row.expiry < TODAY;

  const doneN = rows.filter((r) => r.status === "Done").length;
  const overN = rows.filter(overdue).length;
  const dueN  = rows.filter((r) => r.due >= TODAY && r.status !== "Done").length;
  const expN  = rows.filter(expired).length;

  const cell = `w-full bg-transparent outline-none text-sm ${t.strong} px-1.5 py-1 rounded-md focus:ring-2`;
  const th   = "py-2 px-1.5 font-medium text-left whitespace-nowrap";

  return (
    <Card t={t} className="overflow-x-auto">
      <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
        <div className="flex items-center gap-2"><Syringe size={16} style={{ color: TONE.emerald }} /><h3 className={`font-semibold text-sm ${t.strong}`}>Vaccination calendar</h3></div>
        <div className="flex items-center gap-2">
          <span className="text-xs px-2 py-1 rounded-full" style={tint("emerald")}>{doneN} done</span>
          <span className="text-xs px-2 py-1 rounded-full" style={tint("amber")}>{dueN} upcoming</span>
          <span className="text-xs px-2 py-1 rounded-full" style={tint("rose")}>{overN} overdue</span>
          {expN > 0 && <span className="text-xs px-2 py-1 rounded-full" style={tint("violet")}>{expN} expired batch</span>}
          <button onClick={addRow} className="flex items-center gap-1 px-3 h-9 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700"><Plus size={15}/> Add row</button>
        </div>
      </div>

      <datalist id="vax-suggest">{VAX_SUGGEST.map((v) => <option key={v} value={v} />)}</datalist>

      <table style={{ minWidth: 1080 }} className="w-full text-sm">
        <thead>
          <tr className={`text-xs ${t.muted} border-b ${t.border}`}>
            <th className={th}>Vaccine</th><th className={th}>Target</th><th className={th}>Date given</th>
            <th className={th}>Next due</th><th className={th}>Dose</th><th className={th}>Batch no.</th>
            <th className={th}>Expiry date</th><th className={th}>Administered by</th><th className={th}>Status</th><th className={th}></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className={`border-b ${t.border}`} style={overdue(r) ? { backgroundColor: TONE.rose + "0f" } : undefined}>
              <td className="px-0.5"><input list="vax-suggest" className={cell} value={r.vaccine} onChange={(e)=>update(i,"vaccine",e.target.value)} placeholder="Vaccine name" /></td>
              <td className="px-0.5">
                <select className={cell} value={r.target} onChange={(e)=>update(i,"target",e.target.value)}>
                  {VAX_TARGETS.map((x)=><option key={x} value={x}>{x}</option>)}
                </select>
              </td>
              <td className="px-0.5"><input type="date" className={cell} value={r.given} onChange={(e)=>update(i,"given",e.target.value)} /></td>
              <td className="px-0.5">
                <input type="date" className={cell} value={r.due} onChange={(e)=>update(i,"due",e.target.value)} style={overdue(r) ? { color: TONE.rose, fontWeight: 600 } : undefined} />
              </td>
              <td className="px-0.5"><input className={cell} value={r.dose} onChange={(e)=>update(i,"dose",e.target.value)} placeholder="2 ml S/C" /></td>
              <td className="px-0.5"><input className={cell} value={r.batch} onChange={(e)=>update(i,"batch",e.target.value)} placeholder="Batch" /></td>
              <td className="px-0.5"><input type="date" className={cell} value={r.expiry} onChange={(e)=>update(i,"expiry",e.target.value)} title={expired(r) ? "Batch expired" : undefined} style={expired(r) ? { color: TONE.rose, fontWeight: 600 } : undefined} /></td>
              <td className="px-0.5"><input className={cell} value={r.by} onChange={(e)=>update(i,"by",e.target.value)} placeholder="Name" /></td>
              <td className="px-0.5">
                <select className={cell} value={r.status} onChange={(e)=>update(i,"status",e.target.value)}
                  style={{ color: solid(r.status==="Done"?"emerald":overdue(r)?"rose":"amber"), fontWeight: 600 }}>
                  {["Scheduled","Done","Missed"].map((x)=><option key={x} value={x}>{x}</option>)}
                </select>
              </td>
              <td className="px-0.5 text-right"><button onClick={()=>delRow(i)} title="Delete row" className={`grid place-items-center w-7 h-7 rounded-md border ${t.border} ${t.chip}`} style={{ color: TONE.rose }}><Trash2 size={13}/></button></td>
            </tr>
          ))}
          {rows.length === 0 && <tr><td colSpan={10}><Empty t={t} msg="No vaccinations yet. Tap “Add row” to start your calendar." /></td></tr>}
        </tbody>
      </table>
      <p className={`text-xs ${t.muted} mt-3`}>Overdue rows (next due before {TODAY}) are highlighted, and batches past their expiry date are flagged in red.</p>
    </Card>
  );
}

const DISEASES = [
  { name:"Mastitis",                cat:"Bacterial",   tone:"sky",    signs:"Swollen quarter, clots/flakes in milk, sudden yield drop", action:"Strip & test, hygiene at milking, teat-dip, dry-cow therapy" },
  { name:"East Coast Fever (ECF)",  cat:"Tick-borne",  tone:"amber",  signs:"High fever, swollen lymph nodes, laboured breathing", action:"Tick control (acaricide), ECF infection-and-treatment vaccine" },
  { name:"Foot & Mouth Disease",    cat:"Viral",       tone:"rose",   signs:"Blisters on mouth/feet, drooling, lameness, milk drop", action:"Vaccinate 6-monthly, restrict movement, report outbreaks" },
  { name:"Lumpy Skin Disease",      cat:"Viral",       tone:"rose",   signs:"Firm skin nodules, fever, drop in condition", action:"Annual LSD vaccination, vector (fly) control" },
  { name:"Anaplasmosis",            cat:"Tick-borne",  tone:"amber",  signs:"Anaemia, pale gums, fever, weakness", action:"Tick control, tetracyclines under vet guidance" },
  { name:"Brucellosis",             cat:"Bacterial",   tone:"violet", signs:"Late abortion, retained placenta, weak calves", action:"S19 vaccinate heifers, test & cull positives (zoonotic!)" },
  { name:"Milk fever",              cat:"Metabolic",   tone:"violet", signs:"Down cow soon after calving, cold ears, staggering", action:"Calcium therapy, manage dry-cow mineral balance" },
  { name:"Bloat",                   cat:"Metabolic",   tone:"lime",   signs:"Distended left flank, discomfort, laboured breathing", action:"Introduce lush pasture gradually, anti-bloat drench" },
  { name:"Worms (helminthiasis)",   cat:"Parasitic",   tone:"lime",   signs:"Poor growth, rough coat, diarrhoea, pot belly in calves", action:"Routine deworming, rotate pasture & dewormer class" },
  { name:"Calf pneumonia",          cat:"Respiratory", tone:"sky",    signs:"Coughing, nasal discharge, fast breathing, dullness", action:"Good colostrum, ventilation, prompt antibiotics" },
];

function Health({ t, open }) {
  return (
    <div className="space-y-5">
      <Head t={t} title="Health & vaccinations" sub="Build and track your vaccination calendar; schedules raise alerts" />
      <VaccineCalendar t={t} />
      <div className="grid lg:grid-cols-2 gap-4">
        <Card t={t}>
          <CardTitle t={t} icon={Syringe} title="Vaccination schedule" />
          <ul className={`divide-y ${t.divide}`}>
            {VACCINES.map((v,i)=>(
              <li key={i} className="flex items-center gap-3 py-2.5">
                <span className="w-2 h-2 rounded-full" style={{ background: solid(vaccineTone[v.state]) }} />
                <div className="flex-1"><div className={`text-sm font-medium ${t.strong}`}>{v.name}</div><div className={`text-xs ${t.muted}`}>{v.herd} animals · due {v.due}</div></div>
                <span className="text-xs px-2 py-0.5 rounded-full capitalize" style={tint(vaccineTone[v.state])}>{v.state}</span>
              </li>
            ))}
          </ul>
        </Card>
        <Card t={t} className="overflow-x-auto">
          <CardTitle t={t} icon={Stethoscope} title="Recent treatments" />
          <table style={{ minWidth: 440 }} className="w-full text-sm">
            <thead><tr className={`text-left text-xs ${t.muted}`}>{["Date","Animal","Diagnosis","Vet"].map(h=><th key={h} className="py-2 font-medium">{h}</th>)}</tr></thead>
            <tbody>
              {MEDICAL.map((m,i)=>(
                <tr key={i} className={`border-t ${t.border}`}>
                  <td className={`py-2.5 ${t.muted}`}>{m.date}</td>
                  <td><button onClick={()=>open(m.animal)} className="font-medium hover:underline" style={{ color: TONE.emerald }}>{byId[m.animal].name}</button></td>
                  <td className={t.strong}>{m.diag}</td><td className={t.muted}>{m.vet}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <Card t={t}>
        <CardTitle t={t} icon={HeartPulse} title="Common diseases" right={<span className={`text-xs ${t.muted}`}>Kenya dairy · watch-list</span>} />
        <div className="space-y-2">
          {DISEASES.map((d) => (
            <div key={d.name} className={`flex items-start gap-3 p-3 rounded-xl border ${t.border}`}>
              <span className="grid place-items-center w-9 h-9 rounded-lg shrink-0" style={tint(d.tone)}><HeartPulse size={16} /></span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`text-sm font-semibold ${t.strong}`}>{d.name}</span>
                  <span className="text-xs font-medium px-2 py-0.5 rounded-full" style={tint(d.tone)}>{d.cat}</span>
                </div>
                <div className={`text-xs ${t.muted} mt-1`}><b className={t.strong}>Signs:</b> {d.signs}</div>
                <div className={`text-xs ${t.muted} mt-0.5`}><b className={t.strong}>Manage:</b> {d.action}</div>
              </div>
            </div>
          ))}
        </div>
        <p className={`text-xs ${t.muted} mt-3`}>Reference only — always confirm diagnosis and treatment with a qualified vet. Brucellosis and others are zoonotic (can infect people).</p>
      </Card>
    </div>
  );
}

function Breeding({ t, open }) {
  return (
    <div className="space-y-5">
      <Head t={t} title="Reproduction" sub="Heat, AI, pregnancy checks and breeding intelligence" />
      <Card t={t} className="overflow-x-auto">
        <CardTitle t={t} icon={Baby} title="Breeding events" />
        <table style={{ minWidth: 560 }} className="w-full text-sm">
          <thead><tr className={`text-left text-xs ${t.muted}`}>{["Dam","Event","Sire","Date","Status","Expected delivery"].map(h=><th key={h} className="py-2 font-medium">{h}</th>)}</tr></thead>
          <tbody>
            {BREEDING.map((b,i)=>(
              <tr key={i} className={`border-t ${t.border}`}>
                <td className="py-2.5"><button onClick={()=>open(b.dam)} className="font-medium hover:underline" style={{ color: TONE.emerald }}>{byId[b.dam].name}</button></td>
                <td className={t.strong}>{b.event}</td>
                <td className={t.muted}>{byId[b.sire]?.name || b.sire}</td>
                <td className={t.muted}>{b.date}</td>
                <td><span className="text-xs px-2 py-0.5 rounded-full" style={tint(statusTone[b.status] || "amber")}>{b.status}</span></td>
                <td className={t.muted}>{b.edd}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Card t={t}>
        <CardTitle t={t} icon={Dna} title="Breeding intelligence" right={<span className={`text-xs ${t.muted}`}>Pairings ranked by genetic diversity</span>} />
        <div className="grid md:grid-cols-3 gap-3">
          {PAIRS.map((p,i)=>(
            <div key={i} className={`p-4 rounded-xl border ${t.border} ${t.card}`}>
              <div className={`text-sm font-semibold ${t.strong}`}>{p.dam} × {p.sire}</div>
              <div className="mt-3 flex items-center gap-2">
                <div className={`flex-1 h-2 rounded-full ${t.track}`}><div className="h-full rounded-full" style={{ width:`${p.diversity}%`, background: solid(p.tone) }} /></div>
                <span className="text-xs font-medium" style={{ color: solid(p.tone) }}>{p.diversity}</span>
              </div>
              <div className={`mt-2 text-xs ${t.muted}`}>Inbreeding {p.inbreed}</div>
              <div className={`mt-1 text-xs ${t.muted}`}>{p.note}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function FamilyTree({ t, open, dark }) {
  const [focusId, setFocusId] = useState("NG-C-100");
  const focus = byId[focusId] || byId["NG-C-100"];
  const dad = byId[focus.dadId], mom = byId[focus.momId];

  const ink    = dark ? "#f5f5f4" : "#1c1917";
  const sub    = dark ? "#a8a29e" : "#78716c";
  const cardBg = dark ? "#1c1917" : "#ffffff";
  const bd     = dark ? "#33302c" : "#e7e5e4";
  const line   = dark ? "#4b4640" : "#cfcac3";

  const Box = (a, label, x, y, hl = false) => {
    const w = 150, h = 46;
    if (!a) return (
      <g key={label + x}>
        <rect x={x} y={y} width={w} height={h} rx={10} fill="none" stroke={bd} strokeDasharray="4 4" />
        <text x={x + w / 2} y={y + h / 2 + 4} textAnchor="middle" fontSize="11" fill={sub}>Unknown</text>
      </g>
    );
    return (
      <g key={label + x} onClick={() => open(a.id)} style={{ cursor: "pointer" }}>
        <rect x={x} y={y} width={w} height={h} rx={10} fill={cardBg} stroke={hl ? TONE.emerald : bd} strokeWidth={hl ? 2 : 1.2} />
        <text x={x + 13} y={y + 30} fontSize="19">{SPECIES[a.sp]}</text>
        <text x={x + 36} y={y + 20} fontSize="12.5" fontWeight="700" fill={ink}>{a.name}</text>
        <text x={x + 36} y={y + 34} fontSize="9.5" fill={sub}>{label} · {a.id}</text>
      </g>
    );
  };

  // bracket: two parents (at cx1/cx2, bottom by) join a bar at my, drop to child top (ccx, cy)
  const bracket = (cx1, cx2, by, my, ccx, cy) => (
    <>
      <line x1={cx1} y1={by} x2={cx1} y2={my} /><line x1={cx2} y1={by} x2={cx2} y2={my} />
      <line x1={cx1} y1={my} x2={cx2} y2={my} /><line x1={ccx} y1={my} x2={ccx} y2={cy} />
    </>
  );

  return (
    <div className="space-y-5">
      <Head t={t} title={`Family tree — ${focus.name}`} sub="Three-generation pedigree · tap any animal to open its profile"
        action={
          <select value={focusId} onChange={(e) => setFocusId(e.target.value)}
            className={`h-10 px-3 rounded-lg text-sm font-medium outline-none border ${t.border} ${t.input} ${t.strong}`}>
            {ANIMALS.map((a) => <option key={a.id} value={a.id}>{SPECIES[a.sp]} {a.name} · {a.id}</option>)}
          </select>
        } />
      <div className="grid md:grid-cols-3 gap-4">
        <Card t={t}><CardTitle t={t} icon={Dna} title="Inbreeding coefficient" /><div className="text-3xl font-bold" style={{ color: TONE.emerald }}>0.0%</div><div className={`text-xs ${t.muted} mt-1`}>No common ancestors in 3 generations</div></Card>
        <Card t={t}><CardTitle t={t} icon={TrendingUp} title="Bloodline score" /><div className={`text-3xl font-bold ${t.strong}`}>A−</div><div className={`text-xs ${t.muted} mt-1`}>Strong dairy dam line, hardy sire line</div></Card>
        <Card t={t}><CardTitle t={t} icon={Milk} title="Predicted 1st lactation" /><div className={`text-3xl font-bold ${t.strong}`}>4,850 L</div><div className={`text-xs ${t.muted} mt-1`}>From dam &amp; granddam performance</div></Card>
      </div>

      <Card t={t} className="overflow-x-auto">
        <CardTitle t={t} icon={GitBranch} title="Pedigree" />
        <svg viewBox="0 0 720 430" width="100%" style={{ minWidth: 680 }} fontFamily="inherit">
          <g stroke={line} strokeWidth="1.5" fill="none" strokeLinecap="round">
            {bracket(95, 270, 62, 112, 182, 150)}   {/* paternal grandparents → sire */}
            {bracket(445, 620, 62, 112, 532, 150)}  {/* maternal grandparents → dam */}
            {bracket(182, 532, 196, 246, 357, 284)} {/* sire + dam → focus */}
            <line x1="357" y1="330" x2="357" y2="384" strokeDasharray="4 4" />
          </g>
          {/* generation labels */}
          <text x="8" y="42" fontSize="10" fill={sub} fontWeight="600" transform="rotate(-90 8 42)">GRANDPARENTS</text>
          {/* nodes */}
          {Box(byId[dad?.dadId], "Paternal grandsire", 20, 16)}
          {Box(byId[dad?.momId], "Paternal granddam", 195, 16)}
          {Box(byId[mom?.dadId], "Maternal grandsire", 370, 16)}
          {Box(byId[mom?.momId], "Maternal granddam", 545, 16)}
          {Box(dad, "Sire", 107, 150)}
          {Box(mom, "Dam", 457, 150)}
          {Box(focus, "This animal", 282, 284, true)}
          <g>
            <rect x="282" y="384" width="150" height="38" rx="10" fill="none" stroke={bd} strokeDasharray="4 4" />
            <text x="357" y="407" textAnchor="middle" fontSize="10.5" fill={sub}>Calf expected · AI Aug 2026</text>
          </g>
        </svg>
      </Card>
    </div>
  );
}

function WeightView({ t }) {
  const gain = [{ m:"Mar",g:0.72 },{ m:"Apr",g:0.81 },{ m:"May",g:0.77 },{ m:"Jun",g:0.69 },{ m:"Jul",g:0.84 }];
  return (
    <div className="space-y-5">
      <Head t={t} title="Weight & growth" sub="Nyota (NG-C-100) · predicted mature weight 520 kg" />
      <div className="grid grid-cols-3 gap-3">
        <Stat t={t} label="Current"        value="388 kg"  sub="Jul weigh-in"   icon={WeightIcon}  tone="emerald" />
        <Stat t={t} label="Avg daily gain" value="0.78 kg" sub="Last 90 days"   icon={TrendingUp}  tone="lime" />
        <Stat t={t} label="Mature (pred.)" value="520 kg"  sub="Growth model"   icon={ArrowUpRight}tone="amber" />
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <Card t={t}>
          <CardTitle t={t} icon={TrendingUp} title="Growth curve" />
          <div className="h-64">
            <ResponsiveContainer>
              <LineChart data={WEIGHT_CURVE} margin={{ left:-18, right:8, top:8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={t.grid} vertical={false} />
                <XAxis dataKey="age" tick={{ fill:t.axis, fontSize:12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill:t.axis, fontSize:12 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={t.tip} />
                <Line type="monotone" dataKey="kg" stroke="#16a34a" strokeWidth={2.5} dot={{ r:3 }} name="kg" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card t={t}>
          <CardTitle t={t} icon={WeightIcon} title="Monthly daily gain (kg/day)" />
          <div className="h-64">
            <ResponsiveContainer>
              <BarChart data={gain} margin={{ left:-18, right:8, top:8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={t.grid} vertical={false} />
                <XAxis dataKey="m" tick={{ fill:t.axis, fontSize:12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill:t.axis, fontSize:12 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={t.tip} />
                <Bar dataKey="g" fill="#65a30d" radius={[4,4,0,0]} name="kg/day" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </div>
  );
}

function Productivity({ t }) {
  const daily = [
    { d:"Mon",am:12.1,pm:10.4 },{ d:"Tue",am:12.6,pm:10.9 },{ d:"Wed",am:11.8,pm:10.2 },
    { d:"Thu",am:12.9,pm:11.1 },{ d:"Fri",am:13.2,pm:11.4 },{ d:"Sat",am:12.4,pm:10.8 },{ d:"Sun",am:12.7,pm:11.0 },
  ];
  return (
    <div className="space-y-5">
      <Head t={t} title="Productivity — dairy" sub="Nyota · lactation 1 · day 281" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Stat t={t} label="Daily yield" value="23.8 L" sub="AM + PM"    icon={Milk}       tone="emerald" />
        <Stat t={t} label="Butterfat"   value="3.9%"   sub="Last test"  icon={Droplets}   tone="amber" />
        <Stat t={t} label="Protein"     value="3.3%"   sub="Last test"  icon={Egg}        tone="lime" />
        <Stat t={t} label="SCC"         value="180k"   sub="cells/ml"   icon={ShieldCheck}tone="sky" />
      </div>
      <Card t={t}>
        <CardTitle t={t} icon={Milk} title="Milking — this week (litres)" />
        <div className="h-64">
          <ResponsiveContainer>
            <BarChart data={daily} margin={{ left:-18, right:8, top:8 }} barGap={2}>
              <CartesianGrid strokeDasharray="3 3" stroke={t.grid} vertical={false} />
              <XAxis dataKey="d" tick={{ fill:t.axis, fontSize:12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill:t.axis, fontSize:12 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={t.tip} />
              <Bar dataKey="am" stackId="a" fill="#15803d" name="Morning" />
              <Bar dataKey="pm" stackId="a" fill="#a3e635" name="Evening" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}

/* ================================================================== */
/*  Logbook — daily production entry: milk + weight                   */
/* ================================================================== */
const MILK_SEED = [
  { date:"2026-08-06", animal:"NG-C-100", am:12.4, pm:11.8, notes:"" },
  { date:"2026-08-06", animal:"NG-C-030", am:9.6,  pm:9.1,  notes:"Slight drop" },
  { date:"2026-08-06", animal:"NG-C-050", am:7.2,  pm:6.9,  notes:"" },
  { date:"2026-08-05", animal:"NG-C-100", am:12.1, pm:12.0, notes:"" },
];
const WEIGHT_SEED = [
  { date:"2026-08-01", animal:"NG-C-100", weight:388, method:"Weighband", notes:"" },
  { date:"2026-08-01", animal:"NG-C-102", weight:84,  method:"Scale",     notes:"Weaning check" },
  { date:"2026-07-01", animal:"NG-C-100", weight:372, method:"Weighband", notes:"" },
];
const MILK_BLANK   = { date: TODAY, animal:"", am:"", pm:"", notes:"" };
const WEIGHT_BLANK = { date: TODAY, animal:"", weight:"", method:"Scale", notes:"" };

function Logbook({ t, animals, dark }) {
  const [tab, setTab]   = useState("milk");
  const [milk, setMilk] = useState(MILK_SEED);
  const [wts, setWts]   = useState(WEIGHT_SEED);

  const opts = useMemo(() => animals.filter((a) => a.status === "Active"), [animals]);
  const cell = `w-full bg-transparent outline-none text-sm ${t.strong} px-1.5 py-1 rounded-md`;
  const th   = "py-2 px-1.5 font-medium text-left whitespace-nowrap";
  const num  = (v) => Number(v) || 0;

  const setM = (i,k,v) => setMilk((r)=>r.map((x,idx)=>idx===i?{...x,[k]:v}:x));
  const setW = (i,k,v) => setWts((r)=>r.map((x,idx)=>idx===i?{...x,[k]:v}:x));

  const todayMilk = milk.filter((r)=>r.date===TODAY).reduce((s,r)=>s+num(r.am)+num(r.pm),0);
  const milkTotal = milk.reduce((s,r)=>s+num(r.am)+num(r.pm),0);

  const AnimalSelect = ({ value, onChange }) => (
    <select className={cell} value={value} onChange={onChange}>
      <option value="">Select animal</option>
      {opts.map((a)=><option key={a.id} value={a.id}>{a.name} ({a.id})</option>)}
    </select>
  );

  // Built once (per theme) instead of rebuilding 320 nodes on every keystroke.
  const watermark = useMemo(() => (
    <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden select-none" style={{ zIndex: 0 }}>
      <div className="flex flex-wrap content-start w-full h-full" style={{ opacity: dark ? 0.07 : 0.1 }}>
        {Array.from({ length: 320 }).map((_, i) => {
          const HERD = ["🐄","🐐","🐑","🐔","🐖"];
          return (
            <div key={i} className="grid place-items-center" style={{ width: 92, height: 88, fontSize: 34, transform: `rotate(${(i % 3 - 1) * 8}deg)` }}>
              {HERD[i % HERD.length]}
            </div>
          );
        })}
      </div>
    </div>
  ), [dark]);

  return (
    <div className="relative">
      {watermark}

      <div className="relative space-y-5" style={{ zIndex: 1 }}>
      <Head t={t} title="Logbook" sub="Record daily production — milk yield and weigh-ins. Open to Managers and Administrators." />

      <div className={`flex gap-1 p-1 rounded-xl ${t.chip} w-full sm:w-fit`}>
        {[{k:"milk",label:"Milk log",icon:Milk},{k:"weight",label:"Weight log",icon:Scale}].map((x)=>(
          <button key={x.k} onClick={()=>setTab(x.k)} className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${tab===x.k ? "bg-emerald-600 text-white shadow-sm" : `${t.muted} ${t.hover}`}`}>
            <x.icon size={15}/> {x.label}
          </button>
        ))}
      </div>

      {tab === "milk" ? (
        <Card t={t} className="overflow-x-auto">
          <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
            <div className="flex items-center gap-2"><Milk size={16} style={{ color: TONE.emerald }}/><h3 className={`font-semibold text-sm ${t.strong}`}>Milk log</h3></div>
            <div className="flex items-center gap-2">
              <span className="text-xs px-2 py-1 rounded-full" style={tint("emerald")}>{todayMilk.toFixed(1)} L today</span>
              <span className="text-xs px-2 py-1 rounded-full" style={tint("sky")}>{milkTotal.toFixed(1)} L logged</span>
              <button onClick={()=>setMilk((r)=>[{...MILK_BLANK},...r])} className="flex items-center gap-1 px-3 h-9 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700"><Plus size={15}/> Add entry</button>
            </div>
          </div>
          <table style={{ minWidth: 820 }} className="w-full text-sm">
            <thead><tr className={`text-xs ${t.muted} border-b ${t.border}`}>
              <th className={th}>Date</th><th className={th}>Animal</th><th className={th}>Morning (L)</th><th className={th}>Evening (L)</th><th className={th}>Day total</th><th className={th}>Notes</th><th className={th}></th>
            </tr></thead>
            <tbody>
              {milk.map((r,i)=>(
                <tr key={i} className={`border-b ${t.border}`}>
                  <td className="px-0.5"><input type="date" className={cell} value={r.date} onChange={(e)=>setM(i,"date",e.target.value)} /></td>
                  <td className="px-0.5"><AnimalSelect value={r.animal} onChange={(e)=>setM(i,"animal",e.target.value)} /></td>
                  <td className="px-0.5"><input type="number" step="0.1" className={cell} value={r.am} onChange={(e)=>setM(i,"am",e.target.value)} placeholder="0.0" /></td>
                  <td className="px-0.5"><input type="number" step="0.1" className={cell} value={r.pm} onChange={(e)=>setM(i,"pm",e.target.value)} placeholder="0.0" /></td>
                  <td className={`px-1.5 font-semibold ${t.strong}`}>{(num(r.am)+num(r.pm)).toFixed(1)} L</td>
                  <td className="px-0.5"><input className={cell} value={r.notes} onChange={(e)=>setM(i,"notes",e.target.value)} placeholder="—" /></td>
                  <td className="px-0.5 text-right"><button onClick={()=>setMilk((r2)=>r2.filter((_,idx)=>idx!==i))} className={`grid place-items-center w-7 h-7 rounded-md border ${t.border} ${t.chip}`} style={{ color: TONE.rose }}><Trash2 size={13}/></button></td>
                </tr>
              ))}
              {milk.length===0 && <tr><td colSpan={7}><Empty t={t} msg="No milk entries yet. Tap “Add entry” to log the morning and evening yield." /></td></tr>}
            </tbody>
          </table>
        </Card>
      ) : (
        <Card t={t} className="overflow-x-auto">
          <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
            <div className="flex items-center gap-2"><Scale size={16} style={{ color: TONE.emerald }}/><h3 className={`font-semibold text-sm ${t.strong}`}>Weight log</h3></div>
            <div className="flex items-center gap-2">
              <span className="text-xs px-2 py-1 rounded-full" style={tint("sky")}>{wts.length} weigh-ins</span>
              <button onClick={()=>setWts((r)=>[{...WEIGHT_BLANK},...r])} className="flex items-center gap-1 px-3 h-9 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700"><Plus size={15}/> Add entry</button>
            </div>
          </div>
          <table style={{ minWidth: 760 }} className="w-full text-sm">
            <thead><tr className={`text-xs ${t.muted} border-b ${t.border}`}>
              <th className={th}>Date</th><th className={th}>Animal</th><th className={th}>Weight (kg)</th><th className={th}>Method</th><th className={th}>Notes</th><th className={th}></th>
            </tr></thead>
            <tbody>
              {wts.map((r,i)=>(
                <tr key={i} className={`border-b ${t.border}`}>
                  <td className="px-0.5"><input type="date" className={cell} value={r.date} onChange={(e)=>setW(i,"date",e.target.value)} /></td>
                  <td className="px-0.5"><AnimalSelect value={r.animal} onChange={(e)=>setW(i,"animal",e.target.value)} /></td>
                  <td className="px-0.5"><input type="number" className={cell} value={r.weight} onChange={(e)=>setW(i,"weight",e.target.value)} placeholder="0" /></td>
                  <td className="px-0.5">
                    <select className={cell} value={r.method} onChange={(e)=>setW(i,"method",e.target.value)}>
                      {["Scale","Weighband","Estimate"].map((m)=><option key={m} value={m}>{m}</option>)}
                    </select>
                  </td>
                  <td className="px-0.5"><input className={cell} value={r.notes} onChange={(e)=>setW(i,"notes",e.target.value)} placeholder="—" /></td>
                  <td className="px-0.5 text-right"><button onClick={()=>setWts((r2)=>r2.filter((_,idx)=>idx!==i))} className={`grid place-items-center w-7 h-7 rounded-md border ${t.border} ${t.chip}`} style={{ color: TONE.rose }}><Trash2 size={13}/></button></td>
                </tr>
              ))}
              {wts.length===0 && <tr><td colSpan={6}><Empty t={t} msg="No weigh-ins yet. Tap “Add entry” to record a weight." /></td></tr>}
            </tbody>
          </table>
        </Card>
      )}
      </div>
    </div>
  );
}

function Inventory({ t }) {
  return (
    <div className="space-y-5">
      <Head t={t} title="Inventory" sub="Auto-deducts on use · alerts below reorder point" />
      <Card t={t} className="overflow-x-auto">
        <table style={{ minWidth: 560 }} className="w-full text-sm">
          <thead><tr className={`text-left text-xs ${t.muted}`}>{["Item","Category","In stock","Reorder point","Status"].map(h=><th key={h} className="py-2 font-medium">{h}</th>)}</tr></thead>
          <tbody>
            {INVENTORY.map((r,i)=>{
              const low = r.qty <= r.min;
              return (
                <tr key={i} className={`border-t ${t.border}`}>
                  <td className={`py-2.5 font-medium ${t.strong}`}>{r.item}</td>
                  <td className={t.muted}>{r.cat}</td>
                  <td className={t.strong}>{r.qty} {r.unit}</td>
                  <td className={t.muted}>{r.min} {r.unit}</td>
                  <td>
                    {low
                      ? <span className="text-xs px-2 py-0.5 rounded-full inline-flex items-center gap-1" style={tint("rose")}><TriangleAlert size={11}/> Reorder</span>
                      : <span className="text-xs px-2 py-0.5 rounded-full inline-flex items-center gap-1" style={tint("emerald")}><CircleCheck size={11}/> OK</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

/* ---- Financial statements (coherent set: net profit → retained
   earnings; closing cash ties across all three) --------------------- */
const PL_STMT = {
  period: "1 Jan – 31 Jul 2026",
  revenue: [
    { k:"Milk sales", v:1240000 },
    { k:"Livestock sales", v:480000 },
    { k:"Manure & other income", v:60000 },
  ],
  cos: [
    { k:"Feed & fodder", v:620000 },
    { k:"Veterinary, AI & drugs", v:145000 },
    { k:"Casual labour (milking & herding)", v:180000 },
  ],
  opex: [
    { k:"Salaries — permanent staff", v:240000 },
    { k:"Utilities (water & power)", v:68000 },
    { k:"Transport & fuel", v:54000 },
    { k:"Repairs & maintenance", v:42000 },
    { k:"Depreciation", v:96000 },
    { k:"SACCO, admin & other", v:35000 },
  ],
  finance: 48000,
};
const BS_STMT = {
  date: "As at 31 July 2026",
  nonCurrent: [
    { k:"Land & buildings", v:3200000 },
    { k:"Plant & equipment (milking, cooling)", v:480000 },
    { k:"Breeding livestock (dairy herd)", v:1150000 },
  ],
  current: [
    { k:"Feed & input inventory", v:96000 },
    { k:"Trade receivables (co-op & buyers)", v:148000 },
    { k:"Cash, M-Pesa & bank", v:214000 },
  ],
  equity: [
    { k:"Owner's capital", v:4300000 },
    { k:"Retained earnings", v:588000 },
  ],
  ncLiab: [{ k:"Asset finance loan", v:300000 }],
  cLiab: [
    { k:"Trade payables (feed & vet)", v:72000 },
    { k:"SACCO & short-term", v:28000 },
  ],
};
const CF_STMT = {
  period: "1 Jan – 31 Jul 2026",
  operating: [
    { k:"Net profit before tax", v:252000 },
    { k:"Add: depreciation", v:96000 },
    { k:"(Increase) in receivables", v:-28000 },
    { k:"(Increase) in inventory", v:-12000 },
    { k:"Increase in payables", v:18000 },
  ],
  investing: [
    { k:"Purchase of breeding stock", v:-140000 },
    { k:"Purchase of equipment", v:-60000 },
  ],
  financing: [
    { k:"Loan repayment", v:-90000 },
    { k:"Owner drawings", v:-70000 },
  ],
  opening: 248000,
};
const VAT_SALES = [
  { k:"Milk sales (unprocessed)", net:1240000, treat:"Exempt", rate:0 },
  { k:"Live animal sales", net:480000, treat:"Exempt", rate:0 },
  { k:"Other taxable income (hire / processed)", net:60000, treat:"Standard 16%", rate:0.16 },
];
const VAT_PURCH = [
  { k:"Animal feed & fodder", net:620000, treat:"Zero-rated", rate:0 },
  { k:"Veterinary & AI services", net:145000, treat:"Exempt", rate:0 },
  { k:"Utilities (electricity)", net:58000, treat:"Standard 16%", rate:0.16 },
  { k:"Transport & fuel", net:54000, treat:"Standard 16%", rate:0.16 },
  { k:"Repairs & maintenance", net:42000, treat:"Standard 16%", rate:0.16 },
  { k:"Equipment purchase", net:60000, treat:"Standard 16%", rate:0.16 },
];
const vatTone = (tr) => tr.startsWith("Standard") ? "sky" : tr === "Zero-rated" ? "amber" : "stone";

const ANIMAL_PL = [
  { name:"Nyota",   id:"NG-C-100", milk:180000, calf:0,     other:6000, feed:78000, vet:14000, labour:22000, overhead:18000 },
  { name:"Malaika", id:"NG-C-030", milk:158000, calf:35000, other:4000, feed:72000, vet:16000, labour:20000, overhead:17000 },
  { name:"Wimbo",   id:"NG-C-045", milk:142000, calf:0,     other:3000, feed:70000, vet:12000, labour:19000, overhead:16000 },
  { name:"Zawadi",  id:"NG-C-051", milk:120000, calf:0,     other:2000, feed:64000, vet:11000, labour:17000, overhead:15000 },
  { name:"Baraka",  id:"NG-C-102", milk:38000,  calf:0,     other:1000, feed:40000, vet:9000,  labour:11000, overhead:9000 },
];
const animalPL = (a) => {
  const rev = a.milk + a.calf + a.other;
  const direct = a.feed + a.vet + a.labour;
  const gross = rev - direct;
  const net = gross - a.overhead;
  return { rev, direct, gross, net, margin: rev ? Math.round(net / rev * 100) : 0 };
};

const sumV = (arr) => arr.reduce((s, x) => s + x.v, 0);
const fmt = (n) => (n < 0 ? `(${money(Math.abs(n))})` : money(n));

function Ln({ t, k, v, lvl = 0, bold, tone, top, big }) {
  return (
    <div className={`flex items-center justify-between gap-4 ${top ? `mt-1.5 pt-2 border-t ${t.border}` : "py-1.5"}`}>
      <span className="text-sm" style={{ paddingLeft: lvl * 14 }}>
        <span className={bold ? `font-semibold ${t.strong}` : t.muted}>{k}</span>
      </span>
      <span className={`nf-num ${big ? "text-base" : "text-sm"} ${bold ? `font-bold ${t.strong}` : t.strong}`} style={tone ? { color: solid(tone) } : undefined}>
        {typeof v === "number" ? fmt(v) : v}
      </span>
    </div>
  );
}
function SLabel({ t, children }) {
  return <div className={`text-xs font-semibold uppercase tracking-wide ${t.muted} mt-4 mb-1 first:mt-0`}>{children}</div>;
}

function Finance({ t }) {
  const [tab, setTab] = useState("overview");
  const [selAnimal, setSelAnimal] = useState(0);
  const income  = FINANCE.reduce((s, r) => s + r.income, 0);
  const expense = FINANCE.reduce((s, r) => s + r.expense, 0);
  const perAnimal = [
    { name:"Nyota",profit:68000 },{ name:"Malaika",profit:54000 },{ name:"Wimbo",profit:41000 },
    { name:"Simba",profit:22000 },{ name:"Baraka",profit:-8000 },
  ];

  // P&L
  const totRev = sumV(PL_STMT.revenue), totCos = sumV(PL_STMT.cos), gross = totRev - totCos;
  const totOpex = sumV(PL_STMT.opex), opProfit = gross - totOpex, npbt = opProfit - PL_STMT.finance;
  // Balance sheet
  const totNCA = sumV(BS_STMT.nonCurrent), totCA = sumV(BS_STMT.current), totAssets = totNCA + totCA;
  const totEq = sumV(BS_STMT.equity), totLiab = sumV(BS_STMT.ncLiab) + sumV(BS_STMT.cLiab), totEL = totEq + totLiab;
  // Cash flow
  const opCF = sumV(CF_STMT.operating), invCF = sumV(CF_STMT.investing), finCF = sumV(CF_STMT.financing);
  const netCF = opCF + invCF + finCF, closing = CF_STMT.opening + netCF;

  // VAT analysis
  const outputVAT = VAT_SALES.reduce((s, r) => s + r.net * r.rate, 0);
  const inputVAT  = VAT_PURCH.reduce((s, r) => s + r.net * r.rate, 0);
  const totalSales = VAT_SALES.reduce((s, r) => s + r.net, 0);
  const taxableSales = VAT_SALES.filter((r) => r.rate > 0).reduce((s, r) => s + r.net, 0);
  const taxableRatio = totalSales ? taxableSales / totalSales : 0;
  const recoverable = Math.round(inputVAT * taxableRatio);
  const irrecoverable = inputVAT - recoverable;
  const netVAT = outputVAT - recoverable;   // > 0 payable to KRA

  const tabs = [["overview","Overview"],["pl","Trading & P&L"],["animalpl","P&L per animal"],["bs","Balance sheet"],["cf","Cash flow"],["vat","VAT analysis"]];
  const printBtn = (
    <button onClick={() => window.print()} className={`flex items-center gap-1.5 px-2.5 h-8 rounded-lg text-xs font-medium border ${t.border} ${t.chip} ${t.hover} ${t.strong}`}><Printer size={13} /> Print</button>
  );

  return (
    <div className="space-y-5">
      <Head t={t} title="Finance" sub="Performance, position and cash — statements for NgoroFarm" />

      <div className={`flex gap-1 p-1 rounded-xl ${t.chip} w-full sm:w-fit overflow-x-auto`}>
        {tabs.map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`px-3 sm:px-4 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${tab === k ? "bg-emerald-600 text-white shadow-sm" : `${t.muted} ${t.hover}`}`}>{l}</button>
        ))}
      </div>

      {tab === "overview" && (
        <>
          <div className="grid grid-cols-3 gap-3">
            <Stat t={t} label="Income (5mo)" value={money(income)} sub="Milk 71% · sales 24%" icon={ArrowUpRight} tone="emerald" />
            <Stat t={t} label="Expenses" value={money(expense)} sub="Feed 58% · vet 19%" icon={ArrowDownRight} tone="amber" />
            <Stat t={t} label="Net profit" value={money(income - expense)} sub={`${Math.round((1 - expense / income) * 100)}% margin`} icon={TrendingUp} tone="lime" />
          </div>
          <Card t={t}>
            <CardTitle t={t} icon={Beef} title="Profit by animal (per month)" />
            <div className="h-64">
              <ResponsiveContainer>
                <BarChart data={perAnimal} layout="vertical" margin={{ left:8, right:24, top:8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={t.grid} horizontal={false} />
                  <XAxis type="number" tick={{ fill:t.axis, fontSize:12 }} axisLine={false} tickLine={false} tickFormatter={(v)=>`${v/1000}k`} />
                  <YAxis type="category" dataKey="name" tick={{ fill:t.axis, fontSize:12 }} axisLine={false} tickLine={false} width={64} />
                  <Tooltip contentStyle={t.tip} formatter={(v)=>money(v)} />
                  <Bar dataKey="profit" radius={[0,4,4,0]}>{perAnimal.map((p,i)=><Cell key={i} fill={p.profit<0?"#e11d48":"#15803d"} />)}</Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </>
      )}

      {tab === "pl" && (
        <Card t={t} className="max-w-2xl">
          <CardTitle t={t} icon={FileText} title="Trading, Profit & Loss" right={<div className="flex items-center gap-2"><span className={`text-xs ${t.muted} hidden sm:block`}>{PL_STMT.period}</span>{printBtn}</div>} />
          <SLabel t={t}>Revenue</SLabel>
          {PL_STMT.revenue.map((r) => <Ln key={r.k} t={t} k={r.k} v={r.v} lvl={1} />)}
          <Ln t={t} k="Total revenue" v={totRev} bold top />
          <SLabel t={t}>Cost of sales</SLabel>
          {PL_STMT.cos.map((r) => <Ln key={r.k} t={t} k={r.k} v={-r.v} lvl={1} />)}
          <Ln t={t} k="Total cost of sales" v={-totCos} bold top />
          <Ln t={t} k="Gross profit" v={gross} bold tone="emerald" top big />
          <SLabel t={t}>Operating expenses</SLabel>
          {PL_STMT.opex.map((r) => <Ln key={r.k} t={t} k={r.k} v={-r.v} lvl={1} />)}
          <Ln t={t} k="Total operating expenses" v={-totOpex} bold top />
          <Ln t={t} k="Operating profit" v={opProfit} bold top />
          <Ln t={t} k="Finance costs (loan interest)" v={-PL_STMT.finance} lvl={1} />
          <Ln t={t} k="Net profit before tax" v={npbt} bold tone={npbt >= 0 ? "emerald" : "rose"} top big />
          <div className="mt-3 px-3 py-2 rounded-lg text-xs flex items-center justify-between" style={tint("emerald")}>
            <span>Net margin</span><span className="nf-num font-semibold">{Math.round(npbt / totRev * 100)}%</span>
          </div>
        </Card>
      )}

      {tab === "bs" && (
        <Card t={t} className="max-w-2xl">
          <CardTitle t={t} icon={Scale} title="Balance sheet" right={<div className="flex items-center gap-2"><span className={`text-xs ${t.muted} hidden sm:block`}>{BS_STMT.date}</span>{printBtn}</div>} />
          <SLabel t={t}>Non-current assets</SLabel>
          {BS_STMT.nonCurrent.map((r) => <Ln key={r.k} t={t} k={r.k} v={r.v} lvl={1} />)}
          <Ln t={t} k="Total non-current assets" v={totNCA} bold top />
          <SLabel t={t}>Current assets</SLabel>
          {BS_STMT.current.map((r) => <Ln key={r.k} t={t} k={r.k} v={r.v} lvl={1} />)}
          <Ln t={t} k="Total current assets" v={totCA} bold top />
          <Ln t={t} k="TOTAL ASSETS" v={totAssets} bold tone="emerald" top big />

          <SLabel t={t}>Equity</SLabel>
          {BS_STMT.equity.map((r) => <Ln key={r.k} t={t} k={r.k} v={r.v} lvl={1} />)}
          <Ln t={t} k="Total equity" v={totEq} bold top />
          <SLabel t={t}>Non-current liabilities</SLabel>
          {BS_STMT.ncLiab.map((r) => <Ln key={r.k} t={t} k={r.k} v={r.v} lvl={1} />)}
          <SLabel t={t}>Current liabilities</SLabel>
          {BS_STMT.cLiab.map((r) => <Ln key={r.k} t={t} k={r.k} v={r.v} lvl={1} />)}
          <Ln t={t} k="Total liabilities" v={totLiab} bold top />
          <Ln t={t} k="TOTAL EQUITY & LIABILITIES" v={totEL} bold tone="emerald" top big />
          <div className="mt-3 px-3 py-2 rounded-lg text-xs flex items-center gap-2" style={tint(totAssets === totEL ? "emerald" : "rose")}>
            <CircleCheck size={14} /> {totAssets === totEL ? "Balanced — assets equal equity plus liabilities." : "Out of balance — review entries."}
          </div>
        </Card>
      )}

      {tab === "cf" && (
        <Card t={t} className="max-w-2xl">
          <CardTitle t={t} icon={Banknote} title="Cash flow statement" right={<div className="flex items-center gap-2"><span className={`text-xs ${t.muted} hidden sm:block`}>{CF_STMT.period}</span>{printBtn}</div>} />
          <SLabel t={t}>Operating activities</SLabel>
          {CF_STMT.operating.map((r) => <Ln key={r.k} t={t} k={r.k} v={r.v} lvl={1} />)}
          <Ln t={t} k="Net cash from operating activities" v={opCF} bold tone="emerald" top />
          <SLabel t={t}>Investing activities</SLabel>
          {CF_STMT.investing.map((r) => <Ln key={r.k} t={t} k={r.k} v={r.v} lvl={1} />)}
          <Ln t={t} k="Net cash used in investing" v={invCF} bold top />
          <SLabel t={t}>Financing activities</SLabel>
          {CF_STMT.financing.map((r) => <Ln key={r.k} t={t} k={r.k} v={r.v} lvl={1} />)}
          <Ln t={t} k="Net cash used in financing" v={finCF} bold top />
          <Ln t={t} k="Net change in cash" v={netCF} bold tone={netCF >= 0 ? "emerald" : "rose"} top />
          <Ln t={t} k="Cash at 1 Jan 2026" v={CF_STMT.opening} />
          <Ln t={t} k="Cash at 31 Jul 2026" v={closing} bold tone="emerald" top big />
        </Card>
      )}

      {tab === "vat" && (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <Stat t={t} label="Output VAT" value={money(outputVAT)} sub="on taxable sales" icon={ArrowUpRight} tone="sky" />
            <Stat t={t} label="Input VAT" value={money(inputVAT)} sub="incurred on purchases" icon={ArrowDownRight} tone="amber" />
            <Stat t={t} label="Net VAT payable" value={money(netVAT)} sub="to KRA (after apportionment)" icon={Receipt} tone={netVAT >= 0 ? "rose" : "emerald"} />
          </div>

          <Card t={t} className="overflow-x-auto">
            <CardTitle t={t} icon={ArrowUpRight} title="Output VAT — sales by treatment" right={<span className={`text-xs ${t.muted} hidden sm:block`}>YTD 2026</span>} />
            <table style={{ minWidth: 520 }} className="w-full text-sm">
              <thead><tr className={`text-xs ${t.muted} border-b ${t.border}`}>
                <th className="py-2 text-left font-medium">Supply</th><th className="py-2 text-left font-medium">Treatment</th><th className="py-2 text-right font-medium">Net</th><th className="py-2 text-right font-medium">VAT</th>
              </tr></thead>
              <tbody>
                {VAT_SALES.map((r) => (
                  <tr key={r.k} className={`border-b ${t.border}`}>
                    <td className={`py-2.5 ${t.strong}`}>{r.k}</td>
                    <td className="py-2.5"><span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={tint(vatTone(r.treat))}>{r.treat}</span></td>
                    <td className={`py-2.5 text-right nf-num ${t.muted}`}>{money(r.net)}</td>
                    <td className={`py-2.5 text-right nf-num font-semibold ${t.strong}`}>{money(Math.round(r.net * r.rate))}</td>
                  </tr>
                ))}
                <tr><td className={`py-2.5 font-semibold ${t.strong}`}>Total</td><td /><td className={`py-2.5 text-right nf-num font-semibold ${t.strong}`}>{money(totalSales)}</td><td className={`py-2.5 text-right nf-num font-bold ${t.strong}`}>{money(outputVAT)}</td></tr>
              </tbody>
            </table>
          </Card>

          <Card t={t} className="overflow-x-auto">
            <CardTitle t={t} icon={ArrowDownRight} title="Input VAT — purchases by treatment" />
            <table style={{ minWidth: 520 }} className="w-full text-sm">
              <thead><tr className={`text-xs ${t.muted} border-b ${t.border}`}>
                <th className="py-2 text-left font-medium">Purchase</th><th className="py-2 text-left font-medium">Treatment</th><th className="py-2 text-right font-medium">Net</th><th className="py-2 text-right font-medium">VAT</th>
              </tr></thead>
              <tbody>
                {VAT_PURCH.map((r) => (
                  <tr key={r.k} className={`border-b ${t.border}`}>
                    <td className={`py-2.5 ${t.strong}`}>{r.k}</td>
                    <td className="py-2.5"><span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={tint(vatTone(r.treat))}>{r.treat}</span></td>
                    <td className={`py-2.5 text-right nf-num ${t.muted}`}>{money(r.net)}</td>
                    <td className={`py-2.5 text-right nf-num font-semibold ${t.strong}`}>{money(Math.round(r.net * r.rate))}</td>
                  </tr>
                ))}
                <tr><td className={`py-2.5 font-semibold ${t.strong}`}>Total</td><td /><td /><td className={`py-2.5 text-right nf-num font-bold ${t.strong}`}>{money(inputVAT)}</td></tr>
              </tbody>
            </table>
          </Card>

          <Card t={t} className="max-w-2xl">
            <CardTitle t={t} icon={Receipt} title="VAT position" right={printBtn} />
            <Ln t={t} k="Output VAT on taxable sales" v={outputVAT} />
            <Ln t={t} k="Input VAT incurred" v={inputVAT} />
            <Ln t={t} k={`Less: irrecoverable on exempt supplies (${Math.round((1 - taxableRatio) * 100)}%)`} v={-irrecoverable} lvl={1} />
            <Ln t={t} k="Recoverable input VAT" v={recoverable} bold top />
            <Ln t={t} k="Net VAT payable to KRA" v={netVAT} bold tone={netVAT >= 0 ? "rose" : "emerald"} top big />
            <div className="mt-3 px-3 py-2.5 rounded-lg text-xs" style={tint("amber")}>
              <b>Why so little is reclaimable:</b> NgoroFarm's main supplies — unprocessed milk and live animals — are exempt, so only the taxable share of turnover ({Math.round(taxableRatio * 100)}%) of input VAT can be reclaimed. The rest ({money(irrecoverable)}) is absorbed as a cost and already sits in expenses.
            </div>
            <p className={`text-xs ${t.muted} mt-3`}>VAT is filed monthly on iTax (VAT3 return) by the 20th of the following month. Treatments here are illustrative — livestock and unprocessed-produce rules vary and change; confirm current KRA classifications. This isn't tax advice.</p>
          </Card>
        </div>
      )}

      {tab === "animalpl" && (() => {
        const rows = ANIMAL_PL.map((a) => ({ a, p: animalPL(a) }));
        const tot = rows.reduce((s, { p }) => ({ rev: s.rev + p.rev, direct: s.direct + p.direct, gross: s.gross + p.gross, net: s.net + p.net }), { rev:0, direct:0, gross:0, net:0 });
        const sel = ANIMAL_PL[selAnimal], sp = animalPL(sel);
        return (
          <div className="grid lg:grid-cols-3 gap-4">
            <Card t={t} className="lg:col-span-2 overflow-x-auto">
              <CardTitle t={t} icon={Beef} title="Profit & loss by animal" right={<span className={`text-xs ${t.muted} hidden sm:block`}>YTD 2026 · tap a row</span>} />
              <table style={{ minWidth: 560 }} className="w-full text-sm">
                <thead><tr className={`text-xs ${t.muted} border-b ${t.border}`}>
                  <th className="py-2 text-left font-medium">Animal</th>
                  <th className="py-2 text-right font-medium">Revenue</th>
                  <th className="py-2 text-right font-medium">Direct</th>
                  <th className="py-2 text-right font-medium">Gross</th>
                  <th className="py-2 text-right font-medium">Net profit</th>
                  <th className="py-2 text-right font-medium">Margin</th>
                </tr></thead>
                <tbody>
                  {rows.map(({ a, p }, i) => {
                    const on = selAnimal === i;
                    return (
                      <tr key={a.id} onClick={() => setSelAnimal(i)} className={`border-b ${t.border} cursor-pointer ${on ? "" : t.hover}`} style={on ? { backgroundColor: TONE.emerald + "14" } : undefined}>
                        <td className="py-2.5"><div className={`font-semibold ${t.strong}`}>{a.name}</div><div className={`text-xs ${t.muted}`}>{a.id}</div></td>
                        <td className={`py-2.5 text-right nf-num ${t.muted}`}>{money(p.rev)}</td>
                        <td className={`py-2.5 text-right nf-num ${t.muted}`}>{money(p.direct)}</td>
                        <td className={`py-2.5 text-right nf-num ${t.strong}`}>{money(p.gross)}</td>
                        <td className="py-2.5 text-right nf-num font-bold" style={{ color: solid(p.net >= 0 ? "emerald" : "rose") }}>{money(p.net)}</td>
                        <td className="py-2.5 text-right"><span className="text-xs font-semibold px-2 py-0.5 rounded-full nf-num" style={tint(p.net >= 0 ? "emerald" : "rose")}>{p.margin}%</span></td>
                      </tr>
                    );
                  })}
                  <tr>
                    <td className={`py-2.5 font-semibold ${t.strong}`}>Herd total</td>
                    <td className={`py-2.5 text-right nf-num font-semibold ${t.strong}`}>{money(tot.rev)}</td>
                    <td className={`py-2.5 text-right nf-num font-semibold ${t.strong}`}>{money(tot.direct)}</td>
                    <td className={`py-2.5 text-right nf-num font-semibold ${t.strong}`}>{money(tot.gross)}</td>
                    <td className="py-2.5 text-right nf-num font-bold" style={{ color: solid("emerald") }}>{money(tot.net)}</td>
                    <td className={`py-2.5 text-right nf-num font-semibold ${t.muted}`}>{Math.round(tot.net / tot.rev * 100)}%</td>
                  </tr>
                </tbody>
              </table>
            </Card>

            <Card t={t}>
              <CardTitle t={t} icon={FileText} title={`${sel.name} · P&L`} right={<span className={`text-xs ${t.muted}`}>{sel.id}</span>} />
              <SLabel t={t}>Revenue</SLabel>
              <Ln t={t} k="Milk sales" v={sel.milk} lvl={1} />
              {sel.calf > 0 && <Ln t={t} k="Calf sales" v={sel.calf} lvl={1} />}
              <Ln t={t} k="Other income" v={sel.other} lvl={1} />
              <Ln t={t} k="Total revenue" v={sp.rev} bold top />
              <SLabel t={t}>Direct costs</SLabel>
              <Ln t={t} k="Feed & fodder" v={-sel.feed} lvl={1} />
              <Ln t={t} k="Vet & AI" v={-sel.vet} lvl={1} />
              <Ln t={t} k="Labour" v={-sel.labour} lvl={1} />
              <Ln t={t} k="Gross profit" v={sp.gross} bold tone={sp.gross >= 0 ? "emerald" : "rose"} top />
              <Ln t={t} k="Allocated overheads" v={-sel.overhead} lvl={1} />
              <Ln t={t} k="Net profit" v={sp.net} bold tone={sp.net >= 0 ? "emerald" : "rose"} top big />
              <div className="mt-3 px-3 py-2 rounded-lg text-xs flex items-center justify-between" style={tint(sp.net >= 0 ? "emerald" : "rose")}>
                <span>Net margin</span><span className="nf-num font-semibold">{sp.margin}%</span>
              </div>
            </Card>
          </div>
        );
      })()}
    </div>
  );
}

/* ================================================================== */
/*  Check-out — dispatch animals off the farm (sale / transfer / …)   */
/* ================================================================== */
const REASONS = [
  { key:"Sale",       status:"Sold",        tone:"emerald", pay:true  },
  { key:"Transfer",   status:"Transferred", tone:"sky",     pay:false },
  { key:"Slaughter",  status:"Slaughtered", tone:"stone",   pay:true  },
  { key:"Cull",       status:"Culled",      tone:"amber",   pay:true  },
  { key:"Death/Loss", status:"Dead",        tone:"rose",    pay:false },
];
const METHODS = [
  { key:"M-Pesa", icon:Smartphone },
  { key:"Cash",   icon:Banknote },
  { key:"Bank",   icon:Wallet },
];
function ref() {
  const s = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789";
  let r = ""; for (let i=0;i<8;i++) r += s[Math.floor(Math.random()*s.length)];
  return r;
}

function Checkout({ t, animals, setAnimals }) {
  const [cart, setCart]     = useState([]);
  const [reason, setReason] = useState("Sale");
  const [buyer, setBuyer]   = useState("");
  const [dest, setDest]     = useState("");
  const [phone, setPhone]   = useState("");
  const [method, setMethod] = useState("M-Pesa");
  const [amount, setAmount] = useState("");
  const [date, setDate]     = useState("2026-08-06");
  const [notes, setNotes]   = useState("");
  const [err, setErr]       = useState("");
  const [receipt, setRcpt]  = useState(null);
  const [invoice, setInvoice] = useState(null);   // completed dispatch to invoice
  const [q, setQ]           = useState("");   // active-herd search

  const R = REASONS.find((r) => r.key === reason);
  const available = animals.filter((a) => a.status === "Active" && !cart.includes(a.id)
    && (!q.trim() || [a.name, a.id, a.breed, a.sp].join(" ").toLowerCase().includes(q.trim().toLowerCase())));
  const picked    = cart.map((id) => animals.find((a) => a.id === id)).filter(Boolean);
  const total     = picked.reduce((s, a) => s + (a.value || 0), 0);

  const add = (id) => { setCart((c) => [...c, id]); setErr(""); };
  const drop = (id) => setCart((c) => c.filter((x) => x !== id));

  const confirm = () => {
    if (picked.length === 0) { setErr("Add at least one animal to check out."); return; }
    if (R.pay && !buyer.trim()) { setErr("Buyer / recipient name is required."); return; }
    const finalAmt = amount.trim() === "" ? total : Number(amount) || 0;
    const rec = {
      ref: "CHK-" + ref(), date, reason, status: R.status, tone: R.tone,
      buyer: buyer.trim() || "—", dest: dest.trim() || "—",
      method: R.pay ? method : "—", phone: phone.trim(),
      amount: R.pay ? finalAmt : 0, notes: notes.trim(),
      animals: picked.map((a) => ({ id: a.id, name: a.name, breed: a.breed, value: a.value })),
    };
    setAnimals((prev) => prev.map((a) => cart.includes(a.id) ? { ...a, status: R.status } : a));
    setRcpt(rec);
    setCart([]); setBuyer(""); setDest(""); setPhone(""); setAmount(""); setNotes("");
  };

  const field = "w-full h-10 px-3 rounded-lg text-sm outline-none border " + t.border + " " + t.input + " " + t.strong;
  const lbl   = `text-xs font-medium ${t.muted} mb-1 block`;

  if (invoice) return <CheckoutInvoice t={t} r={invoice} onBack={() => setInvoice(null)} />;

  return (
    <div className="space-y-5">
      <Head t={t} title="Check-out" sub="Dispatch animals leaving the farm — sale, transfer, slaughter or loss" />

      <div className="grid lg:grid-cols-3 gap-5">
        {/* Available animals */}
        <Card t={t} className="lg:col-span-1">
          <CardTitle t={t} icon={Beef} title="Active herd" right={<span className={`text-xs ${t.muted}`}>{available.length} available</span>} />
          <div className={`flex items-center gap-2 mb-3 px-3 h-10 rounded-lg ${t.input} border ${t.border}`}>
            <Search size={15} className={t.muted} />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, breed, tag…" className={`bg-transparent outline-none text-sm w-full ${t.strong}`} />
            {q && <button onClick={() => setQ("")} title="Clear" className={t.muted}><X size={15} /></button>}
          </div>
          <div className="space-y-2 max-h-[28rem] overflow-y-auto pr-1">
            {available.length === 0 ? <Empty t={t} msg={q ? "No animals match your search." : "No active animals left to check out."} /> : available.map((a) => (
              <div key={a.id} className={`flex items-center gap-3 p-2.5 rounded-lg border ${t.border} ${t.chip}`}>
                <div className="grid place-items-center w-9 h-9 rounded-lg text-lg" style={{ backgroundColor: TONE.emerald + "1a" }}>{SPECIES[a.sp]}</div>
                <div className="min-w-0 flex-1">
                  <div className={`text-sm font-semibold ${t.strong} truncate`}>{a.name} <span className={`font-normal ${t.muted}`}>· {a.id}</span></div>
                  <div className={`text-xs ${t.muted}`}>{a.breed} · {money(a.value)}</div>
                </div>
                <button onClick={() => add(a.id)} title="Add to check-out" className="grid place-items-center w-8 h-8 rounded-lg bg-emerald-600 text-white shadow-sm hover:bg-emerald-700"><Plus size={16}/></button>
              </div>
            ))}
          </div>
        </Card>

        {/* Cart + transaction */}
        <div className="lg:col-span-2 space-y-5">
          <Card t={t}>
            <CardTitle t={t} icon={ShoppingCart} title="Check-out list" right={<span className="text-sm font-bold" style={{ color: TONE.emerald }}>{money(total)}</span>} />
            {picked.length === 0 ? <Empty t={t} msg="Nothing added yet. Pick animals from the active herd on the left." /> : (
              <div className="space-y-2">
                {picked.map((a) => (
                  <div key={a.id} className={`flex items-center gap-3 p-2.5 rounded-lg border ${t.border}`}>
                    <div className="grid place-items-center w-9 h-9 rounded-lg text-lg" style={{ backgroundColor: TONE.emerald + "1a" }}>{SPECIES[a.sp]}</div>
                    <div className="min-w-0 flex-1">
                      <div className={`text-sm font-semibold ${t.strong} truncate`}>{a.name} <span className={`font-normal ${t.muted}`}>· {a.id}</span></div>
                      <div className={`text-xs ${t.muted}`}>{a.breed} · {money(a.value)}</div>
                    </div>
                    <button onClick={() => drop(a.id)} title="Remove" className={`grid place-items-center w-8 h-8 rounded-lg border ${t.border} ${t.chip}`} style={{ color: TONE.rose }}><Minus size={15}/></button>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card t={t}>
            <CardTitle t={t} icon={Truck} title="Dispatch details" />
            {err && <div className="mb-3 px-3 py-2 rounded-lg text-sm" style={tint("rose")}>{err}</div>}

            <label className={lbl}>Reason for check-out</label>
            <div className="flex flex-wrap gap-2 mb-4">
              {REASONS.map((r) => {
                const on = reason === r.key;
                return (
                  <button key={r.key} onClick={() => setReason(r.key)}
                    className="px-3 h-9 rounded-lg text-sm font-medium border transition-colors"
                    style={on ? { backgroundColor: solid(r.tone), color:"#fff", borderColor: solid(r.tone) }
                              : { borderColor: "transparent", ...tint(r.tone) }}>
                    {r.key}
                  </button>
                );
              })}
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              <div><label className={lbl}>{R.pay ? "Buyer / recipient" : "Recipient / authority"}</label>
                <div className={`flex items-center gap-2 ${field}`}><User size={15} className={t.muted}/><input className={`bg-transparent outline-none w-full ${t.strong}`} value={buyer} onChange={(e)=>setBuyer(e.target.value)} placeholder={R.pay ? "e.g. Nyeri Livestock Market" : "e.g. County Vet Office"} /></div>
              </div>
              <div><label className={lbl}>Destination</label>
                <div className={`flex items-center gap-2 ${field}`}><MapPin size={15} className={t.muted}/><input className={`bg-transparent outline-none w-full ${t.strong}`} value={dest} onChange={(e)=>setDest(e.target.value)} placeholder="e.g. Nyeri" /></div>
              </div>
              <div><label className={lbl}>Date</label>
                <div className={`flex items-center gap-2 ${field}`}><Calendar size={15} className={t.muted}/><input type="date" className={`bg-transparent outline-none w-full ${t.strong}`} value={date} onChange={(e)=>setDate(e.target.value)} /></div>
              </div>
              <div><label className={lbl}>Amount (KES){R.pay && <span className={t.muted}> · suggested {money(total)}</span>}</label>
                <input type="number" disabled={!R.pay} className={field} value={amount} onChange={(e)=>setAmount(e.target.value)} placeholder={R.pay ? String(total) : "n/a"} />
              </div>
            </div>

            {R.pay && (
              <div className="mt-4">
                <label className={lbl}>Payment method</label>
                <div className="flex flex-wrap gap-2">
                  {METHODS.map((m) => {
                    const on = method === m.key;
                    return (
                      <button key={m.key} onClick={() => setMethod(m.key)}
                        className={`flex items-center gap-1.5 px-3 h-9 rounded-lg text-sm font-medium border ${t.border} ${on ? "text-white shadow-sm" : `${t.chip} ${t.muted}`}`}
                        style={on ? { backgroundColor: TONE.emerald, borderColor: TONE.emerald } : undefined}>
                        <m.icon size={15}/> {m.key}
                      </button>
                    );
                  })}
                </div>
                {method === "M-Pesa" && (
                  <div className="mt-3"><label className={lbl}>M-Pesa phone number</label>
                    <div className={`flex items-center gap-2 ${field}`}><Smartphone size={15} className={t.muted}/><input className={`bg-transparent outline-none w-full ${t.strong}`} value={phone} onChange={(e)=>setPhone(e.target.value)} placeholder="07XX XXX XXX" /></div>
                  </div>
                )}
              </div>
            )}

            <div className="mt-4"><label className={lbl}>Notes</label>
              <textarea rows={2} className={`w-full px-3 py-2 rounded-lg text-sm outline-none border ${t.border} ${t.input} ${t.strong}`} value={notes} onChange={(e)=>setNotes(e.target.value)} placeholder="Transport, weighbridge ticket, permit no.…" />
            </div>

            <div className={`flex items-center justify-between gap-3 mt-5 pt-4 border-t ${t.border}`}>
              <div>
                <div className={`text-xs ${t.muted}`}>{picked.length} animal{picked.length===1?"":"s"} · {reason}</div>
                <div className="text-lg font-bold" style={{ color: TONE.emerald }}>{R.pay ? money(amount.trim()===""?total:Number(amount)||0) : "No payment"}</div>
              </div>
              <button onClick={confirm} className="flex items-center gap-2 px-5 h-11 rounded-xl bg-emerald-600 text-white text-sm font-semibold shadow-sm hover:bg-emerald-700">
                <Truck size={17}/> Confirm check-out
              </button>
            </div>
          </Card>
        </div>
      </div>

      {receipt && <CheckoutReceipt t={t} r={receipt} onClose={() => setRcpt(null)} onInvoice={(rec) => { setRcpt(null); setInvoice(rec); }} />}
    </div>
  );
}

function CheckoutReceipt({ t, r, onClose, onInvoice }) {
  return (
    <Modal t={t} onCancel={onClose} title="Check-out complete" icon={CircleCheck} tone={r.tone} narrow
      footer={<>
        {r.amount > 0 && <button onClick={() => onInvoice(r)} className={`px-4 h-10 rounded-lg text-sm font-medium border ${t.border} ${t.chip} ${t.hover} ${t.strong} flex items-center gap-1.5`}><FileText size={15}/> Invoice</button>}
        <button onClick={onClose} className="px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700">Done</button>
      </>}>
      <div className="text-center pb-3">
        <div className="grid place-items-center w-14 h-14 rounded-full mx-auto mb-2" style={tint(r.tone)}><Receipt size={26}/></div>
        <div className={`text-sm ${t.muted}`}>Dispatch reference</div>
        <div className={`text-lg font-bold tracking-wide ${t.strong}`}>{r.ref}</div>
      </div>
      <div className={`rounded-xl border ${t.border} ${t.chip} divide-y ${t.divide}`}>
        <Row t={t} k="Reason"   v={<StatusPill status={r.status} />} />
        <Row t={t} k="Recipient" v={r.buyer} />
        <Row t={t} k="Destination" v={r.dest} />
        <Row t={t} k="Date"     v={r.date} />
        {r.amount > 0 && <Row t={t} k="Payment" v={`${r.method}${r.phone?` · ${r.phone}`:""}`} />}
        {r.amount > 0 && <Row t={t} k="Amount" v={<b style={{ color: TONE.emerald }}>{money(r.amount)}</b>} />}
      </div>
      <div className="mt-3">
        <div className={`text-xs font-medium ${t.muted} mb-1.5`}>Animals checked out ({r.animals.length})</div>
        <div className="space-y-1.5">
          {r.animals.map((a) => (
            <div key={a.id} className={`flex justify-between text-sm px-3 py-2 rounded-lg border ${t.border}`}>
              <span className={t.strong}>{a.name} <span className={t.muted}>· {a.id}</span></span>
              <span className={t.muted}>{money(a.value)}</span>
            </div>
          ))}
        </div>
      </div>
      {r.method === "M-Pesa" && r.amount > 0 && (
        <div className="mt-3 px-3 py-2 rounded-lg text-xs" style={tint("emerald")}>
          <b>M-Pesa:</b> {money(r.amount)} request sent to {r.phone || "buyer"}. Awaiting confirmation (demo).
        </div>
      )}
    </Modal>
  );
}
function Row({ t, k, v }) {
  return <div className="flex items-center justify-between px-3 py-2.5 text-sm"><span className={t.muted}>{k}</span><span className={`font-medium ${t.strong}`}>{v}</span></div>;
}

/* ---- Invoice document generated from a completed check-out -------- */
function CheckoutInvoice({ t, r, onBack }) {
  const subtotal = r.animals.reduce((s, a) => s + (a.value || 0), 0);
  const vat = Math.round(subtotal * 0.16);
  const grand = subtotal + vat;
  const invNo = "INV-" + r.ref.replace(/^CHK-/, "");
  const due = "2026-08-20";
  const ink = "#111827", sub = "#6b7280", line = "#e5e7eb";

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <button onClick={onBack} className={`text-sm ${t.muted} flex items-center gap-1 hover:underline`}><ChevronRight size={14} className="rotate-180" /> Back to check-out</button>
        <button onClick={() => window.print()} className="flex items-center gap-1.5 px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700"><Printer size={16} /> Print / Save PDF</button>
      </div>

      <InvoiceDoc
        invNo={invNo}
        subtotal={subtotal} vat={vat} total={grand}
        billTo={<>
          <div style={{ fontSize: 14, fontWeight: 700, color: ink }}>{r.buyer}</div>
          {r.phone && <div style={{ fontSize: 13, color: ink }}>{r.phone}</div>}
          {r.dest && r.dest !== "—" && <div style={{ fontSize: 12, color: sub }}>{r.dest}</div>}
          <div style={{ fontSize: 12, color: sub, marginTop: 4 }}>Reason: {r.reason}</div>
        </>}
        details={<>
          <IRow k="Issued" v={r.date} />
          <IRow k="Due" v={due} />
          <IRow k="Dispatch ref" v={r.ref} />
          <div style={{ height: 1, background: line, margin: "8px 0" }} />
          <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, color: sub, marginBottom: 4 }}>Pay to</div>
          <div style={{ fontSize: 13, color: ink }}>{r.method !== "—" ? r.method : "M-Pesa Paybill 4••••2"}</div>
          <div style={{ fontSize: 13, color: ink }}>Account: {invNo}</div>
        </>}
        items={r.animals.map((a) => ({ title: `${a.name} · ${a.id}`, subtitle: a.breed, qty: 1, unit: money(a.value), amount: money(a.value) }))}
        extra={r.amount > 0 && r.amount !== subtotal
          ? <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 2px", fontSize: 12, color: sub }}><span>Agreed price at dispatch</span><span>{money(r.amount)}</span></div>
          : null}
        footerNote={<><b style={{ color: ink }}>Terms:</b> Payment due by {due}. Animals released on cleared payment. Livestock sold as seen; movement permit issued on dispatch.<span style={{ display: "block", marginTop: 6 }}>Thank you for your business — NgoroFarm, Nairutia.</span></>}
      />

      <p className={`text-xs ${t.muted} text-center`}>Invoice generated from dispatch {r.ref} · {r.animals.length} animal{r.animals.length === 1 ? "" : "s"} · VAT at Kenya's 16% standard rate.</p>
    </div>
  );
}

/* ================================================================== */
/*  Vet & advisory — vet requests, directory, knowledge library       */
/* ================================================================== */
function Advisory({ t }) {
  const [tickets, setTickets] = useState([
    { id:"VR-204", animal:"Nyota · NG-C-100", issue:"Mastitis follow-up",  status:"Open",      when:"Today 09:12" },
    { id:"VR-198", animal:"Malaika · NG-C-030", issue:"Pregnancy check",   status:"Scheduled", when:"Aug 8" },
    { id:"VR-187", animal:"Whole herd",        issue:"FMD vaccination round", status:"Closed",  when:"Jul 30" },
  ]);
  const vets = [
    { name:"Dr. Wanjiru Kamau", spec:"Dairy health & AI",         town:"Nyeri",    km:6,  rating:4.9, tone:"emerald" },
    { name:"Dr. Otieno Ochieng", spec:"Reproduction & obstetrics", town:"Karatina", km:12, rating:4.7, tone:"sky" },
    { name:"J. Mwangi (AHT)",   spec:"Vaccination & deworming",    town:"Mweiga",   km:4,  rating:4.6, tone:"amber" },
  ];
  const learn = [
    { title:"Spotting & treating mastitis early", tag:"Video",   min:"6 min", tone:"rose",    icon:PlayCircle },
    { title:"Timing AI to the heat cycle",        tag:"Audio",   min:"8 min", tone:"sky",     icon:Headphones },
    { title:"Calf feeding in the first 8 weeks",  tag:"Article", min:"5 min", tone:"lime",    icon:BookOpen },
    { title:"Least-cost dairy ration on a budget",tag:"Video",   min:"9 min", tone:"amber",   icon:PlayCircle },
    { title:"Preventing East Coast Fever",        tag:"Audio",   min:"7 min", tone:"emerald", icon:Headphones },
    { title:"Reading a milk-yield trend",         tag:"Article", min:"4 min", tone:"violet",  icon:BookOpen },
  ];
  const sColor = (s) => s === "Open" ? "amber" : s === "Scheduled" ? "sky" : "emerald";
  const request = () => setTickets((x) => [{ id:"VR-" + Math.floor(200 + Math.random()*99), animal:"Nyota · NG-C-100", issue:"New consultation request", status:"Open", when:"Just now" }, ...x]);

  return (
    <div className="space-y-5">
      <Head t={t} title="Vet & advisory" sub="Request a vet, reach vetted professionals, and learn — closing the gap with DigiCow-style services" />

      <div className="grid lg:grid-cols-3 gap-4">
        <Card t={t} className="lg:col-span-2">
          <CardTitle t={t} icon={Stethoscope} title="My vet requests"
            right={<button onClick={request} className="flex items-center gap-1 px-3 h-9 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700"><Plus size={15}/> Request a vet</button>} />
          <div className="overflow-x-auto">
            <table style={{ minWidth: 460 }} className="w-full text-sm">
              <thead><tr className={`text-xs ${t.muted} border-b ${t.border}`}>
                <th className="py-2 text-left font-medium">Ref</th><th className="py-2 text-left font-medium">Animal</th><th className="py-2 text-left font-medium">Issue</th><th className="py-2 text-left font-medium">Status</th><th className="py-2 text-left font-medium">When</th>
              </tr></thead>
              <tbody>
                {tickets.map((r) => (
                  <tr key={r.id} className={`border-b ${t.border}`}>
                    <td className={`py-2.5 font-mono text-xs ${t.strong}`}>{r.id}</td>
                    <td className={`py-2.5 ${t.strong}`}>{r.animal}</td>
                    <td className={`py-2.5 ${t.muted}`}>{r.issue}</td>
                    <td className="py-2.5"><span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={tint(sColor(r.status))}>{r.status}</span></td>
                    <td className={`py-2.5 text-xs ${t.muted}`}>{r.when}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card t={t}>
          <CardTitle t={t} icon={User} title="Vetted vets near you" />
          <div className="space-y-2">
            {vets.map((v) => (
              <div key={v.name} className={`p-3 rounded-xl border ${t.border} ${t.chip}`}>
                <div className="flex items-center gap-2">
                  <div className="grid place-items-center w-9 h-9 rounded-lg text-white font-bold text-xs" style={{ backgroundColor: solid(v.tone) }}>{v.name.split(" ")[0][0]}{v.name.split(" ")[1]?.[0] || ""}</div>
                  <div className="min-w-0 flex-1">
                    <div className={`text-sm font-semibold ${t.strong} truncate`}>{v.name}</div>
                    <div className={`text-xs ${t.muted} truncate`}>{v.spec}</div>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-2 text-xs">
                  <span className={t.muted}>{v.town} · {v.km} km</span>
                  <span className="flex items-center gap-1" style={{ color: TONE.amber }}><Star size={12} fill="currentColor" /> {v.rating}</span>
                </div>
                <button className="mt-2 w-full flex items-center justify-center gap-1.5 h-8 rounded-lg text-white text-xs font-medium" style={{ backgroundColor: TONE.emerald }}><Phone size={13}/> Request visit</button>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card t={t}>
        <CardTitle t={t} icon={GraduationCap} title="Knowledge library" right={<span className={`text-xs ${t.muted}`}>audio · video · articles</span>} />
        <div className="space-y-2">
          {learn.map((l) => (
            <button key={l.title} className={`w-full text-left p-3 rounded-xl border ${t.border} ${t.card} ${t.hover} transition-colors flex items-center gap-3`}>
              <span className="grid place-items-center w-10 h-10 rounded-lg shrink-0" style={tint(l.tone)}><l.icon size={18} /></span>
              <div className="min-w-0 flex-1">
                <div className={`text-sm font-semibold ${t.strong} truncate`}>{l.title}</div>
                <div className={`text-xs ${t.muted} mt-0.5`}>{l.tag} · {l.min}</div>
              </div>
              <ChevronRight size={16} className={`${t.muted} shrink-0`} />
            </button>
          ))}
        </div>
      </Card>
    </div>
  );
}

/* ================================================================== */
/*  Feed management — stock, rations, cost-per-litre                  */
/* ================================================================== */
const FEED_TYPES = [
  { type:"Concentrate",  tone:"emerald" },
  { type:"Forage",       tone:"lime" },
  { type:"Hay/Roughage", tone:"amber" },
  { type:"Supplement",   tone:"sky" },
  { type:"Mineral",      tone:"violet" },
];
const FEED_SEED = [
  { id:"F1", item:"Dairy meal (18% DCP)", type:"Concentrate",  kg:420, daily:64,  cost:52,  tone:"emerald" },
  { id:"F2", item:"Maize germ",           type:"Concentrate",  kg:180, daily:30,  cost:34,  tone:"lime" },
  { id:"F3", item:"Lucerne hay (bales)",  type:"Hay/Roughage", kg:95,  daily:40,  cost:28,  tone:"amber" },
  { id:"F4", item:"Mineral lick",         type:"Mineral",      kg:22,  daily:1.5, cost:180, tone:"sky" },
];

function FeedForm({ t, initial, onCancel, onSave }) {
  const [f, setF] = useState(initial
    ? { item:initial.item, type:initial.type || "Concentrate", kg:String(initial.kg), daily:String(initial.daily), cost:String(initial.cost) }
    : { item:"", type:"Concentrate", kg:"", daily:"", cost:"" });
  const [err, setErr] = useState("");
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const field = `w-full h-10 px-3 rounded-lg text-sm outline-none border ${t.border} ${t.input} ${t.strong}`;
  const lbl = `text-xs font-medium ${t.muted} mb-1 block`;

  const submit = () => {
    if (!f.item.trim()) { setErr("Feed name is required."); return; }
    const kg = Number(f.kg) || 0, daily = Number(f.daily) || 0, cost = Number(f.cost) || 0;
    if (daily <= 0) { setErr("Daily use must be greater than zero."); return; }
    const meta = FEED_TYPES.find((x) => x.type === f.type) || FEED_TYPES[0];
    onSave({ id: initial ? initial.id : "F" + Date.now(), item:f.item.trim(), type:f.type, kg, daily, cost, tone:meta.tone });
  };

  return (
    <Modal t={t} title={initial ? "Edit feed" : "Add feed"} icon={Wheat} tone="emerald" onCancel={onCancel}
      footer={<>
        <button onClick={onCancel} className={`px-4 h-10 rounded-lg text-sm font-medium border ${t.border} ${t.muted} ${t.hover}`}>Cancel</button>
        <button onClick={submit} className="px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700 flex items-center gap-1.5">{initial ? <><Save size={15} /> Save</> : <><Plus size={15} /> Add feed</>}</button>
      </>}>
      {err && <div className="mb-3 px-3 py-2 rounded-lg text-sm" style={tint("rose")}>{err}</div>}
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="sm:col-span-2">
          <label className={lbl}>Feed name</label>
          <input className={field} value={f.item} onChange={(e) => set("item", e.target.value)} placeholder="e.g. Dairy meal (18% DCP)" />
        </div>
        <div>
          <label className={lbl}>Type</label>
          <select className={field} value={f.type} onChange={(e) => set("type", e.target.value)}>
            {FEED_TYPES.map((x) => <option key={x.type} value={x.type}>{x.type}</option>)}
          </select>
        </div>
        <div>
          <label className={lbl}>Cost per kg (KES)</label>
          <input type="number" inputMode="numeric" className={field} value={f.cost} onChange={(e) => set("cost", e.target.value)} placeholder="0" />
        </div>
        <div>
          <label className={lbl}>On hand (kg)</label>
          <input type="number" inputMode="numeric" className={field} value={f.kg} onChange={(e) => set("kg", e.target.value)} placeholder="0" />
        </div>
        <div>
          <label className={lbl}>Daily use (kg)</label>
          <input type="number" inputMode="numeric" className={field} value={f.daily} onChange={(e) => set("daily", e.target.value)} placeholder="0" />
        </div>
      </div>
    </Modal>
  );
}

function Feed({ t }) {
  const [stock, setStock] = useState(FEED_SEED);
  const [form, setForm]   = useState(null);   // null | "new" | feed (edit)
  const rations = [
    { group:"Milking herd", head:6, kgHead:12, tone:"emerald" },
    { group:"Dry cows",     head:2, kgHead:7,  tone:"sky" },
    { group:"Heifers",      head:2, kgHead:6,  tone:"amber" },
    { group:"Calves",       head:2, kgHead:2.5,tone:"lime" },
  ];
  const dailyFeedCost = stock.reduce((s, f) => s + f.daily * f.cost, 0);
  const milkPerDay = 148;
  const feedCostPerL = dailyFeedCost / milkPerDay;
  const daysLeft = (f) => f.daily > 0 ? Math.floor(f.kg / f.daily) : 0;

  const saveFeed = (item) => { setStock((prev) => prev.some((x) => x.id === item.id) ? prev.map((x) => x.id === item.id ? item : x) : [...prev, item]); setForm(null); };
  const removeFeed = (id) => setStock((prev) => prev.filter((x) => x.id !== id));

  return (
    <div className="space-y-5">
      <Head t={t} title="Feed management" sub="Stock, rations and cost-per-litre — a standard module the smallholder apps skip" />

      <div className="grid sm:grid-cols-3 gap-3">
        <Stat t={t} label="Feed cost / day" value={money(dailyFeedCost)} sub="all groups" icon={Wheat} tone="amber" />
        <Stat t={t} label="Feed cost / litre" value={money(Math.round(feedCostPerL))} sub={`at ${milkPerDay} L/day`} icon={Milk} tone="emerald" />
        <Stat t={t} label="Low-stock feeds" value={String(stock.filter((f) => daysLeft(f) <= 3).length)} sub="≤ 3 days cover" icon={TriangleAlert} tone="rose" />
      </div>

      <Card t={t} className="overflow-x-auto">
        <CardTitle t={t} icon={Boxes} title="Feed store"
          right={<button onClick={() => setForm("new")} className="flex items-center gap-1 px-2.5 h-8 rounded-lg bg-emerald-600 text-white text-xs font-semibold shadow-sm hover:bg-emerald-700"><Plus size={14} /> Add feed</button>} />
        {stock.length === 0 ? <Empty t={t} msg="No feeds yet — add your first feed item." /> : (
          <table style={{ minWidth: 680 }} className="w-full text-sm">
            <thead><tr className={`text-xs ${t.muted} border-b ${t.border}`}>
              <th className="py-2 text-left font-medium">Feed</th><th className="py-2 text-left font-medium">Type</th><th className="py-2 text-left font-medium">On hand</th><th className="py-2 text-left font-medium">Daily use</th><th className="py-2 text-left font-medium">Days left</th><th className="py-2 text-left font-medium">Cost/kg</th><th className="py-2 text-right font-medium"></th>
            </tr></thead>
            <tbody>
              {stock.map((f) => {
                const d = daysLeft(f); const low = d <= 3;
                return (
                  <tr key={f.id} className={`group border-b ${t.border}`} style={low ? { backgroundColor: TONE.rose + "0f" } : undefined}>
                    <td className={`py-2.5 font-medium ${t.strong}`}>{f.item}</td>
                    <td className="py-2.5"><span className="text-xs font-medium px-2 py-0.5 rounded-full" style={tint(f.tone)}>{f.type}</span></td>
                    <td className={`py-2.5 nf-num ${t.muted}`}>{f.kg} kg</td>
                    <td className={`py-2.5 nf-num ${t.muted}`}>{f.daily} kg</td>
                    <td className="py-2.5"><span className="text-xs font-semibold px-2 py-0.5 rounded-full nf-num" style={tint(low ? "rose" : "emerald")}>{d} days</span></td>
                    <td className={`py-2.5 nf-num ${t.muted}`}>{money(f.cost)}</td>
                    <td className="py-2.5">
                      <div className="flex justify-end gap-1 opacity-60 sm:opacity-0 sm:group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                        <button onClick={() => setForm(f)} title="Edit" className={`grid place-items-center w-8 h-8 rounded-lg border ${t.border} ${t.chip}`} style={{ color: TONE.sky }}><Pencil size={14} /></button>
                        <button onClick={() => removeFeed(f.id)} title="Delete" className={`grid place-items-center w-8 h-8 rounded-lg border ${t.border} ${t.chip}`} style={{ color: TONE.rose }}><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </Card>

      <Card t={t}>
        <CardTitle t={t} icon={Beef} title="Ration plan by group" />
        <div className="space-y-2">
          {rations.map((r) => (
            <div key={r.group} className={`flex items-center gap-3 p-3 rounded-xl border ${t.border} ${t.chip}`}>
              <span className="grid place-items-center w-9 h-9 rounded-lg shrink-0" style={tint(r.tone)}><Wheat size={16} /></span>
              <div className={`text-sm font-semibold ${t.strong} flex-1 min-w-0 truncate`}>{r.group}</div>
              <div className="flex items-center gap-5 shrink-0">
                <div className="text-right hidden sm:block"><div className={`text-xs ${t.muted}`}>Head</div><div className={`text-sm nf-num ${t.strong}`}>{r.head}</div></div>
                <div className="text-right hidden sm:block"><div className={`text-xs ${t.muted}`}>kg / head</div><div className={`text-sm nf-num ${t.strong}`}>{r.kgHead}</div></div>
                <div className="text-right"><div className={`text-xs ${t.muted}`}>Daily kg</div><div className={`text-sm nf-num ${t.strong}`}>{(r.head * r.kgHead).toFixed(1)}</div></div>
                <div className="text-right"><div className={`text-xs ${t.muted}`}>Share</div><div className={`text-sm nf-num ${t.strong}`}>{Math.round((r.head * r.kgHead) / rations.reduce((s, x) => s + x.head * x.kgHead, 0) * 100)}%</div></div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {form && <FeedForm t={t} initial={form === "new" ? null : form} onCancel={() => setForm(null)} onSave={saveFeed} />}
    </div>
  );
}

/* ================================================================== */
/*  Cooperative — milk deliveries & M-Pesa payout (the KE channel)    */
/* ================================================================== */
function Cooperative({ t }) {
  const rate = 52; // KES / litre
  const deliveries = [
    { date:"Aug 6", am:74, pm:70, status:"Accepted" },
    { date:"Aug 5", am:72, pm:69, status:"Accepted" },
    { date:"Aug 4", am:75, pm:71, status:"Accepted" },
    { date:"Aug 3", am:70, pm:66, status:"1.5 L rejected" },
    { date:"Aug 2", am:73, pm:70, status:"Accepted" },
  ];
  const litres = deliveries.reduce((s, d) => s + d.am + d.pm, 0);
  const monthLitres = 3980;
  const gross = monthLitres * rate;
  const deductions = [
    { label:"AI & vet (checkoff)", amt:2400 },
    { label:"Dairy meal on credit", amt:18400 },
    { label:"SACCO savings",        amt:5000 },
  ];
  const dedTotal = deductions.reduce((s, d) => s + d.amt, 0);
  const net = gross - dedTotal;

  return (
    <div className="space-y-5">
      <Head t={t} title="Kwikas Sacco" sub="Milk deliveries and monthly M-Pesa payout — how Kenyan dairy actually gets paid" />

      <div className="grid lg:grid-cols-3 gap-4">
        <Card t={t} className="lg:col-span-2">
          <CardTitle t={t} icon={Milk} title="Recent milk deliveries"
            right={<span className={`text-xs ${t.muted}`}>Kwikas Sacco · member NG-0142 · {money(rate)}/L</span>} />
          <DataTable t={t} minWidth={460} rows={deliveries} rowKey="date"
            columns={[
              { label:"Date",    render:(d)=><span className={`font-medium ${t.strong}`}>{d.date}</span> },
              { label:"Morning", render:(d)=><span className={`nf-num ${t.muted}`}>{d.am} L</span> },
              { label:"Evening", render:(d)=><span className={`nf-num ${t.muted}`}>{d.pm} L</span> },
              { label:"Total",   render:(d)=><span className={`font-semibold nf-num ${t.strong}`}>{d.am + d.pm} L</span> },
              { label:"Status",  render:(d)=><span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={tint(d.status !== "Accepted" ? "amber" : "emerald")}>{d.status}</span> },
            ]} />
          <div className={`pt-3 text-xs ${t.muted}`}>Last 5 days delivered: <b className={t.strong}>{litres} L</b></div>
        </Card>

        <Card t={t}>
          <CardTitle t={t} icon={Smartphone} title="This month's payout" />
          <div className={`rounded-xl border ${t.border} ${t.chip} divide-y ${t.divide}`}>
            <Row t={t} k="Delivered" v={`${monthLitres.toLocaleString()} L`} />
            <Row t={t} k={`Gross @ ${money(rate)}/L`} v={money(gross)} />
            {deductions.map((d) => <Row key={d.label} t={t} k={d.label} v={<span style={{ color: TONE.rose }}>-{money(d.amt)}</span>} />)}
          </div>
          <div className="flex items-center justify-between mt-3 px-1">
            <span className={`text-sm font-medium ${t.strong}`}>Net to M-Pesa</span>
            <span className="text-lg font-bold" style={{ color: TONE.emerald }}>{money(net)}</span>
          </div>
          <div className="mt-3 px-3 py-2 rounded-lg text-xs flex items-center gap-2" style={tint("emerald")}>
            <Smartphone size={14} /> Paid to 07•• ••• •142 on the 5th of next month.
          </div>
        </Card>
      </div>

      <div className="grid sm:grid-cols-3 gap-3">
        <Stat t={t} label="Monthly litres" value={monthLitres.toLocaleString()} sub="to cooperative" icon={Milk} tone="sky" />
        <Stat t={t} label="Gross value" value={money(gross)} sub={`@ ${money(rate)}/L`} icon={Wallet} tone="lime" />
        <Stat t={t} label="Net payout" value={money(net)} sub="after deductions" icon={Handshake} tone="emerald" />
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Payments — pay for services & inputs via M-Pesa (STK push)        */
/* ================================================================== */
const BILLS_SEED = [
  { id:"B1", label:"Vet consultation — mastitis follow-up", payee:"Dr. Wanjiru Kamau", cat:"Vet",      amount:1200,  tone:"rose",    icon:Stethoscope },
  { id:"B2", label:"Dairy meal — 10 bags on order",         payee:"Nyala Agrovet",     cat:"Feed",     amount:18400, tone:"amber",   icon:Wheat },
  { id:"B3", label:"AI service — sexed semen straw",         payee:"KAGRC",             cat:"Breeding", amount:2500,  tone:"sky",     icon:Dna },
  { id:"B4", label:"Sacco checkoff — August",                payee:"Kwikas Sacco",      cat:"Sacco",    amount:2400,  tone:"emerald", icon:Handshake },
  { id:"B5", label:"Deworming drugs restock",                payee:"Mweiga Agrovet",    cat:"Vet",      amount:1600,  tone:"lime",    icon:Syringe },
];
const PAY_HISTORY = [
  { ref:"QК7HX2P9", payee:"Nyala Agrovet",      amount:12800, method:"M-Pesa", when:"Jul 28" },
  { ref:"QК4RT1M6", payee:"Dr. Otieno Ochieng", amount:1800,  method:"M-Pesa", when:"Jul 21" },
  { ref:"—",         payee:"Farm wages",         amount:9000,  method:"Cash",   when:"Jul 20" },
];
function payRef() {
  const s = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789"; let r = "";
  for (let i = 0; i < 8; i++) r += s[Math.floor(Math.random() * s.length)];
  return r;
}

/* ================================================================== */
/*  Payments & sales — merged: pay bills (out) + check-out (in)       */
/* ================================================================== */
function Transactions({ t, tab, setTab, animals, setAnimals }) {
  return (
    <div className="space-y-5">
      <div className={`flex gap-1 p-1 rounded-xl ${t.chip} w-full sm:w-fit`}>
        {[["pay","Pay bills"], ["checkout","Check-out / sales"]].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`px-3 sm:px-4 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${tab === k ? "bg-emerald-600 text-white shadow-sm" : `${t.muted} ${t.hover}`}`}>{l}</button>
        ))}
      </div>
      {tab === "pay" && <PaymentsM t={t} />}
      {tab === "checkout" && <Checkout t={t} animals={animals} setAnimals={setAnimals} />}
    </div>
  );
}

const PURCH_CATS = [
  { cat:"Feed",      tone:"amber",   icon:Wheat },
  { cat:"Vet",       tone:"rose",    icon:Stethoscope },
  { cat:"Breeding",  tone:"sky",     icon:Dna },
  { cat:"Equipment", tone:"violet",  icon:Boxes },
  { cat:"Utilities", tone:"emerald", icon:Droplets },
  { cat:"Sacco",     tone:"emerald", icon:Handshake },
  { cat:"Labour",    tone:"lime",    icon:UserCog },
  { cat:"Other",     tone:"stone",   icon:Receipt },
];

function AddInvoice({ t, initial, onCancel, onSave }) {
  const [f, setF] = useState(initial
    ? { payee:initial.payee, label:initial.label, cat:initial.cat, amount:String(initial.amount), invNo:initial.invNo || "", date:initial.date || TODAY, due:initial.due || "" }
    : { payee:"", label:"", cat:"Feed", amount:"", invNo:"", date:TODAY, due:"" });
  const [err, setErr] = useState("");
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const field = `w-full h-10 px-3 rounded-lg text-sm outline-none border ${t.border} ${t.input} ${t.strong}`;
  const lbl = `text-xs font-medium ${t.muted} mb-1 block`;

  const submit = () => {
    if (!f.payee.trim() || !f.label.trim()) { setErr("Supplier and description are required."); return; }
    const amt = Number(f.amount) || 0;
    if (amt <= 0) { setErr("Enter a valid amount."); return; }
    const meta = PURCH_CATS.find((c) => c.cat === f.cat) || PURCH_CATS[PURCH_CATS.length - 1];
    onSave({ id: initial ? initial.id : "B" + Date.now(), label:f.label.trim(), payee:f.payee.trim(), cat:f.cat, amount:amt, tone:meta.tone, icon:meta.icon, invNo:f.invNo.trim(), date:f.date, due:f.due });
  };

  return (
    <Modal t={t} title={initial ? "Edit purchase invoice" : "Add purchase invoice"} icon={FileText} tone="emerald" onCancel={onCancel}
      footer={<>
        <button onClick={onCancel} className={`px-4 h-10 rounded-lg text-sm font-medium border ${t.border} ${t.muted} ${t.hover}`}>Cancel</button>
        <button onClick={submit} className="px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700 flex items-center gap-1.5">{initial ? <><Save size={15} /> Save changes</> : <><Plus size={15} /> Add to bills</>}</button>
      </>}>
      {err && <div className="mb-3 px-3 py-2 rounded-lg text-sm" style={tint("rose")}>{err}</div>}
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="sm:col-span-2">
          <label className={lbl}>Supplier / payee</label>
          <input className={field} value={f.payee} onChange={(e) => set("payee", e.target.value)} placeholder="e.g. Nyala Agrovet" />
        </div>
        <div className="sm:col-span-2">
          <label className={lbl}>Description</label>
          <input className={field} value={f.label} onChange={(e) => set("label", e.target.value)} placeholder="e.g. Dairy meal — 10 bags" />
        </div>
        <div>
          <label className={lbl}>Category</label>
          <select className={field} value={f.cat} onChange={(e) => set("cat", e.target.value)}>
            {PURCH_CATS.map((c) => <option key={c.cat} value={c.cat}>{c.cat}</option>)}
          </select>
        </div>
        <div>
          <label className={lbl}>Amount (KES)</label>
          <input type="number" inputMode="numeric" className={field} value={f.amount} onChange={(e) => set("amount", e.target.value)} placeholder="0" />
        </div>
        <div>
          <label className={lbl}>Invoice no. (optional)</label>
          <input className={field} value={f.invNo} onChange={(e) => set("invNo", e.target.value)} placeholder="INV-…" />
        </div>
        <div>
          <label className={lbl}>Invoice date</label>
          <input type="date" className={field} value={f.date} onChange={(e) => set("date", e.target.value)} />
        </div>
        <div className="sm:col-span-2">
          <label className={lbl}>Due date (optional)</label>
          <input type="date" className={field} value={f.due} onChange={(e) => set("due", e.target.value)} />
        </div>
      </div>
    </Modal>
  );
}

function Payments({ t }) {
  const [bills, setBills]   = useState(BILLS_SEED);
  const [sel, setSel]       = useState(() => new Set());
  const [method, setMethod] = useState("M-Pesa");
  const [phone, setPhone]   = useState("0712 345 142");
  const [stk, setStk]       = useState(null);          // null | "pushing" | {receipt}
  const [hist, setHist]     = useState(PAY_HISTORY);
  const [err, setErr]       = useState("");
  const [form, setForm]     = useState(null);    // null | "new" | bill (edit)

  const removeBill = useCallback((id) => {
    setBills((b) => b.filter((x) => x.id !== id));
    setSel((s) => { const n = new Set(s); n.delete(id); return n; });
  }, []);
  const saveBill = useCallback((bill) => {
    setBills((prev) => prev.some((x) => x.id === bill.id) ? prev.map((x) => x.id === bill.id ? bill : x) : [bill, ...prev]);
    setForm(null);
  }, []);

  const picked      = useMemo(() => bills.filter((b) => sel.has(b.id)), [bills, sel]);
  const total       = useMemo(() => picked.reduce((s, b) => s + b.amount, 0), [picked]);
  const outstanding = useMemo(() => bills.reduce((s, b) => s + b.amount, 0), [bills]);
  const paidPeriod  = useMemo(() => hist.reduce((s, h) => s + h.amount, 0), [hist]);
  const allSel      = bills.length > 0 && picked.length === bills.length;

  const toggle    = useCallback((id) => setSel((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; }), []);
  const selectAll = useCallback(() => setSel(new Set(bills.map((b) => b.id))), [bills]);
  const clearSel  = useCallback(() => setSel(new Set()), []);

  const pay = useCallback(() => {
    if (picked.length === 0) { setErr("Select at least one bill to pay."); return; }
    if (method === "M-Pesa" && !phone.trim()) { setErr("Enter the M-Pesa phone number."); return; }
    setErr(""); setStk("pushing");
    setTimeout(() => {
      const ref = payRef();
      const paidIds = new Set(sel);
      const paid = bills.filter((b) => paidIds.has(b.id));
      setStk({ receipt: { ref, amount: paid.reduce((s, b) => s + b.amount, 0), method, phone, items: paid } });
      setHist((h) => [...paid.map((b) => ({ ref: method === "M-Pesa" ? "Q" + ref : "—", payee: b.payee, amount: b.amount, method, when: "Just now" })), ...h]);
      setBills((b) => b.filter((x) => !paidIds.has(x.id)));
      setSel(new Set());
    }, 1700);
  }, [picked, method, phone, sel, bills]);

  const methods = [{ key:"M-Pesa", icon:Smartphone }, { key:"Card", icon:CreditCard }, { key:"Cash", icon:Banknote }];
  const field = `w-full h-10 px-3 rounded-lg text-sm outline-none border ${t.border} ${t.input} ${t.strong}`;

  return (
    <div className="space-y-5">
      <Head t={t} title="Payments" sub="Pay vet, feed, AI and inputs — M-Pesa STK push, card or cash" />

      {/* Summary */}
      <Card t={t} className="relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 pointer-events-none select-none">
          <span style={{ position:"absolute", right:12,  top:-8,   fontSize:92, opacity:0.09, transform:"rotate(-6deg)" }}>🐐</span>
          <span style={{ position:"absolute", right:104, bottom:-16, fontSize:78, opacity:0.08 }}>🐑</span>
          <span style={{ position:"absolute", right:186, top:0,    fontSize:72, opacity:0.07, transform:"rotate(5deg)" }}>🐖</span>
        </div>
        <div className="relative" style={{ zIndex: 1 }}>
          <div className={`grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x ${t.divide}`}>
            {[
              { label:"Outstanding",      value:money(outstanding), sub:`${bills.length} bill${bills.length === 1 ? "" : "s"} due`, icon:Receipt,     tone:"amber" },
              { label:"Selected to pay",  value:money(total),       sub:`${picked.length} selected`,                                icon:CircleCheck, tone:"emerald" },
              { label:"Paid this period", value:money(paidPeriod),  sub:`${hist.length} payments`,                                  icon:Banknote,    tone:"sky" },
            ].map((s) => (
              <div key={s.label} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0 sm:py-1 sm:px-5 sm:first:pl-0 sm:last:pr-0">
                <span className="grid place-items-center w-10 h-10 rounded-xl shrink-0" style={tint(s.tone)}><s.icon size={18} /></span>
                <div className="min-w-0">
                  <div className={`text-xl font-bold ${t.strong}`} style={{ letterSpacing: "-0.02em" }}>{s.value}</div>
                  <div className={`text-xs ${t.muted}`}>{s.label} · {s.sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      <div className="grid lg:grid-cols-3 gap-4 items-start">
        <Card t={t} className="lg:col-span-2">
          <CardTitle t={t} icon={Receipt} title="Bills to pay"
            right={<div className="flex items-center gap-3">
              {bills.length > 0 && <button onClick={allSel ? clearSel : selectAll} className="text-xs font-semibold" style={{ color: TONE.emerald }}>{allSel ? "Clear all" : "Select all"}</button>}
              <button onClick={() => setForm("new")} className="flex items-center gap-1 px-2.5 h-8 rounded-lg bg-emerald-600 text-white text-xs font-semibold shadow-sm hover:bg-emerald-700"><Plus size={14} /> Add invoice</button>
            </div>} />
          {bills.length === 0 ? <Empty t={t} msg="All caught up — no outstanding bills." /> : (
            <div className="space-y-2">
              {bills.map((b) => {
                const on = sel.has(b.id);
                return (
                  <div key={b.id} className={`group flex items-center gap-2 rounded-xl border transition-colors ${on ? "" : t.hover}`}
                    style={on ? { borderColor: TONE.emerald, backgroundColor: TONE.emerald + "0f" } : { borderColor: "transparent" }}>
                    <button onClick={() => toggle(b.id)} className="flex-1 min-w-0 flex items-center gap-3 p-3 text-left">
                      <span className="grid place-items-center w-10 h-10 rounded-lg shrink-0" style={tint(b.tone)}><b.icon size={17} /></span>
                      <div className="min-w-0 flex-1">
                        <div className={`text-sm font-semibold ${t.strong} truncate`}>{b.label}</div>
                        <div className="text-xs flex items-center gap-1.5 mt-0.5">
                          <span className={`${t.muted} truncate`}>{b.payee}</span>
                          <span className="px-1.5 py-0.5 rounded-full font-medium shrink-0" style={tint(b.tone)}>{b.cat}</span>
                          {b.due && <span className={`${t.muted} shrink-0`}>· due {b.due}</span>}
                        </div>
                      </div>
                      <div className={`text-sm font-bold ${t.strong} shrink-0`}>{money(b.amount)}</div>
                      <span className="grid place-items-center w-5 h-5 rounded-md border shrink-0" style={{ borderColor: on ? TONE.emerald : t.axis, backgroundColor: on ? TONE.emerald : "transparent" }}>
                        {on && <CircleCheck size={14} className="text-white" />}
                      </span>
                    </button>
                    <div className="flex gap-1 pr-2 shrink-0 opacity-60 sm:opacity-0 sm:group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                      <button onClick={() => setForm(b)} title="Edit" className={`grid place-items-center w-8 h-8 rounded-lg border ${t.border} ${t.chip}`} style={{ color: TONE.sky }}><Pencil size={14} /></button>
                      <button onClick={() => removeBill(b.id)} title="Delete" className={`grid place-items-center w-8 h-8 rounded-lg border ${t.border} ${t.chip}`} style={{ color: TONE.rose }}><Trash2 size={14} /></button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        <Card t={t} className="lg:sticky lg:top-4 self-start">
          <CardTitle t={t} icon={CreditCard} title="Checkout" />
          {err && <div className="mb-3 px-3 py-2 rounded-lg text-sm" style={tint("rose")}>{err}</div>}

          <label className={`text-xs font-medium ${t.muted} mb-1 block`}>Payment method</label>
          <div className="flex gap-2 mb-3">
            {methods.map((m) => {
              const on = method === m.key;
              return (
                <button key={m.key} onClick={() => setMethod(m.key)}
                  className={`flex-1 flex items-center justify-center gap-1.5 h-10 rounded-lg text-sm font-medium border ${t.border} ${on ? "text-white shadow-sm" : `${t.chip} ${t.muted}`}`}
                  style={on ? { backgroundColor: TONE.emerald, borderColor: TONE.emerald } : undefined}>
                  <m.icon size={15} /> {m.key}
                </button>
              );
            })}
          </div>

          {method === "M-Pesa" && (
            <div className="mb-3">
              <label className={`text-xs font-medium ${t.muted} mb-1 block`}>M-Pesa phone number</label>
              <div className={`flex items-center gap-2 ${field}`}><Smartphone size={15} className={t.muted} /><input className={`bg-transparent outline-none w-full ${t.strong}`} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="07XX XXX XXX" /></div>
            </div>
          )}

          <div className={`rounded-xl border ${t.border} ${t.chip} divide-y ${t.divide} mb-3`}>
            <Row t={t} k="Items" v={String(picked.length)} />
            <Row t={t} k="Total" v={<b style={{ color: TONE.emerald }}>{money(total)}</b>} />
          </div>

          <button onClick={pay} disabled={picked.length === 0}
            className={`w-full flex items-center justify-center gap-2 h-11 rounded-xl text-white text-sm font-semibold shadow-sm ${picked.length === 0 ? "opacity-50 cursor-not-allowed bg-emerald-600" : "bg-emerald-600 hover:bg-emerald-700"}`}>
            {method === "M-Pesa" ? <Smartphone size={17} /> : <CreditCard size={17} />} Pay {money(total)}
          </button>
          <p className={`text-xs ${t.muted} mt-2 text-center`}>{method === "M-Pesa" ? "An STK push is sent to your phone — enter your PIN to authorize." : `Records the ${method.toLowerCase()} payment against these bills.`}</p>
        </Card>
      </div>

      <Card t={t}>
        <CardTitle t={t} icon={Clock} title="Recent payments" right={<span className={`text-xs ${t.muted}`}>Paid this period {money(paidPeriod)}</span>} />
        <DataTable t={t} minWidth={480} rows={hist} rowKey={undefined}
          columns={[
            { label:"Ref",    render:(h)=><span className={`font-mono text-xs ${t.strong}`}>{h.ref}</span> },
            { label:"Payee",  render:(h)=><span className={t.strong}>{h.payee}</span> },
            { label:"Method", render:(h)=><span className="text-xs font-medium px-2 py-0.5 rounded-full" style={tint(h.method === "M-Pesa" ? "emerald" : h.method === "Card" ? "sky" : "amber")}>{h.method}</span> },
            { label:"When",   render:(h)=><span className={`text-xs ${t.muted}`}>{h.when}</span> },
            { label:"Amount", align:"right", render:(h)=><span className={`font-semibold nf-num ${t.strong}`}>{money(h.amount)}</span> },
          ]} />
      </Card>

      {/* STK push / receipt */}
      {form && <AddInvoice t={t} initial={form === "new" ? null : form} onCancel={() => setForm(null)} onSave={saveBill} />}
      {stk === "pushing" && (
        <Modal t={t} title="M-Pesa payment" icon={Smartphone} tone="emerald" narrow onCancel={() => setStk(null)}
          footer={<button onClick={() => setStk(null)} className={`px-4 h-10 rounded-lg text-sm font-medium border ${t.border} ${t.muted} ${t.hover}`}>Cancel</button>}>
          <div className="flex flex-col items-center text-center py-4">
            <span className="relative grid place-items-center w-16 h-16 mb-3">
              <span className="absolute inline-flex w-16 h-16 rounded-full opacity-60 animate-ping" style={{ backgroundColor: TONE.emerald + "55" }} />
              <span className="grid place-items-center w-16 h-16 rounded-full" style={tint("emerald")}><Smartphone size={26} /></span>
            </span>
            <div className={`font-semibold ${t.strong}`}>STK push sent to {phone}</div>
            <div className={`text-sm ${t.muted} mt-1`}>Enter your M-Pesa PIN on your phone to authorize <b className={t.strong}>{money(total)}</b>.</div>
          </div>
        </Modal>
      )}
      {stk && stk.receipt && (
        <Modal t={t} title="Payment successful" icon={CircleCheck} tone="emerald" narrow onCancel={() => setStk(null)}
          footer={<button onClick={() => setStk(null)} className="px-4 h-10 rounded-lg bg-emerald-600 text-white text-sm font-medium shadow-sm hover:bg-emerald-700">Done</button>}>
          <div className="text-center pb-3">
            <div className="grid place-items-center w-14 h-14 rounded-full mx-auto mb-2" style={tint("emerald")}><CircleCheck size={26} /></div>
            <div className={`text-sm ${t.muted}`}>{stk.receipt.method} confirmation</div>
            <div className={`text-lg font-bold tracking-wide ${t.strong}`}>{stk.receipt.method === "M-Pesa" ? "Q" + stk.receipt.ref : stk.receipt.ref}</div>
          </div>
          <div className={`rounded-xl border ${t.border} ${t.chip} divide-y ${t.divide}`}>
            <Row t={t} k="Amount" v={<b style={{ color: TONE.emerald }}>{money(stk.receipt.amount)}</b>} />
            <Row t={t} k="Method" v={stk.receipt.method === "M-Pesa" ? `M-Pesa · ${stk.receipt.phone}` : stk.receipt.method} />
            <Row t={t} k="Bills paid" v={String(stk.receipt.items.length)} />
          </div>
          <div className="mt-3 space-y-1.5">
            {stk.receipt.items.map((b) => (
              <div key={b.id} className={`flex justify-between text-sm px-3 py-2 rounded-lg border ${t.border}`}>
                <span className={`${t.strong} truncate pr-2`}>{b.payee}</span><span className={t.muted}>{money(b.amount)}</span>
              </div>
            ))}
          </div>
        </Modal>
      )}
    </div>
  );
}

function Reports({ t }) {
  const reports = [
    { name:"Animal register", icon:Beef },{ name:"Medical report", icon:Stethoscope },{ name:"Vaccination report", icon:Syringe },
    { name:"Mortality report", icon:Skull },{ name:"Breeding report", icon:Baby },{ name:"Milk production", icon:Milk },
    { name:"Weight gain", icon:WeightIcon },{ name:"Financial report", icon:Wallet },{ name:"Inventory report", icon:Boxes },
  ];
  return (
    <div className="space-y-5">
      <Head t={t} title="Reports" sub="Export to PDF, Excel or CSV" />
      <div className="space-y-2">
        {reports.map((r)=>(
          <div key={r.name} className={`flex items-center gap-3 p-3 rounded-xl border ${t.border} ${t.card}`}>
            <span className="grid place-items-center w-10 h-10 rounded-lg shrink-0" style={tint("emerald")}><r.icon size={18}/></span>
            <div className={`font-semibold text-sm ${t.strong} flex-1 min-w-0 truncate`}>{r.name}</div>
            <div className="flex gap-2 shrink-0">{["PDF","Excel","CSV"].map((f)=><button key={f} className={`text-xs px-2.5 py-1 rounded-md border ${t.border} ${t.muted} ${t.hover}`}>{f}</button>)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Primitives                                                        */
/* ================================================================== */
function Head({ t, title, sub, action }) {
  return (
    <div className="flex items-end justify-between gap-3 flex-wrap">
      <div>
        <h1 className={`text-xl sm:text-2xl font-bold tracking-tight ${t.strong}`} style={{ letterSpacing: "-0.02em" }}>{title}</h1>
        {sub && <p className={`text-sm ${t.muted} mt-1`}>{sub}</p>}
      </div>
      {action}
    </div>
  );
}
function Card({ t, className = "", children }) {
  return <div className={`p-4 sm:p-5 rounded-2xl border ${t.border} ${t.card} ${className}`} style={{ boxShadow: t.shadow }}>{children}</div>;
}
function CardTitle({ t, icon: Icon, title, right }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-2">{Icon && <Icon size={16} style={{ color: TONE.emerald }} />}<h3 className={`font-semibold text-sm tracking-tight ${t.strong}`}>{title}</h3></div>
      {right}
    </div>
  );
}
function Stat({ t, label, value, sub, icon: Icon, tone = "emerald" }) {
  return (
    <div className={`p-4 rounded-2xl border ${t.border} ${t.card}`} style={{ boxShadow: t.shadow }}>
      <span className="grid place-items-center w-9 h-9 rounded-lg" style={tint(tone)}><Icon size={17} /></span>
      <div className={`text-2xl font-bold mt-3 tracking-tight ${t.strong}`} style={{ letterSpacing: "-0.02em" }}>{value}</div>
      <div className={`text-xs font-medium ${t.strong} mt-0.5`}>{label}</div>
      {sub && <div className={`text-xs ${t.muted}`}>{sub}</div>}
    </div>
  );
}
function Alert({ t, tone, icon: Icon, title, body, cta, onClick }) {
  return (
    <div className={`p-4 rounded-2xl border ${t.border} ${t.card}`} style={{ boxShadow: t.shadow }}>
      <div className="flex items-start gap-3">
        <span className="grid place-items-center w-9 h-9 rounded-lg shrink-0" style={tint(tone)}><Icon size={17} /></span>
        <div className="flex-1 min-w-0">
          <div className={`text-sm font-semibold ${t.strong}`}>{title}</div>
          <div className={`text-xs ${t.muted}`}>{body}</div>
          <button onClick={onClick} className="text-xs font-medium mt-1.5 inline-flex items-center gap-0.5 hover:underline" style={{ color: solid(tone) }}>{cta} <ChevronRight size={12} /></button>
        </div>
      </div>
    </div>
  );
}
function Meta({ t, label, value }) {
  return (
    <div>
      <div className={`text-xs uppercase tracking-wide ${t.muted}`}>{label}</div>
      <div className={`text-sm font-medium ${t.strong}`}>{value}</div>
    </div>
  );
}
function Connector() { return <div className="flex justify-center py-3"><div className="w-px h-6" style={{ background: TONE.emerald + "4d" }} /></div>; }
function Empty({ t, msg }) { return <div className={`py-10 text-center text-sm ${t.muted}`}>{msg}</div>; }

/* Responsive table: a normal table on sm+, stacked label/value cards on phones
   (no horizontal scrolling). columns: [{ label, align?, render?(row), key? }] */
function DataTable({ t, columns, rows, minWidth = 480, rowKey }) {
  const val = (c, r, i) => (c.render ? c.render(r, i) : r[c.key]);
  return (
    <>
      <div className="hidden sm:block overflow-x-auto">
        <table style={{ minWidth }} className="w-full text-sm">
          <thead>
            <tr className={`text-xs ${t.muted} border-b ${t.border}`}>
              {columns.map((c, i) => <th key={i} className={`py-2 font-medium ${c.align === "right" ? "text-right" : "text-left"}`}>{c.label}</th>)}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, ri) => (
              <tr key={rowKey ? r[rowKey] : ri} className={`border-b ${t.border}`}>
                {columns.map((c, ci) => <td key={ci} className={`py-2.5 ${c.align === "right" ? "text-right" : ""}`}>{val(c, r, ri)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="sm:hidden space-y-2">
        {rows.map((r, ri) => (
          <div key={rowKey ? r[rowKey] : ri} className={`rounded-xl border ${t.border} p-3 space-y-1.5`}>
            {columns.map((c, ci) => (
              <div key={ci} className="flex items-center justify-between gap-3">
                <span className={`text-xs ${t.muted} shrink-0`}>{c.label}</span>
                <span className={`text-sm ${t.strong} text-right min-w-0`}>{val(c, r, ri)}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </>
  );
}

const statusColor = { Active:"emerald", Sold:"sky", Dead:"rose", Missing:"amber", Transferred:"sky", Slaughtered:"stone", Culled:"amber" };
function StatusDot({ status }) { return <span className="w-2 h-2 rounded-full inline-block" style={{ background: solid(statusColor[status]) }} />; }
function StatusPill({ status }) { return <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={tint(statusColor[status])}>{status}</span>; }

/* ================================================================== */
/*  Theme                                                             */
/* ================================================================== */
function theme(dark) {
  return dark ? {
    app:"text-stone-100",
    bg:"linear-gradient(135deg, #0c1611 0%, #101813 40%, #14130d 100%)",
    side:"bg-stone-900", bar:"bg-stone-900", card:"bg-stone-900",
    chip:"bg-stone-800", input:"bg-stone-800", track:"bg-stone-800", divide:"divide-stone-800",
    border:"border-stone-800", hover:"hover:bg-stone-800", strong:"text-stone-100", muted:"text-stone-400",
    ring:"ring-stone-900", grid:"#292524", axis:"#a8a29e",
    shadow:"0 1px 2px rgba(0,0,0,0.30), 0 1px 3px rgba(0,0,0,0.22)",
    tip:{ background:"#1c1917", border:"1px solid #292524", borderRadius:10, color:"#f5f5f4", fontSize:12 },
  } : {
    app:"text-stone-800",
    bg:"linear-gradient(135deg, #e6f4df 0%, #dcefce 100%)",
    side:"bg-white", bar:"bg-white", card:"bg-white",
    chip:"bg-stone-100", input:"bg-stone-50", track:"bg-stone-200", divide:"divide-stone-200",
    border:"border-stone-200", hover:"hover:bg-stone-100", strong:"text-stone-900", muted:"text-stone-500",
    ring:"ring-white", grid:"#e7e5e4", axis:"#78716c",
    shadow:"0 1px 2px rgba(16,24,40,0.04), 0 2px 6px rgba(16,24,40,0.06)",
    tip:{ background:"#ffffff", border:"1px solid #e7e5e4", borderRadius:10, color:"#1c1917", fontSize:12 },
  };
}

/* Memoized view aliases — a view only re-renders when its own props change,
   so unrelated top-level state (search text, cart, offline toggle) doesn't
   redraw every screen. */
const DashboardM    = React.memo(Dashboard);
const HealthM       = React.memo(Health);
const ProductivityM = React.memo(Productivity);
const WeightViewM   = React.memo(WeightView);
const FinanceM      = React.memo(Finance);
const ScanM         = React.memo(Scan);
const AdvisoryM     = React.memo(Advisory);
const BreedingM     = React.memo(Breeding);
const FamilyTreeM   = React.memo(FamilyTree);
const FeedM         = React.memo(Feed);
const InventoryM    = React.memo(Inventory);
const CooperativeM  = React.memo(Cooperative);
const PaymentsM     = React.memo(Payments);
const ReportsM      = React.memo(Reports);
const RegisterM     = React.memo(Register);
const CartM         = React.memo(Cart);
const InvoiceM      = React.memo(Invoice);
const LogbookM      = React.memo(Logbook);
const TransactionsM = React.memo(Transactions);
