import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "ke.co.ngorofarm.app",
  appName: "NgoroFarm",
  webDir: "dist",
  // Android WebView settings
  android: {
    allowMixedContent: false,
  },
  server: {
    androidScheme: "https",
  },
};

export default config;
