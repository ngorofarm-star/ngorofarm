# Create the container image — from the browser only (no CLI, no Docker)

If the command-line tools keep failing, build the image entirely in the Google
Cloud **console**. Google Cloud Build does the work; you only click.

`cloudbuild.yaml` (in the project root) tells Cloud Build to build the
`server/` image, push it to Artifact Registry, and deploy it to Cloud Run.

---

## One-time prep (console)

1. **Pick/confirm your project** (top bar) and make sure **Billing is linked**
   (Billing → Link a billing account). Nothing builds without billing.
2. **Enable APIs** — search each in the console and click *Enable*:
   Cloud Build, Artifact Registry, Cloud Run, Secret Manager.
3. **Create the image repository** — *Artifact Registry → Create repository*:
   - Name: `ngorofarm`
   - Format: **Docker**
   - Region: **africa-south1**
4. **Store your Anthropic key** — *Secret Manager → Create secret*:
   - Name: `ANTHROPIC_API_KEY`
   - Value: your `sk-ant-...` key
5. **Give Cloud Build permission to deploy** — *IAM → find the
   `...@cloudbuild.gserviceaccount.com` account → Edit → add roles*:
   **Cloud Run Admin**, **Service Account User**, **Secret Manager Secret
   Accessor**, **Artifact Registry Writer**.

## Build it (choose ONE)

### A. On every GitHub push (recommended — fully automatic)

*Cloud Build → Triggers → Create trigger*:
- Source: connect your **GitHub** repo (the console walks you through it).
- Event: *Push to a branch* → `^main$`.
- Configuration: **Cloud Build configuration file** → `/cloudbuild.yaml`.
- Create. Then click **Run** (or just push to `main`).

### B. One-off, right now, without GitHub

*Cloud Build → History → Run a build* isn't source-connected, so easiest is:
upload the repo to a Cloud Storage bucket, or use the Trigger above. If you have
Cloud Shell open (it needs no install), a single line does it:

```bash
gcloud builds submit --config cloudbuild.yaml \
  --substitutions SHORT_SHA=manual .
```

## Result

Watch **Cloud Build → History**. When the build is green, your image exists at:

```
africa-south1-docker.pkg.dev/<PROJECT_ID>/ngorofarm/ngorofarm-api:<sha>
```

and the Cloud Run service `ngorofarm-api` is live — open **Cloud Run** in the
console to get its URL, then visit `<url>/health` (should show `{"ok":true}`).

## Only want the image, not a deploy?

Delete the **deploy** step (step 3) from `cloudbuild.yaml`. Cloud Build will
still build and push the image; deploy it later from *Cloud Run → Create
service → Deploy from an existing image* and pick it from Artifact Registry —
all in the console.
