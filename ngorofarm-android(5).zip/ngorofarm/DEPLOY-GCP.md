# Deploy NgoroFarm on Google Cloud

Recommended setup: **Firebase Hosting** (web app) + **Cloud Run** (secure API /
chatbot proxy / M-Pesa). Both start on free tiers. Use region
**`africa-south1`** (Johannesburg) for lowest latency to Kenya.

Prerequisites: a Google account, the **gcloud** CLI, and **firebase-tools**
(`npm i -g firebase-tools`). Create a project at console.cloud.google.com and
note its **project ID**.

---

## 1. Frontend → Firebase Hosting

```bash
# from the project root
npm install
npm run build                      # produces dist/

npm i -g firebase-tools
firebase login
# put your real project id in .firebaserc (replace your-firebase-project-id)
firebase deploy --only hosting
```

Your app is now live at `https://<project>.web.app`. `firebase.json` already:
- serves `dist/`,
- rewrites SPA routes to `index.html`,
- rewrites `/api/**` to the Cloud Run service `ngorofarm-api` (deployed next),
  so the frontend can call the chatbot proxy **same-origin**.

## 2. Backend → Cloud Run (chatbot proxy today, M-Pesa + data later)

```bash
cd server
gcloud config set project <PROJECT_ID>

# store your Anthropic key in Secret Manager (never in code)
printf "sk-ant-..." | gcloud secrets create ANTHROPIC_API_KEY --data-file=-

gcloud run deploy ngorofarm-api \
  --source . \
  --region africa-south1 \
  --allow-unauthenticated \
  --set-secrets ANTHROPIC_API_KEY=ANTHROPIC_API_KEY:latest
```

This builds the Dockerfile, deploys the service, and injects the key at runtime.
Test it: `curl https://<cloud-run-url>/health` → `{"ok":true}`.

## 3. Point the chatbot at the proxy (production)

In `src/NgoroFarm.jsx`, the `ChatBot` currently calls the Anthropic API
directly (fine for the demo, but it would expose usage in production). For the
deployed app, change that one `fetch` to call your own endpoint instead:

```js
const res = await fetch("/api/chat", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ system, messages: next }),
});
const data = await res.json();
const reply = data.text;
```

Because Firebase Hosting rewrites `/api/**` to Cloud Run, this works
same-origin with no CORS or key exposure. Rebuild and `firebase deploy` again.

## 4. Data & auth (next)

- **Firestore** for herd / health / breeding / milk / payments records — pairs
  with Firebase and has offline sync for patchy rural connectivity.
- **Firebase Auth** for login / passkeys (reuses the biometric flow).
- **M-Pesa Daraja**: add STK-push + callback routes in `server/index.js`
  (placeholders are marked), store the Daraja keys in Secret Manager, and give
  Safaricom the Cloud Run callback URL.

## Notes

- Update `ANTHROPIC_MODEL` (env on the Cloud Run service) to a current model
  string — check docs.anthropic.com.
- The Android APK still builds via GitHub Actions (see GET-THE-APK.md); the
  installed app simply talks to these same hosted URLs.
- Costs: Hosting + Cloud Run (scale-to-zero) + Firestore all have free tiers
  that comfortably cover a pilot.
