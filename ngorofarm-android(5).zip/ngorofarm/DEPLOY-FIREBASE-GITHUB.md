# Auto-deploy the web app to Firebase Hosting from GitHub

The workflow `.github/workflows/firebase-hosting.yml` builds the app and deploys
`dist/` to Firebase Hosting on every push to `main`.

## Easiest setup (recommended)

Let Firebase wire up the GitHub connection for you. From the project root, once:

```bash
npm i -g firebase-tools
firebase login
firebase init hosting:github
```

Answer the prompts (pick your Firebase project, set public dir to `dist`,
configure as a single-page app = **Yes**). It will:
- create the service account,
- add the **`FIREBASE_SERVICE_ACCOUNT`** secret to your GitHub repo,
- and generate a workflow.

You can keep that generated file or the one in this repo — just make sure the
`projectId` matches your Firebase project.

## Manual setup (if you'd rather not run the wizard)

1. Put your real project ID in `firebase-hosting.yml` (replace
   `your-firebase-project-id`) and in `.firebaserc`.
2. In the **Google Cloud console → IAM → Service Accounts**, create a service
   account with the **Firebase Hosting Admin** role. If you keep the `/api/**`
   rewrite to Cloud Run in `firebase.json`, also grant **Cloud Run Viewer** (the
   deployer needs to read the `ngorofarm-api` service to publish the rewrite).
3. Create a JSON key for that account, then in your GitHub repo go to
   **Settings → Secrets and variables → Actions → New repository secret**:
   - Name: `FIREBASE_SERVICE_ACCOUNT`
   - Value: paste the entire JSON key file.

## Deploy

```bash
git add .
git commit -m "NgoroFarm web app"
git push origin main
```

Open the repo's **Actions** tab — the **Deploy web app to Firebase Hosting** job
runs, builds, and publishes. When it's green, your app is live at
`https://<project>.web.app`.

## Notes

- Pull requests get a temporary **preview URL** automatically (the action posts
  it as a PR comment) so you can review before merging to `main`.
- The `npm ci` step needs `package-lock.json` (already included).
- Deploying the API (`server/`) to Cloud Run is separate — see `DEPLOY-GCP.md`.
