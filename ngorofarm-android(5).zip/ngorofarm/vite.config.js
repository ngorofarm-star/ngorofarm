import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "dist",
    // Capacitor loads from file:// inside the WebView, so use relative asset paths.
    assetsDir: "assets",
  },
  base: "./",
});
