# NgoroFarm — Android app (Vite + React + Capacitor)

Birth-to-sale livestock management for the modern Kenyan farm. This project wraps
the NgoroFarm web app in a native Android shell using **Capacitor**, so you can
produce an installable **APK** (or a signed **AAB** for the Play Store).

> The web build is verified: `npm run build` compiles cleanly with Tailwind JIT.
> (Running under real Tailwind here also removes the artifact's "arbitrary class"
> limitation — every utility class now works.)

---

## Prerequisites (install once)

- **Node.js** LTS (18 or 20) — https://nodejs.org
- **Android Studio** (includes the Android SDK & an emulator) — https://developer.android.com/studio
- **JDK 17** (Android Studio bundles one; or install Temurin 17)

After installing Android Studio, open it once and let it finish downloading the
Android SDK and build tools.

---

## 1. Install dependencies

```bash
npm install
```

## 2. Build the web app

```bash
npm run build      # outputs to dist/
```

## 3. Add the Android platform (first time only)

```bash
npx cap add android
```

This creates an `android/` folder (a real Gradle project).

## 4. Sync the web build into Android

```bash
npx cap sync
```

Run this every time after `npm run build`. Shortcut: `npm run cap:sync`.

## 5. Open in Android Studio

```bash
npx cap open android
```

(Shortcut for build + sync + open: `npm run cap:android`.)

## 6. Produce the APK

In Android Studio:

- **Quick test APK:** menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
  When it finishes, click **locate** — the file is at
  `android/app/build/outputs/apk/debug/app-debug.apk`.
  Copy it to a phone and install (enable "Install unknown apps").

- **Signed release (for sharing / Play Store):** **Build → Generate Signed
  Bundle / APK**, create a keystore when prompted (keep it safe — you need the
  same key for every future update), choose **APK** (sideloading) or **Android
  App Bundle / AAB** (Play Store), and select the **release** build.

You can also run straight onto a connected phone (USB debugging on) or emulator
with the ▶ **Run** button.

---

## Project layout

```
ngorofarm/
├─ index.html              # app shell (mobile viewport, theme-color)
├─ vite.config.js          # base:"./" so assets load from file:// in the WebView
├─ tailwind.config.js      # scans src/**
├─ postcss.config.js
├─ capacitor.config.ts     # appId ke.co.ngorofarm.app, webDir "dist"
├─ src/
│  ├─ main.jsx             # React entry
│  ├─ index.css            # Tailwind directives + safe-area padding
│  └─ NgoroFarm.jsx        # the whole app (single component)
└─ (android/ appears after `npx cap add android`)
```

Change the app identity in `capacitor.config.ts` (`appId`, `appName`) before your
first release. The `appId` must stay stable once published.

---

## Recommended native plugins (already in package.json)

- `@capacitor/camera` — native camera for RFID/QR tag scanning (better than the
  browser `getUserMedia` fallback the prototype uses).
- `@capacitor/preferences` — simple persistent key/value storage.

Add more as needed, e.g.:

```bash
npm i @capacitor/splash-screen @capacitor/status-bar
# fingerprint / Face ID:
npm i @capacitor-community/biometric-auth
# offline database:
npm i @capacitor-community/sqlite
```

After adding any plugin: `npm run build && npx cap sync`.

---

## From prototype to production (what to wire next)

The app currently runs on in-memory mock data. To make the APK genuinely useful:

1. **Backend + API** for the herd, health, breeding, feed, finance data.
2. **M-Pesa Daraja** STK push for real payments (replace the simulated flow).
3. **Offline capture & sync** via `@capacitor-community/sqlite` (the offline
   indicator is already in the UI).
4. **Real biometric login** — WebAuthn passkeys on the web, or the native
   biometric plugin inside the app.
5. **Camera permissions** — declared automatically by the Camera plugin; review
   `android/app/src/main/AndroidManifest.xml` before release.

---

## Troubleshooting

- **Blank white screen in the app:** make sure `base: "./"` is set in
  `vite.config.js` (it is) and that you ran `npx cap sync` after building.
- **Gradle / SDK errors:** open Android Studio once and let it install the SDK
  and accept licenses; set JDK 17 in Settings → Build Tools → Gradle.
- **Changes not showing:** rebuild and re-sync — `npm run cap:sync`.

Docs: https://capacitorjs.com/docs/android
