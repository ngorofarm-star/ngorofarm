/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  // NgoroFarm manages light/dark through its own token system (inline styles),
  // so we don't rely on Tailwind's `dark:` variant here.
  theme: {
    extend: {},
  },
  plugins: [],
};
