import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const KEY = process.env.ANTHROPIC_API_KEY;                 // set via Secret Manager
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-4-6"; // update to a current model string

app.get("/health", (_req, res) => res.json({ ok: true }));

// Secure chatbot proxy — the browser calls this instead of Anthropic directly,
// so the API key never leaves the server.
app.post("/api/chat", async (req, res) => {
  try {
    if (!KEY) return res.status(500).json({ error: "ANTHROPIC_API_KEY not configured" });
    const { messages = [], system } = req.body || {};

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({ model: MODEL, max_tokens: 1000, system, messages }),
    });

    const data = await r.json();
    const text = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n")
      .trim();
    res.json({ text });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// --- M-Pesa Daraja (STK push + callback) would go here ---------------------
// app.post("/api/mpesa/stkpush", ...)
// app.post("/api/mpesa/callback", ...)   // Safaricom posts payment result here
// ---------------------------------------------------------------------------

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`NgoroFarm API listening on ${port}`));
